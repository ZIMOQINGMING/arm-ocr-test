#!/usr/bin/env bash
# MediaBoard v7.1 一键取证包（collect.sh）：现场报障时打包全部证据，U 盘拷走即送修
# 内容：全部配置 / playlist 快照 / 播出日志（末 200 行）/ 自截屏（末 6 张）/
#       版本与环境信息（内核、浏览器版本、磁盘、字体清单）
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
OUT="$DIR/support-$TS"

mkdir -p "$OUT/logs"
# 配置类（小文件，全量）
for f in settings.txt layout.txt schedule.txt ticker.txt notify.txt schemes.js fonts.json VERSION; do
  [ -f "$DIR/$f" ] && cp "$DIR/$f" "$OUT/" 2>/dev/null
done
for d in schemes layouts; do
  [ -d "$DIR/$d" ] && cp -r "$DIR/$d" "$OUT/" 2>/dev/null
done
find "$DIR/schemes" -name "playlist-*.js" >/dev/null 2>&1 && cp "$DIR"/playlist-*.js "$OUT/" 2>/dev/null
[ -f "$DIR/playlist.js" ] && cp "$DIR/playlist.js" "$OUT/" 2>/dev/null

# 日志与截屏（限量防撑爆）
if [ -f "$DIR/logs/play.jsonl" ]; then
  tail -200 "$DIR/logs/play.jsonl" > "$OUT/logs/play.jsonl"
fi
if [ -d "$DIR/logs/shots" ]; then
  ls -1t "$DIR/logs/shots"/*.png 2>/dev/null | head -6 | while IFS= read -r s; do cp "$s" "$OUT/logs/"; done
fi

# 环境快照
{
  echo "===== MediaBoard 取证环境 ====="
  echo "时间:   $(date)"
  [ -f "$DIR/VERSION" ] && { echo "版本:"; cat "$DIR/VERSION"; }
  echo "内核:   $(uname -a)"
  echo "架构:   $(uname -m)"
  for c in chromium-browser chromium google-chrome; do
    command -v "$c" >/dev/null 2>&1 && { echo "浏览器: $("$c" --version 2>/dev/null)"; break; }
  done
  echo "磁盘:   $(df -h "$DIR" | tail -1)"
  echo "中文字体: $(fc-list :lang=zh 2>/dev/null | wc -l) 个族"
  echo "播放进程: $(pgrep -af 'player\.html' 2>/dev/null || echo 无)"
  echo "看门狗:   $([ -f "$DIR/.runpid" ] && cat "$DIR/.runpid" 2>/dev/null || echo 未记录)"
} > "$OUT/environment.txt" 2>/dev/null

tar czf "$DIR/support-$TS.tar.gz" -C "$DIR" "support-$TS" 2>/dev/null && rm -rf "$OUT"
echo "取证包已生成: $DIR/support-$TS.tar.gz"
echo "拷贝到 U 盘后删除（防止长期堆积）: rm -f $DIR/support-*.tar.gz"
