#!/usr/bin/env bash
# MediaBoard v7.1 停止脚本（A-05 修复：停机令牌 + 进程组收敛）
# 修复前问题：仅 pkill 浏览器且路径写死安装目录名；看门狗 3 秒后必定重拉，无法真停机。
# 修复后机制：
#   1) touch .stop 停机令牌 —— start.sh 看门狗循环每轮首查令牌，在位即退出（最长 ~4 秒）
#   2) 按启动时记录的 .runpid 以进程组整体终止（start.sh + kiosk 浏览器 + 自截屏子进程）
#      —— PID 与目录名无关，安装目录改名后依然有效（路径无关化）
#   3) 兜底 pkill 按播放器入口文件名 player.html 匹配，不依赖任何目录路径
#   4) start.sh 启动时自动清除令牌，重播无需手工删
# 用法: bash stop.sh   （之后重启用 bash start.sh）
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"

# 1) 停机令牌
[ -f "$DIR/.stop" ] || touch "$DIR/.stop"

# 2) 进程组终止（主 PID 启动时写入 .runpid）
if [ -f "$DIR/.runpid" ]; then
  PID="$(cat "$DIR/.runpid" 2>/dev/null)"
  if [ -n "${PID:-}" ] && kill -0 "$PID" 2>/dev/null; then
    # 仅当该 PID 确为进程组长（pgid==pid）才整组终止；否则只杀主进程，
    # 由停机令牌 + player.html 特征兜底收敛（防止误杀同组的无关进程）
    # pgid 提取：procps 优先，/proc/status 的 NSpgid 兜底（部分环境无该字段）
    PGID="$(ps -o pgid= -p "$PID" 2>/dev/null | tr -d ' ')"
    [ -z "$PGID" ] && PGID="$(awk '/^(PGid|NSpgid):/{print $2}' "/proc/$PID/status" 2>/dev/null)"
    if [ -n "$PGID" ] && [ "$PGID" = "$PID" ]; then
      kill -TERM -- "-$PID" 2>/dev/null || kill -TERM "$PID" 2>/dev/null || true
    else
      kill -TERM "$PID" 2>/dev/null || true
    fi
  fi
  rm -f "$DIR/.runpid"
fi

# 3) 兜底：按稳定特征杀残留播放器进程（与安装目录名无关）
pkill -f "player\.html" 2>/dev/null || true

# 4) 收敛确认（等待至多 5 秒）
i=0
while [ $i -lt 5 ]; do
  pgrep -f "player\.html" >/dev/null 2>&1 || break
  sleep 1; i=$((i + 1))
done
if pgrep -f "player\.html" >/dev/null 2>&1; then
  echo "[MediaBoard] 仍有播放进程残留，请人工核查: pgrep -af player.html"
  exit 1
else
  echo "已停止播放（看门狗已解除，令牌 .stop 在位；重启用 bash start.sh）"
fi
