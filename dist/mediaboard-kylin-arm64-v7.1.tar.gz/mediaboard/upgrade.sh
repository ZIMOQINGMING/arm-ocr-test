#!/usr/bin/env bash
# MediaBoard v7.1 升级/回滚（upgrade.sh）：离网环境没有"重新下载"，回滚能力就是安全网
# 用法:
#   bash upgrade.sh <新版包.tar.gz>    升级到新版（自动备份可回滚）
#   bash upgrade.sh rollback            列出可用备份
#   bash upgrade.sh rollback <时间戳>   从 backup/<时间戳> 恢复
# 备份范围（用户资产，升级绝不动手改的现场内容）:
#   schemes/ settings.txt layout.txt schedule.txt ticker.txt notify.txt fonts/ content/
# 注意: content/ 大时备份耗时较长；升级后必须 bash stop.sh && bash start.sh 生效。
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
BAK="$DIR/backup"

do_backup() { # $1=标签(时间戳)
  local tag="$1"
  mkdir -p "$BAK/$tag"
  for f in settings.txt layout.txt schedule.txt ticker.txt notify.txt; do
    [ -f "$DIR/$f" ] && cp "$DIR/$f" "$BAK/$tag/"
  done
  for d in schemes fonts content layouts; do
    [ -d "$DIR/$d" ] && cp -r "$DIR/$d" "$BAK/$tag/"
  done
  echo "[备份] $BAK/$tag"
}

case "${1:-}" in
  rollback)
    shift
    if [ -z "${1:-}" ]; then
      echo "可用备份:"
      ls -1t "$BAK" 2>/dev/null || echo "  （无）"
      echo "用法: bash upgrade.sh rollback <时间戳>"
      exit 0
    fi
    TAG="$1"
    [ -d "$BAK/$TAG" ] || { echo "[错误] 备份不存在: $BAK/$TAG"; exit 1; }
    echo "[回滚] 从 $BAK/$TAG 恢复（覆盖现有配置/素材/方案/字体）"
    for f in settings.txt layout.txt schedule.txt ticker.txt notify.txt; do
      [ -f "$BAK/$TAG/$f" ] && cp "$BAK/$TAG/$f" "$DIR/"
    done
    for d in schemes fonts content layouts; do
      [ -d "$BAK/$TAG/$d" ] && { rm -rf "$DIR/$d"; cp -r "$BAK/$TAG/$d" "$DIR/"; }
    done
    echo "[回滚] 完成。执行 bash stop.sh && bash start.sh 生效"
    ;;
  "")
    echo "用法:"
    echo "  bash upgrade.sh <新版包.tar.gz>   升级（先备份）"
    echo "  bash upgrade.sh rollback          查看备份"
    echo "  bash upgrade.sh rollback <时间戳> 回滚"
    ;;
  *)
    PKG="$1"
    [ -f "$PKG" ] || { echo "[错误] 包不存在: $PKG"; exit 1; }
    echo "[升级] 目标包: $PKG"
    # 先停机（令牌保证停得干净）
    [ -x "$DIR/stop.sh" ] && bash "$DIR/stop.sh" || true
    # 备份用户资产
    TAG="$(date +%Y%m%d-%H%M%S)"
    echo "[升级] 备份用户资产 ..."
    do_backup "$TAG"
    # 解包覆盖（包内为 mediaboard/ 根目录结构）
    case "$PKG" in
      *.tar.gz|*.tgz)
        if tar tzf "$PKG" 2>/dev/null | head -1 | grep -q "^mediaboard/"; then
          tar xzf "$PKG" -C "$(dirname "$DIR")"
        else
          tar xzf "$PKG" -C "$DIR" --strip-components=1
        fi ;;
      *) echo "[错误] 仅支持 tar.gz 包"; exit 1 ;;
    esac
    echo "[升级] 覆盖完成。回滚口令: bash upgrade.sh rollback $TAG"
    echo "[升级] 重启: bash start.sh （升级后首跑建议开自检页核对 24 项全绿）"
    ;;
esac
