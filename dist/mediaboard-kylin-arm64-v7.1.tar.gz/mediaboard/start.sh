#!/usr/bin/env bash
# MediaBoard v7 启动脚本（麒麟V10 离网多媒体看板 - LEDvision 同级编排 + 党团文化 + 排版库）
# 功能: 解析 layout.txt 多节目页/分区(12x12栅格 g:语法、@PANE 分屏归属、@LAYOUT 排版库引用)
#       -> 生成 playlist.js + fonts.json
#       + schemes/ 下每个方案目录生成 playlist-<方案>.js 与 schemes.js（多方案热切换）
#       -> PPT/Word/Excel 自动转图 -> 字体包枚举 -> chromium 全屏播放
# v7: @LAYOUT 排版库引用(layouts/ 24 种党政版式) / 倒计时主题 TOPIC/SINCE/UNIT/LABEL /
#     地图分区颜色透明度 REGION_ALPHA / 底图自定义 BG_FIT/BG_POS/BG_OPACITY/BG_BLUR/BG_DARKEN /
#     文本竖排 VERTICAL / 框型 30 种 / import-fonts.sh 系统字体导入。
# v6: 地图/分屏/多方案/框型库/磨砂参数/TRANSPARENT；schedule 新增 scheme: 指令。
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR" || exit 1

# ---------- v7.1 命令行参数覆盖（优先于 settings.txt）----------
# --scheme=党建文化   临时指定开机方案（不改 settings.txt）
# --duration=6        临时指定素材停留时长（秒）
# --test              等价 MEDIABOARD_TEST=1，只生成 playlist 不拉浏览器
ARG_SCHEME=""; ARG_DURATION=""
for a in "$@"; do
  case "$a" in
    --scheme=*) ARG_SCHEME="${a#--scheme=}";;
    --duration=*) ARG_DURATION="${a#--duration=}";;
    --test) MEDIABOARD_TEST=1;;
    *) ;;
  esac
done

# ---------- 读取设置（可被方案目录 settings.txt 覆盖） ----------
reset_defaults() {
  DURATION=10; SOUND=no; RELOAD_MINUTES=30; FILL=contain; TRANSITION=fade; TRANSITION_TIME=0.8
  TWINKLE=no; PAGE_DURATION=60; BGIMAGE=""; BGCOLOR=""; BGMUSIC=""; BGMUSIC_VOL=0.6
  PERF=high; KENBURNS=no; BGFX=""; SPLIT=""; SCHEME_NAME=""
  BG_FIT=cover; BG_POS=center; BG_OPACITY=""; BG_BLUR=""; BG_DARKEN=""
  TICKER_EFFECT=scroll-left; TICKER_SPEED=90; TICKER_FONT=""; TICKER_SIZE=5.5
  TICKER_COLOR="#ffff00"; TICKER_BGCOLOR="#1a3a6b"; TICKER_BOLD=yes; TICKER_HEIGHT=9
  TICKER_SEP=""; TICKER_MASK=yes; TICKER_POS=bottom; TICKER_OVERLAY=yes
  SCREEN_OFF=""; NOTIFY_MINUTES=5
}
apply_settings() { # $1=设置文件(存在才读)；只覆盖文件里出现的键
  local f="$1"
  [ -f "$f" ] || return 0
  local k v
  while IFS='=' read -r k v; do
    # 剥离行内注释（仅"空格+#"形式；颜色值 #1a3a6b 前面无空格，不受影响）
    v="$(printf '%s' "$v" | sed 's/[[:space:]]\{1,\}#.*$//; s/[[:space:]]*$//')"
    case "$k" in
      DURATION) DURATION="$v";;
      SOUND) SOUND="$v";;
      RELOAD_MINUTES) RELOAD_MINUTES="$v";;
      FILL) FILL="$v";;
      TRANSITION) TRANSITION="$v";;
      TRANSITION_TIME) TRANSITION_TIME="$v";;
      TWINKLE) TWINKLE="$v";;
      PAGE_DURATION) PAGE_DURATION="$v";;
      BGIMAGE) BGIMAGE="$v";;
      BGCOLOR) BGCOLOR="$v";;
      BGMUSIC) BGMUSIC="$v";;
      BGMUSIC_VOL) BGMUSIC_VOL="$v";;
      PERF) PERF="$v";;
      KENBURNS) KENBURNS="$v";;
      BGFX) BGFX="$v";;
      SPLIT) SPLIT="$v";;
      SCHEME) SCHEME_NAME="$(printf '%s' "$v" | tr -d ' ')";;
      BG_FIT) BG_FIT="$v";;
      BG_POS) BG_POS="$v";;
      BG_OPACITY) BG_OPACITY="$v";;
      BG_BLUR) BG_BLUR="$v";;
      BG_DARKEN) BG_DARKEN="$v";;
      TICKER_EFFECT) TICKER_EFFECT="$v";;
      TICKER_SPEED) TICKER_SPEED="$v";;
      TICKER_FONT) TICKER_FONT="$v";;
      TICKER_SIZE) TICKER_SIZE="$v";;
      TICKER_COLOR) TICKER_COLOR="$v";;
      TICKER_BGCOLOR) TICKER_BGCOLOR="$v";;
      TICKER_BOLD) TICKER_BOLD="$v";;
      TICKER_HEIGHT) TICKER_HEIGHT="$v";;
      TICKER_SEP) TICKER_SEP="$v";;
      TICKER_MASK) TICKER_MASK="$v";;
      TICKER_POS) TICKER_POS="$v";;
      TICKER_OVERLAY) TICKER_OVERLAY="$v";;
      SCREEN_OFF) SCREEN_OFF="$v";;
      NOTIFY_MINUTES) NOTIFY_MINUTES="$v";;
    esac
  done < "$f"
}
normalize_settings() {
  [ "$SOUND" = "yes" ] && SOUND_JS=true || SOUND_JS=false
  case "$FILL" in cover|fill|contain|scale-down) ;; *) FILL="contain";; esac
  case "$TRANSITION" in fade|fade-zoom|blur-fade|slide-soft|flip-3d|depth-zoom|random|cover-l|cover-r|cover-u|cover-d|push-l|push-r|push-u|push-d|rotate-3d|wipe-l|wipe-r|wipe-u|wipe-d|wipe-lu|wipe-ru|none) ;; *) TRANSITION="fade";; esac
  case "$TRANSITION_TIME" in *[!0-9.]*) TRANSITION_TIME=0.8;; esac
  case "$TWINKLE" in yes|1|true) TWINKLE_JS=true;; *) TWINKLE_JS=false;; esac
  case "$PAGE_DURATION" in *[!0-9.]*) PAGE_DURATION=60;; esac
  case "$TICKER_EFFECT" in scroll-left|scroll-up|blink|static|typewriter) ;; *) TICKER_EFFECT="scroll-left";; esac
  case "$TICKER_SPEED" in *[!0-9.]*) TICKER_SPEED=90;; esac
  case "$TICKER_SIZE" in *[!0-9.]*) TICKER_SIZE=5.5;; esac
  case "$TICKER_BOLD" in yes|1|true) TICKER_BOLD_JS=true;; *) TICKER_BOLD_JS=false;; esac
  case "$TICKER_HEIGHT" in *[!0-9.]*) TICKER_HEIGHT=9;; esac
  case "$TICKER_SEP" in "") TICKER_SEP="　　●　　";; esac
  case "$TICKER_MASK" in no|0|false) TICKER_MASK_JS=false;; *) TICKER_MASK_JS=true;; esac
  case "$TICKER_OVERLAY" in no|0|false) TICKER_OVERLAY_JS=false;; *) TICKER_OVERLAY_JS=true;; esac
  case "$NOTIFY_MINUTES" in *[!0-9.]*) NOTIFY_MINUTES=5;; esac
  case "$BGMUSIC_VOL" in *[!0-9.]*) BGMUSIC_VOL=0.6;; esac
  case "$BGFX" in aurora|gridmove|particles) ;; *) BGFX="";; esac
  case "$PERF" in high|mid|low) ;; *) PERF="high";; esac
  case "$KENBURNS" in yes|1|true) KENBURNS_JS=true;; *) KENBURNS_JS=false;; esac
  case "$SCREEN_OFF" in [0-2][0-9]:[0-5][0-9]-[0-2][0-9]:[0-5][0-9]) ;; *) SCREEN_OFF="";; esac
  # v7 底图自定义（仅 BGIMAGE 有意义时输出到 playlist）
  case "$BG_FIT" in cover|contain|fill|auto|100%\ 100%) ;; *) BG_FIT="cover";; esac
  case "$BG_POS" in center|top|bottom|left|right|top\ left|top\ right|bottom\ left|bottom\ right) ;; *) BG_POS="center";; esac
  case "$BG_OPACITY" in ""|*[!0-9.]*) BG_OPACITY="";; esac
  case "$BG_BLUR" in ""|*[!0-9.]*) BG_BLUR="";; esac
  case "$BG_DARKEN" in ""|*[!0-9.]*) BG_DARKEN="";; esac
  # v6 分屏模式（settings.txt: SPLIT=2H/2V/3H/3V/3T/3L/4G/4H/4V）
  case "$SPLIT" in 2H|2V|3H|3V|3T|3L|4G|4H|4V) ;; *) SPLIT="";; esac
  [ -n "$BGIMAGE" ] && [ ! -f "$BGIMAGE" ] && { echo "[设置] BGIMAGE 文件不存在, 忽略: $BGIMAGE"; BGIMAGE=""; }
  [ -n "$BGMUSIC" ] && [ ! -f "$BGMUSIC" ] && { echo "[设置] BGMUSIC 文件不存在, 忽略: $BGMUSIC"; }
}

# ---------- PPT/Word/Excel 转图片（有 WPS/LibreOffice 才执行） ----------
convert_doc() {
  local ppt="$1" base outdir d conv pdf
  base="$(basename "$ppt")"
  d="$(dirname "$ppt")"
  outdir="$d/converted/${base%.*}"
  mkdir -p "$outdir"
  conv=""
  for c in soffice libreoffice wpp wps; do
    command -v "$c" >/dev/null 2>&1 && conv="$c" && break
  done
  [ -z "$conv" ] && { echo "[转换] 无转换工具，跳过 $base（请在电脑上另存为图片后放入）"; return 1; }
  "$conv" --headless --convert-to pdf --outdir /tmp "$ppt" >/dev/null 2>&1
  pdf="/tmp/${base%.*}.pdf"
  [ -f "$pdf" ] || { echo "[转换] PDF 转换失败: $base"; return 1; }
  if command -v pdftoppm >/dev/null 2>&1; then
    pdftoppm -r 100 -jpeg "$pdf" "$outdir/slide" >/dev/null 2>&1
  elif command -v gs >/dev/null 2>&1; then
    gs -dNOPAUSE -dBATCH -sDEVICE=jpeg -r100 -sOutputFile="$outdir/slide-%02d.jpg" "$pdf" >/dev/null 2>&1
  else
    echo "[转换] 无 pdftoppm/gs，无法拆页: $base"; return 1
  fi
  rm -f "$pdf"
  echo "[转换] 已转换: $base -> $outdir/"
}
# v6: PPT/Word/Excel 转图同样覆盖 schemes/<方案>/content（多方案素材）
find content schemes -type f \( -iname "*.ppt" -o -iname "*.pptx" -o -iname "*.doc" -o -iname "*.docx" -o -iname "*.xls" -o -iname "*.xlsx" \) -not -path "*/converted/*" 2>/dev/null \
  | while IFS= read -r f; do convert_doc "$f"; done

# ---------- 素材枚举 ----------
emit_media() { # $1=目录, $2=maxdepth
  find "$1" -maxdepth "$2" -type f \
    \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.gif" \
       -o -iname "*.webp" -o -iname "*.bmp" -o -iname "*.mp4" -o -iname "*.webm" \
       -o -iname "*.ogg" -o -iname "*.mov" -o -iname "*.mkv" -o -iname "*.m4v" \) \
    2>/dev/null | LC_ALL=C sort | while IFS= read -r f; do
    printf '"%s",' "$(printf '%s' "$f" | esc)"
  done
}

esc() { sed 's/\\/\\\\/g; s/"/\\"/g'; }
# 文本转 JS 字符串: 保留换行为 \n 转义
escape_text() {
  sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' | awk 'BEGIN{ORS="\\n"} {print}'
}

# style.txt 键值 -> JS 属性片段（白名单 + 数值校验）
style_props() { # $1=分区名, $2=允许键列表(空格分隔)
  local f="$CONTENT_BASE/$1/style.txt" k v out="" keys=" $2 "
  [ -f "$f" ] || { printf ''; return; }
  while IFS='=' read -r k v; do
    case "$k" in ""|\#*) continue;; esac
    case "$keys" in *" $k "*) ;; *) continue;; esac
    [ -n "$v" ] || continue
    case "$k" in
      SIZE|SPEED|LINESPACING|PADDING|MARGIN|RADIUS|GROUPCOLS|REFRESH|BLUR|GLASS_ALPHA|GLASS_BLUR|MAP_TINT|MAP_BLUR|REGION_ALPHA)
        case "$v" in *[!0-9.]*) continue;; esac;;
      ZBG_FIT|ZBG_POS) ;;
      TARGET|SINCE)
        case "$v" in [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]*) ;; *) continue;; esac;;
      COUNTUP)
        case "$v" in 1|yes|true) v=true;; *) v=false;; esac;;
    esac
    case "$k" in
      COUNTUP) out="$out,countup:$v";;
      *) out="$out,$(printf '%s' "$k" | tr 'A-Z' 'a-z'):\"$(printf '%s' "$v" | esc)\"";;
    esac
  done < "$f"
  printf '%s' "$out"
}

# 分区级视觉/布局键（对所有窗口类型有效，放进 zone 对象本体）
# v7: 竖排文本 VERTICAL、分区底图 ZBG_FIT/ZBG_POS（框型 30 种同 v6 语法）
# v6: 框型库 FRAME(30种)/FRAME_COLOR/FRAME_COLOR2、磨砂参数 GLASS_ALPHA/GLASS_COLOR/GLASS_BLUR、
#     区域整体模糊 BLUR、全透明 TRANSPARENT、丝带标题栏 TITLEBAR_SHAPE/TITLEBAR_COLOR
ZONE_KEYS="PADDING MARGIN ALIGNV RADIUS CARD GRADIENT SHADOW STROKE TABNUM ICON DECOR GROUP GROUPCOLS LAYER OPACITY EDGE_MASK GRID_FX GRID_FX_ORDER TRANSITION BORDER TITLEBAR TITLEBAR_COLOR TITLEBAR_SHAPE TITLE TITLE_GLOW GLASS GLOW ZBG ZBG_FIT ZBG_POS FRAME FRAME_COLOR FRAME_COLOR2 BLUR TRANSPARENT GLASS_ALPHA GLASS_COLOR GLASS_BLUR"

# ---------- 分区条目生成 ----------
emit_zone() { # 参数: name zx zy zw zh zdur ztype
  local name="$1" zx="$2" zy="$3" zw="$4" zh="$5" zdur="$6" ztype="$7"
  local nesc props zprops tf content
  nesc="$(printf '%s' "$name" | esc)"
  zprops="$(style_props "$name" "$ZONE_KEYS")"
  case "$ztype" in
    文本|text)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(escape_text < "$tf")"
      props="$(style_props "$name" "FONT SIZE COLOR BGCOLOR BOLD ITALIC ALIGN EFFECT SPEED LINESPACING VERTICAL")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,text:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    时钟|clock)
      props="$(style_props "$name" "FORMAT MODE FONT SIZE COLOR BGCOLOR")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,clock:{%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "${props#,}"
      ;;
    计时|timer)
      props="$(style_props "$name" "TARGET SINCE TITLE TOPIC TOPIC_COLOR TOPIC_BG TOPIC_BG2 LABEL UNIT FONT SIZE COLOR BGCOLOR COUNTUP")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,countdown:{%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "${props#,}"
      ;;
    二维码|qr)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(tr -d '\r' < "$tf" | awk '{printf "%s\\n", $0}' | sed 's/\\n$//; s/\\/\\\\/g; s/"/\\"/g')"
      props="$(style_props "$name" "COLOR BGCOLOR TITLE ECL")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,qr:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    公告|notice)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(escape_text < "$tf")"
      props="$(style_props "$name" "TITLE COLOR BGCOLOR SIZE FONT ICON SPEED DATASRC REFRESH")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,notice:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    表格|table)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(escape_text < "$tf")"
      props="$(style_props "$name" "TITLE HEADER ZEBRA COLOR BGCOLOR SIZE FONT ICON ALIGN ACCENT BORDERCOLOR DATASRC REFRESH")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,table:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    数据|data|统计)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(escape_text < "$tf")"
      props="$(style_props "$name" "TITLE SIZE COLOR BGCOLOR VALUECOLOR BARCOLOR ACCENT FONT ICON COUNTUP DATASRC REFRESH")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,data:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    仪表|gauge)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(escape_text < "$tf")"
      props="$(style_props "$name" "VALUE LABEL MIN MAX UNIT COLORS RING TITLE SIZE COLOR BGCOLOR FONT ICON DATASRC REFRESH")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,gauge:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    天气|weather)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(escape_text < "$tf")"
      props="$(style_props "$name" "COLOR BGCOLOR SIZE FONT DATASRC REFRESH")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,weather:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    地图|map)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(escape_text < "$tf")"
      props="$(style_props "$name" "MAP_COLOR MAP_COLOR2 MAP_FILL MAP_TINT MAP_BLUR REGION_ALPHA TITLE")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,map:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    网页|web)
      tf="$CONTENT_BASE/$name/text.txt"
      content=""
      [ -f "$tf" ] && content="$(tr -d '\r\n ' < "$tf" | esc)"
      props="$(style_props "$name" "URL")"
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,web:{content:"%s"%s}}' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$content" "$props"
      ;;
    *)
      printf '{name:"%s",x:%s,y:%s,w:%s,h:%s%s,duration:%s,slides:[' \
        "$nesc" "$zx" "$zy" "$zw" "$zh" "$zprops" "$zdur"
      emit_media "$CONTENT_BASE/$name" 3
      printf ']}'
      ;;
  esac
}

# ---------- 生成 playlist（根方案或 schemes/<方案>） ----------
# 用法: gen_playlist <输出文件> <JS变量前缀(空=window.PLAYLIST)> <方案基目录>
# 基目录内读: settings.txt(已由调用方装载) / layout.txt / ticker.txt / notify.txt / content/
gen_playlist() {
  local out="$1" varprefix="$2" base="$3"
  CONTENT_BASE="$base/content"
  local TICKER_TEXT="" NOTIFY_TEXT=""
  [ -f "$base/ticker.txt" ] && TICKER_TEXT="$(escape_text < "$base/ticker.txt")"
  [ -f "$base/notify.txt" ] && NOTIFY_TEXT="$(tr '\r' ' ' < "$base/notify.txt" | tr '\n' ' ' | esc)"

  # v7 @LAYOUT=党政·左3中2右3 排版库引用：展开 layouts/<名>.txt 为内联分区行（可嵌套 5 层）
  expand_layout() {
    local f="$1" depth="${2:-0}" line inc
    [ "$depth" -gt 5 ] && { echo "[布局] 排版嵌套过深，忽略: $f" >&2; return 1; }
    [ -f "$f" ] || return 0
    while IFS= read -r line || [ -n "$line" ]; do
      line="$(printf '%s' "$line" | tr -d '\r')"
      case "$line" in
        @LAYOUT=*)
          inc="$(printf '%s' "${line#@LAYOUT=}" | tr -d ' ')"
          if [ -f "layouts/$inc.txt" ]; then
            expand_layout "layouts/$inc.txt" "$((depth + 1))"
          else
            echo "[布局] 排版不存在: layouts/$inc.txt" >&2
          fi
          ;;
        *) printf '%s\n' "$line";;
      esac
    done < "$f"
  }
  local LAYOUT_TMP=""
  if [ -f "$base/layout.txt" ]; then
    LAYOUT_TMP="$(mktemp /tmp/mb_layout.XXXXXX)"
    expand_layout "$base/layout.txt" > "$LAYOUT_TMP"
  fi

  local PAGE_ZONES="" PAGE_DUR="$PAGE_DURATION" PAGE_PLAYS="" PAGE_VALID="" PAGE_PANE=""
  flush_page() {
    [ -n "$PAGE_ZONES" ] || return 0
    local extra=""
    case "$PAGE_PLAYS" in ""|*[!0-9]*) ;; *) extra="$extra,plays:$PAGE_PLAYS";; esac
    case "$PAGE_VALID" in [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]~*) extra="$extra,valid:\"$PAGE_VALID\"";; esac
    # v6 @PANE=N：该页归属第 N 分屏（配合 settings SPLIT=2H/2V/…）
    case "$PAGE_PANE" in ""|*[!0-9]*) ;; *) extra="$extra,pane:$PAGE_PANE";; esac
    printf '{duration:%s,zones:[\n%s\n]%s},\n' "$PAGE_DUR" "$PAGE_ZONES" "$extra"
    PAGE_ZONES=""; PAGE_DUR="$PAGE_DURATION"; PAGE_PLAYS=""; PAGE_VALID=""; PAGE_PANE=""
  }

  {
    if [ -n "$varprefix" ]; then
      printf 'window["MB_PLAYLIST_%s"]=' "$varprefix"
    else
      printf 'window.PLAYLIST='
    fi
    echo "{"
    echo "duration:$DURATION,"
    echo "sound:$SOUND_JS,"
    echo "reloadMinutes:$RELOAD_MINUTES,"
    echo "fill:\"$FILL\","
    echo "transition:\"$TRANSITION\","
    echo "transitionTime:$TRANSITION_TIME,"
    echo "twinkle:$TWINKLE_JS,"
    echo "perf:\"$PERF\","
    echo "kenburns:$KENBURNS_JS,"
    # v6 分屏：SPLIT=2H/2V/3H/3V/3T/3L/4G/4H/4V（空=单屏常规播放）
    [ -n "$SPLIT" ] && echo "split:\"$SPLIT\","
    [ -n "$BGIMAGE" ] && {
      printf 'bgimage:"%s",' "$(printf '%s' "$BGIMAGE" | esc)"
      # v7 底图自定义可调
      printf 'bg_fit:"%s",bg_pos:"%s",' "$BG_FIT" "$BG_POS"
      [ -n "$BG_OPACITY" ] && printf 'bg_opacity:%s,' "$BG_OPACITY"
      [ -n "$BG_BLUR" ] && printf 'bg_blur:%s,' "$BG_BLUR"
      [ -n "$BG_DARKEN" ] && printf 'bg_darken:%s,' "$BG_DARKEN"
      echo ""
    }
    [ -n "$BGCOLOR" ] && echo "bgcolor:\"$(printf '%s' "$BGCOLOR" | esc)\","
    [ -n "$BGFX" ] && echo "bgfx:\"$BGFX\","
    [ -n "$BGMUSIC" ] && echo "bgmusic:\"$(printf '%s' "$BGMUSIC" | esc)\",bgmusicVol:$BGMUSIC_VOL,"
    [ -n "$SCREEN_OFF" ] && echo "screenOff:\"$SCREEN_OFF\","
    [ -n "$NOTIFY_TEXT" ] && printf 'notify:{text:"%s",minutes:%s},\n' "$NOTIFY_TEXT" "$NOTIFY_MINUTES"
    printf 'ticker:{text:"%s",effect:"%s",speed:%s,size:%s,color:"%s",bgcolor:"%s",bold:%s,height:%s,sep:"%s",mask:%s,overlay:%s,pos:"%s"' \
      "$TICKER_TEXT" "$TICKER_EFFECT" "$TICKER_SPEED" "$TICKER_SIZE" \
      "$(printf '%s' "$TICKER_COLOR" | esc)" "$(printf '%s' "$TICKER_BGCOLOR" | esc)" \
      "$TICKER_BOLD_JS" "$TICKER_HEIGHT" "$(printf '%s' "$TICKER_SEP" | esc)" "$TICKER_MASK_JS" "$TICKER_OVERLAY_JS" "$(printf '%s' "$TICKER_POS" | esc)"
    [ -n "$TICKER_FONT" ] && printf ',font:"%s"' "$(printf '%s' "$TICKER_FONT" | esc)"
    echo "},"
    # 字体包（全方案共享根目录 fonts/）
    printf 'fontfaces:['
    local found_font="" fam alias_name f fmt
    while IFS= read -r f; do
      [ -n "$f" ] || continue
      found_font="1"
      fam="$(basename "${f%.*}")"
      # fonts/FONTS.txt 可写「文件名=中文显示名」，用户 style.txt 里 FONT=思源黑体 常规 即可
      if [ -f fonts/FONTS.txt ]; then
        alias_name="$(grep -F "$(basename "$f")=" fonts/FONTS.txt 2>/dev/null | head -1 | cut -d= -f2-)"
        [ -n "$alias_name" ] && fam="$alias_name"
      fi
      case "${f##*.}" in
        ttf|TTF) fmt=truetype;;
        otf|OTF) fmt=opentype;;
        woff2|WOFF2) fmt=woff2;;
        *) fmt=woff;;
      esac
      printf '{family:"%s",url:"%s",format:"%s"},' \
        "$(printf '%s' "$fam" | esc)" "$(printf '%s' "$f" | esc)" "$fmt"
    done <<EOF
$(find fonts -maxdepth 1 -type f \( -iname "*.ttf" -o -iname "*.otf" -o -iname "*.woff" -o -iname "*.woff2" \) 2>/dev/null | LC_ALL=C sort)
EOF
    echo "],"
    # 定时指令表 schedule.txt（v5 扩展；v6 新增 scheme:名称 热切换方案）
    # 单点: HH:MM=play:N|pause|resume|screenoff|screenon|dim:N|notify:文字|ticker:文字|reload|scheme:名称
    # 时段: HH:MM-HH:MM=pages:1,3 时段内只在指定页间循环（跨天区间允许）
    echo "schedule:["
    if [ -f "$base/schedule.txt" ]; then
      local st sc rng_a rng_b pg pgn badpg pp pgarr
      while IFS='=' read -r st sc; do
        st="$(printf '%s' "$st" | tr -d ' \r')"
        sc="$(printf '%s' "$sc" | tr -d '\r')"
        sc="$(printf '%s' "$sc" | sed 's/[[:space:]]\{1,\}#.*$//')"
        case "$st" in ""|\#*) continue;; esac
        case "$st" in
          [0-2][0-9]:[0-5][0-9]-[0-2][0-9]:[0-5][0-9])
            # 时段节目单行
            rng_a="${st%%-*}"; rng_b="${st##*-}"
            pg="${sc#pages:}"
            pg="$(printf '%s' "$pg" | tr -d ' ')"
            case "$pg" in
              *[!0-9,\-]*) echo "[定时] 跳过非法页号: $st=$sc" >&2; continue;;
            esac
            pgn="$(printf '%s' "$pg" | tr ',' ' ')"
            badpg=0
            for pp in $pgn; do
              case "$pp" in ""|*[!0-9]*) badpg=1;; esac
            done
            [ "$badpg" = "1" ] && { echo "[定时] 跳过非法页号: $st=$sc" >&2; continue; }
            # 页号数组（1 基 -> 0 基）
            pgarr="$(printf '%s' "$pg" | awk -F, '{for(i=1;i<=NF;i++){if($i!="") printf "%d,", $i-1}}')"
            printf '{range:true,a:%s,b:%s,pageNos:[%s]},\n' \
              "$(( 10#${rng_a%%:*} * 60 + 10#${rng_a##*:} ))" \
              "$(( 10#${rng_b%%:*} * 60 + 10#${rng_b##*:} ))" \
              "${pgarr%,}"
            ;;
          [0-2][0-9]:[0-5][0-9])
            case "$sc" in
              play:*|pause|resume|screenoff|screenon|dim:*|notify:*|ticker:*|reload|scheme:*) ;;
              *) echo "[定时] 跳过未知指令: $sc" >&2; continue;;
            esac
            printf '{t:"%s",cmd:"%s"},\n' "$st" "$(printf '%s' "$sc" | esc)"
            ;;
          *) echo "[定时] 跳过非法时间行: $st=$sc" >&2; continue;;
        esac
      done < "$base/schedule.txt"
    fi
    echo "],"
    # 多节目页
    echo "pages:["
    local line name rest zx zy zw zh zdur ztype frag gr gc grs gcs gbad g
    if [ -f "$LAYOUT_TMP" ]; then
      while IFS= read -r line || [ -n "$line" ]; do
        line="$(printf '%s' "$line" | tr -d '\r')"
        case "$line" in ""|\#*) continue;; esac
        # 页级规则（写在页分隔符之后、该页分区之前）：
        #   @PLAYS=N 播N次后跳过(0=无限)；@VALID=起~止 日期有效期；@PANE=N 归属第 N 分屏
        case "$line" in
          @PLAYS=*) PAGE_PLAYS="${line#@PLAYS=}"; continue;;
          @VALID=*) PAGE_VALID="$(printf '%s' "${line#@VALID=}" | tr -d ' ')"; continue;;
          @PANE=*) PAGE_PANE="$(printf '%s' "${line#@PANE=}" | tr -d ' ')"; continue;;
        esac
        # 页分隔符: --- 或 --- 秒数
        case "$line" in
          ---*)
            flush_page
            PAGE_DUR="${line#---}"
            PAGE_DUR="$(printf '%s' "$PAGE_DUR" | tr -d ' ')"
            case "$PAGE_DUR" in *[!0-9.]*) PAGE_DUR="$PAGE_DURATION";; ""|0|0.*) PAGE_DUR="$PAGE_DURATION";; esac
            continue;;
        esac
        case "$line" in *=*) ;; *) echo "[布局] 跳过非法行: $line" >&2; continue;; esac
        name="$(printf '%s' "${line%%=*}" | tr -d ' ')"
        rest="$(printf '%s' "${line#*=}" | tr -d ' ')"
        zx=""; zy=""; zw=""; zh=""; zdur=""; ztype=""
        # 栅格语法: 名称=g:行,列,跨行,跨列[,秒][,类型]  （12x12 栅格）
        case "$rest" in
          g:*)
            g="${rest#g:}"
            gr="$(printf '%s' "$g" | cut -d, -f1)"
            gc="$(printf '%s' "$g" | cut -d, -f2)"
            grs="$(printf '%s' "$g" | cut -d, -f3)"
            gcs="$(printf '%s' "$g" | cut -d, -f4)"
            # 只校验前 4 个栅格字段（第 5/6 字段是秒数与类型名，允许中文/空）
            gbad=0
            case "$gr" in ""|*[!0-9]*) gbad=1;; esac
            case "$gc" in ""|*[!0-9]*) gbad=1;; esac
            [ -n "$grs" ] && case "$grs" in *[!0-9]*) gbad=1;; esac
            [ -n "$gcs" ] && case "$gcs" in *[!0-9]*) gbad=1;; esac
            [ "$gbad" = "1" ] && { echo "[布局] 跳过非法栅格行: $line" >&2; continue; }
            [ -z "$grs" ] && grs=1
            [ -z "$gcs" ] && gcs=1
            [ "$gr" -ge 1 ] 2>/dev/null && [ "$gr" -le 12 ] || { echo "[布局] 栅格行号越界(1-12): $line" >&2; continue; }
            [ "$gc" -ge 1 ] 2>/dev/null && [ "$gc" -le 12 ] || { echo "[布局] 栅格列号越界(1-12): $line" >&2; continue; }
            zdur="$(printf '%s' "$g" | cut -d, -f5)"
            ztype="$(printf '%s' "$g" | cut -d, -f6)"
            # 换算为百分比（12 列 x 12 行）
            zy="$(awk -v r="$gr" 'BEGIN{printf "%.2f", (r-1)*100/12}')"
            zx="$(awk -v c="$gc" 'BEGIN{printf "%.2f", (c-1)*100/12}')"
            zh="$(awk -v n="$grs" 'BEGIN{printf "%.2f", n*100/12}')"
            zw="$(awk -v n="$gcs" 'BEGIN{printf "%.2f", n*100/12}')"
            ;;
          *)
            IFS=',' read -r zx zy zw zh zdur ztype <<EOF
$rest
EOF
            case "$zx$zy$zw$zh" in *[!0-9.]*) echo "[布局] 跳过非法行: $line" >&2; continue;; esac
            ;;
        esac
        zdur="${zdur:-$DURATION}"
        case "$zdur" in *[!0-9.]*) zdur="$DURATION";; ""|.) zdur="$DURATION";; esac
        # 窗口类型: 第6字段显式指定优先; 否则按名称关键词自动推断; 兜底=文件
        case "$ztype" in
          文本|text|多行文本|单行文本) ztype="文本";;
          时钟|clock) ztype="时钟";;
          计时|timer|倒计时|countdown) ztype="计时";;
          二维码|qr) ztype="二维码";;
          公告|notice) ztype="公告";;
          表格|table) ztype="表格";;
          数据|data|统计) ztype="数据";;
          仪表|gauge) ztype="仪表";;
          天气|weather) ztype="天气";;
          地图|map) ztype="地图";;
          网页|web) ztype="网页";;
          文件|file|video|"") ztype="${ztype:-}"
            if [ -z "$ztype" ]; then
              case "$name" in
                *时钟*) ztype="时钟";;
                *计时*|*倒计时*) ztype="计时";;
                *二维码*|*扫码*) ztype="二维码";;
                *公告*) ztype="公告";;
                *表格*) ztype="表格";;
                *数据*|*统计*|*指标*) ztype="数据";;
                *仪表*) ztype="仪表";;
                *天气*) ztype="天气";;
                *地图*|*分布*) ztype="地图";;
                *网页*) ztype="网页";;
                *文本*|*文字*|*通知*) ztype="文本";;
                *) ztype="文件";;
              esac
            fi;;
        esac
        frag="$(emit_zone "$name" "$zx" "$zy" "$zw" "$zh" "$zdur" "$ztype")"
        PAGE_ZONES="$PAGE_ZONES$frag,
"
      done < "$LAYOUT_TMP"
    fi
    flush_page
    [ -n "$LAYOUT_TMP" ] && rm -f "$LAYOUT_TMP"
    echo "],"
    echo "slides:["
    emit_media "$CONTENT_BASE" 1
    echo "]"
    echo "};"
  } > "$out"
}

# ---------- 主流程：根方案 + schemes/ 多方案 ----------
reset_defaults
apply_settings settings.txt
# v7.1 命令行覆盖（见 start.sh 头部说明）
[ -n "$ARG_SCHEME" ] && SCHEME_NAME="$ARG_SCHEME"
[ -n "$ARG_DURATION" ] && { case "$ARG_DURATION" in *[!0-9.]*) ;; *) DURATION="$ARG_DURATION";; esac; }
normalize_settings
gen_playlist playlist.js "" "."
echo "[MediaBoard] playlist.js 已生成"

# v6 多方案：schemes/<方案名>/ 含 layout.txt(必需) + 可选 settings/ticker/notify/schedule/content
# 每个方案生成 playlist-<方案名>.js（变量 MB_PLAYLIST_<方案名>），索引汇总进 schemes.js
SCHEME_LIST=""
if [ -d schemes ]; then
  for sd in schemes/*/; do
    [ -d "$sd" ] || continue
    sname="$(basename "$sd")"
    [ -f "$sd/layout.txt" ] || { echo "[方案] 跳过（无 layout.txt）: $sname"; continue; }
    # 方案设置 = 根设置打底 + 方案目录 settings.txt 覆盖；
    # 背景视觉键(BGFX/BGIMAGE/BGMUSIC)不继承根配置——每个方案应有自己的背景风格
    reset_defaults
    apply_settings settings.txt
    BGFX=""; BGIMAGE=""; BGMUSIC=""
    apply_settings "$sd/settings.txt"
    normalize_settings
    skey="$(printf '%s' "$sname" | tr -d '"')"
    gen_playlist "playlist-$sname.js" "$skey" "$sd"
    echo "[方案] 已生成: playlist-$sname.js"
    SCHEME_LIST="$SCHEME_LIST$sname
"
  done
fi
# schemes.js：方案索引 + 开机方案（settings.txt 的 SCHEME=名称；URL ?scheme=名称 优先）
{
  printf 'window.SCHEMES=['
  first=1
  while IFS= read -r sname; do
    [ -n "$sname" ] || continue
    [ $first -eq 0 ] && printf ','
    first=0
    skey="$(printf '%s' "$sname" | tr -d '"')"
    printf '{name:"%s",file:"playlist-%s.js",key:"%s"}' \
      "$(printf '%s' "$skey" | esc)" "$(printf '%s' "$skey" | esc)" "$(printf '%s' "$skey" | esc)"
  done <<EOF
$SCHEME_LIST
EOF
  printf '];\n'
  # 开机方案：回到根设置读 SCHEME（方案里也写 SCHEME 无意义）；命令行 --scheme= 优先
  reset_defaults
  apply_settings settings.txt
  [ -n "$ARG_SCHEME" ] && SCHEME_NAME="$ARG_SCHEME"
  SCHEME_BOOT="$(printf '%s' "$SCHEME_NAME" | tr -d '"')"
  if [ -n "$SCHEME_BOOT" ]; then
    printf 'window.SCHEMES_ACTIVE="%s";\n' "$(printf '%s' "$SCHEME_BOOT" | esc)"
  fi
} > schemes.js
echo "[MediaBoard] schemes.js 已生成"

# fonts.json（编辑器字体下拉用）
{
  printf '{"fonts":['
  first=1
  while IFS= read -r f; do
    [ -n "$f" ] || continue
    fam="$(basename "${f%.*}")"
    [ $first -eq 0 ] && printf ','
    first=0
    printf '"%s"' "$(printf '%s' "$fam" | esc)"
  done <<EOF
$(find fonts -maxdepth 1 -type f \( -iname "*.ttf" -o -iname "*.otf" -o -iname "*.woff" -o -iname "*.woff2" \) 2>/dev/null | LC_ALL=C sort)
EOF
  printf ']}'
} > fonts.json
echo "[MediaBoard] fonts.json 已生成"

# ---------- 测试模式 ----------
[ "${MEDIABOARD_TEST:-0}" = "1" ] && exit 0

# ---------- 找浏览器 ----------
CHROME=""
for c in chromium-browser chromium google-chrome; do
  command -v "$c" >/dev/null 2>&1 && CHROME="$c" && break
done
if [ -z "$CHROME" ]; then
  echo "[错误] 找不到 chromium 浏览器，无法播放"; exit 1
fi
command -v xset >/dev/null 2>&1 && { xset s off 2>/dev/null; xset -dpms 2>/dev/null; }

# ---------- v7.1 运维链路：播出日志 / 停机令牌 / 进程组记录 ----------
mblog() { # $1=事件 $2=详情 —— 生命周期级 proof-of-play（JSONL，按天滚动+容量保护）
  mkdir -p "$DIR/logs" 2>/dev/null || return 0
  printf '{"t":"%s","ev":"%s","scheme":"%s","detail":"%s"}\n' \
    "$(date '+%Y-%m-%dT%H:%M:%S')" "$1" "${SCHEME_BOOT:-${SCHEME_NAME:-}}" "${2:-}" \
    >> "$DIR/logs/play.jsonl" 2>/dev/null || return 0
  # 容量保护：超 100MB 轮转归档（离网机器不带日志系统，自身收敛）
  local sz
  sz="$(wc -c < "$DIR/logs/play.jsonl" 2>/dev/null || echo 0)"
  if [ "${sz:-0}" -gt 104857600 ]; then
    mv "$DIR/logs/play.jsonl" "$DIR/logs/play-$(date +%Y%m%d-%H%M).jsonl" 2>/dev/null
    ls -1t "$DIR/logs"/play-*.jsonl 2>/dev/null | tail -n +8 | xargs -r rm -f 2>/dev/null
  fi
}
rm -f "$DIR/.stop"                      # A-05：清除历史停机令牌，看门狗恢复值守
echo $$ > "$DIR/.runpid"                 # A-05：记录主 PID，stop.sh 按进程组整体收敛
trap 'mblog exit "收到INT/TERM"; rm -f "$DIR/.runpid"; exit 0' INT TERM

# ---------- 看门狗循环（v7.1：令牌退出 + 重拉计数 + 每小时自截屏取证） ----------
RELAUNCH=0
LAST_SHOT=0
# 定时自截屏并入主循环（不再独立后台子进程，令牌退出即全链收敛；SNAPSHOT=no 关闭）
SNAPSHOT_ENABLED=0
[ "${SNAPSHOT:-yes}" != "no" ] && SNAPSHOT_ENABLED=1
[ "$SNAPSHOT_ENABLED" = 1 ] && mkdir -p "$DIR/logs/shots" 2>/dev/null
mblog start "duration=${DURATION}s perf=${PERF} transition=${TRANSITION}"
echo "[MediaBoard] 启动 $CHROME 全屏播放 (Ctrl+C 或 bash stop.sh 停止)"
echo "[MediaBoard] 配置编辑器: file://$DIR/editor.html   自检: file://$DIR/player.html?selftest=1"
echo "[MediaBoard] 播出日志: $DIR/logs/play.jsonl   取证打包: bash $DIR/collect.sh   状态: bash $DIR/status.sh"
while true; do
  # A-05 修复：停机令牌在位即退出（stop.sh touch .stop 后看门狗不再重拉）
  if [ -f "$DIR/.stop" ]; then
    mblog stop "token"
    echo "[MediaBoard] 检测到停机令牌 .stop，看门狗退出（重启用 bash start.sh）"
    rm -f "$DIR/.runpid" 2>/dev/null
    exit 0
  fi
  # 每小时自截屏（火后即忘，短生命周期 headless 实例；保留最近 48 张）
  if [ "$SNAPSHOT_ENABLED" = 1 ]; then
    NOW_S=$(date +%s)
    if [ "$((NOW_S - LAST_SHOT))" -ge 3600 ]; then
      LAST_SHOT=$NOW_S
      ("$CHROME" --headless --disable-gpu --hide-scrollbars \
        --screenshot="$DIR/logs/shots/$(date +%Y%m%d-%H%M).png" --window-size=1280,720 \
        "file://$DIR/player.html" >/dev/null 2>&1) &
      ( ls -1t "$DIR/logs/shots"/*.png 2>/dev/null | tail -n +49 | xargs -r rm -f 2>/dev/null ) &
    fi
  fi
  "$CHROME" --kiosk --noerrdialogs --disable-infobars \
    --no-first-run --no-default-browser-check \
    --allow-file-access-from-files \
    --disable-features=Translate,TranslateUI,TranslateNewUX \
    --disable-session-crashed-bubble --disable-restore-session-state \
    --disable-background-networking --disable-component-update \
    --force-device-scale-factor=1 --lang=zh-CN \
    --autoplay-policy=no-user-gesture-required \
    "file://$DIR/player.html" >/dev/null 2>&1
  RELAUNCH=$((RELAUNCH + 1))
  mblog relaunch "n=$RELAUNCH"
  sleep 3
done
