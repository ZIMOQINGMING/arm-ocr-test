#!/usr/bin/env bash
# MediaBoard 安装脚本：复制到 ~/mediaboard，设置开机自启
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/mediaboard"

# ---------- v7.1 环境前置自检（只警示不阻断，给出处置提示） ----------
echo ""
echo "===== 环境自检 ====="
case "$(uname -m)" in
  aarch64) echo "[OK] 架构: aarch64（麒麟 V10 目标平台）";;
  *) echo "[警告] 架构 $(uname -m) 非 aarch64，仅用于桌面调试，非目标交付环境";;
esac
CHROME_FOUND=""
for c in chromium-browser chromium google-chrome; do
  command -v "$c" >/dev/null 2>&1 && { CHROME_FOUND="$c"; break; }
done
if [ -n "$CHROME_FOUND" ]; then
  echo "[OK] 浏览器: $CHROME_FOUND"
  "$CHROME_FOUND" --version 2>/dev/null | sed 's/^/[OK] 浏览器版本: /'
  echo "        （建议 83.x；81/87 亦可）"
else
  echo "[警告] 未找到 chromium —— 请先在麒麟软件商店安装 Chromium 再运行 start.sh"
fi
if command -v fc-list >/dev/null 2>&1; then
  NZH="$(fc-list :lang=zh 2>/dev/null | wc -l)"
  if [ "${NZH:-0}" -gt 0 ]; then
    echo "[OK] 系统中文字体: ${NZH} 个族（回退安全）"
  else
    echo "[警告] 系统无中文字体 —— 离线包内 3 款字体仍可用（字体回退安全已验）"
  fi
fi
echo "[OK] 磁盘可用: $(df -h "$HOME" 2>/dev/null | tail -1 | awk '{print $4}')（建议 ≥ 500MB）"
echo ""

mkdir -p "$DEST"
cp -r "$SRC"/. "$DEST"/
chmod +x "$DEST"/start.sh "$DEST"/stop.sh "$DEST"/status.sh "$DEST"/collect.sh "$DEST"/upgrade.sh "$DEST"/import-fonts.sh
rm -f "$DEST"/.stop "$DEST"/.runpid 2>/dev/null || true

# 开机自启（UKUI/GNOME 通用 freedesktop 标准）
mkdir -p "$HOME/.config/autostart"
cat > "$HOME/.config/autostart/mediaboard.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=MediaBoard
Comment=离线多媒体播放板
Exec=$DEST/start.sh
X-GNOME-Autostart-enabled=true
EOF

# 桌面快捷方式（双击启动）
DESKTOP_DIR="$HOME/桌面"
[ -d "$DESKTOP_DIR" ] || DESKTOP_DIR="$HOME/Desktop"
cat > "$DESKTOP_DIR/启动播放板.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=启动播放板
Exec=$DEST/start.sh
Terminal=true
EOF
chmod +x "$DESKTOP_DIR/启动播放板.desktop" 2>/dev/null || true

echo ""
echo "安装完成 -> $DEST"
echo "下一步:"
echo "  1. 把图片/视频拷进 $DEST/content/ （按文件名顺序播放）"
echo "  2. 想套现成版式: cp -r \"$DEST/templates/企业信息发布/\"* \"$DEST/\"  然后改 content 下的文字"
echo "  3. 想可视化调界面: chromium --app=file://$DEST/editor.html"
echo "  4. 真机能力自检:   chromium --app=file://$DEST/player.html?selftest=1 （24 项全绿）"
echo "  5. 运行 bash $DEST/start.sh 开始播放（重启后自动播放）"
echo "  6. 日常运维: bash $DEST/status.sh 看状态 · bash $DEST/collect.sh 一键取证 · bash $DEST/upgrade.sh 升级回滚"
