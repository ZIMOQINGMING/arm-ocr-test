#!/usr/bin/env bash
# MediaBoard v7.1 状态查询（无人值守场景最便宜的运维入口）
# 输出：运行状态三态判定 / 开机方案 / 浏览器 PID / 看门狗 / 播出日志概况 / 磁盘占用
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"

PIDS="$(pgrep -f "player\.html" 2>/dev/null | tr '\n' ' ')"
STOP_TOKEN=0; [ -f "$DIR/.stop" ] && STOP_TOKEN=1
RUNPID=""; [ -f "$DIR/.runpid" ] && RUNPID="$(cat "$DIR/.runpid" 2>/dev/null)"
WD_ALIVE=0
[ -n "$RUNPID" ] && kill -0 "$RUNPID" 2>/dev/null && WD_ALIVE=1

SCHEME="$(sed -n 's/^SCHEME=//p' "$DIR/settings.txt" 2>/dev/null | tail -1 | tr -d '"' | tr -d ' ')"
[ -z "$SCHEME" ] && SCHEME="（未指定，按 URL/根方案默认）"

if [ -n "$PIDS" ] && [ "$STOP_TOKEN" = 0 ]; then
  STATUS="运行中"; TONE=""
elif [ -n "$PIDS" ] && [ "$STOP_TOKEN" = 1 ]; then
  STATUS="停机中（令牌在位，浏览器数秒内自止）"; TONE="warn"
elif [ -z "$PIDS" ] && [ "$STOP_TOKEN" = 1 ] && [ "$WD_ALIVE" = 1 ]; then
  STATUS="停机中（看门狗等待退出）"; TONE="warn"
elif [ -z "$PIDS" ] && [ "$STOP_TOKEN" = 0 ]; then
  STATUS="看门狗异常（无浏览器在播且无停机令牌 —— 请 bash start.sh 重启或 bash stop.sh 收敛）"; TONE="warn"
else
  STATUS="已停止"; TONE=""
fi

echo "===== MediaBoard 状态 ====="
echo "状态:   $STATUS"
echo "方案:   开机方案=$SCHEME"
echo "进程:   播放器 PID=[$PIDS]  看门狗 PID=${RUNPID:-（未记录）}"
echo "令牌:   $([ "$STOP_TOKEN" = 1 ] && echo '.stop 在位（已停或停机中）' || echo '无（可正常启动）')"
LOG="$DIR/logs/play.jsonl"
if [ -f "$LOG" ]; then
  BOOT="$(head -1 "$LOG" 2>/dev/null | sed 's/.*"t":"\([^"]*\)".*/\1/')"
  LAST="$(tail -1 "$LOG" 2>/dev/null)"
  N="$(wc -l < "$LOG" 2>/dev/null)"
  echo "日志:   $LOG（$N 条）"
  echo "        首条(本次起算): $BOOT"
  echo "        末条(最近事件): $LAST"
else
  echo "日志:   尚无播出日志（$LOG）"
fi
SNAP="$(ls -1 "$DIR/logs/shots" 2>/dev/null | wc -l)"
[ -n "$SNAP" ] && echo "截屏:   自截屏留证 $SNAP 张（logs/shots/）"
echo "磁盘:   $(du -sh "$DIR" 2>/dev/null | cut -f1)  $(df -h "$DIR" 2>/dev/null | tail -1 | awk '{print "可用"$4}')"
[ "$TONE" = "warn" ] && exit 2 || exit 0
