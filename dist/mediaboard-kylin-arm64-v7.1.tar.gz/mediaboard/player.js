/* MediaBoard v7 - 麒麟V10 离网多媒体看板（LEDvision 同级编排 + 党团文化 + 磨砂视觉 + 排版库版）
 * 依赖: 仅系统自带 chromium (83+)。无网络、无外部服务。qr.js 为本包自带(MIT)。
 * v7 新增: 框型库 30 种（新增 ticket/wave/leaf/slash/doubleline/tag/label/photo/film/screen/
 *   terminal/bubble/octagon/diamond/chevron/cornerfold/panel 十七种新框体） /
 *   地图分区颜色+分区透明度可调（text.txt 色:/明度: 行，style.txt REGION_ALPHA） /
 *   倒计时主题化（TOPIC/SINCE/UNIT/LABEL：安全生产100天等可编辑主题） /
 *   模板底图自定义（BG_FIT/BG_POS/BG_OPACITY/BG_BLUR/BG_DARKEN + 分区 ZBG_FIT/ZBG_POS） /
 *   文本竖排 VERTICAL=yes（党政竖联排版） / @LAYOUT 排版库引用（layouts/ 24 种党政版式）。
 * v6 新增: 党团宣传文化模式（红金模板/党团图标/丝带标题栏/鎏金装饰） /
 *   12 种磨砂半透底层模板（GLASS_ALPHA/GLASS_COLOR/GLASS_BLUR 参数化） /
 *   区域框型库 FRAME= 13 种（圆角/胶囊/斜切/对角切/拱门/梯形/书签/公文/角标/印章/丝带/六边/盾形） /
 *   地图窗（自定义 SVG + 域高亮呼吸 + 脉冲标记 + 底图模糊/压暗/透明叠加） /
 *   分屏播放（SPLIT + @PANE，各分屏独立轮播） / 多方案 schemes（热切换 + 定时 scheme: 指令） /
 *   分区 BLUR 整体模糊与 TRANSPARENT 全透明。
 * v5 新增: 表格窗/数据统计窗/仪表盘窗/天气窗/网页窗(本地HTML) /
 *   翻牌时钟·多行时钟 / 分区级转场覆盖+出场衔接(push/rotate) /
 *   GRID_FX 25块+顺序模式 / 分区边框·标题栏·背景图·玻璃拟态·发光字 /
 *   BGFX 动态背景(极光/网格/粒子) / 定时指令扩展(dim/notify/ticker/reload)
 *   + 时段节目单(HH:MM-HH:MM=pages:...) / notify.txt 热插播 /
 *   图片瀑布流 GROUP=waterfall。
 * 历史: v3 性能档位与视觉增强 / v4 图层合成与页级播放规则。
 */
(function () {
  "use strict";
  var P = window.PLAYLIST || {};
  var stage, msgBox;
  var pageIdx = 0, pageTimer = null, currentZones = [], pages = [];

  function setState(s) {
    var el = document.getElementById("mb-state");
    if (el) { el.textContent = s; }
  }
  window.addEventListener("error", function (e) {
    setState("error:" + (e.message || "unknown"));
  });

  function truthy(v) {
    return v === true || v === 1 || v === "1" || v === "yes" || v === "true";
  }
  function num(v, d) { var n = parseFloat(v); return isFinite(n) ? n : d; }
  function clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function isVideo(src) { return /\.(mp4|webm|ogg|ogv|mov|mkv|m4v)$/i.test(src); }
  function fontCss(o, dSize) {
    return (truthy(o.bold) ? "bold " : "") + (truthy(o.italic) ? "italic " : "")
      + num(o.size, dSize) + "vh '" + (o.font || "sans-serif")
      + "','Noto Sans CJK SC','WenQuanYi Micro Hei',sans-serif";
  }
  // 视觉增强片段（分区级 SHADOW/STROKE/TABNUM/GLOW，Chromium 83 全支持）
  function visCss(z) {
    var s = "";
    if (truthy(z.shadow) && !perfLow()) { s += "text-shadow:0 .25vh 1vh rgba(0,0,0,.65);"; }
    if (truthy(z.stroke)) { s += "-webkit-text-stroke:.14vh rgba(0,0,0,.4);"; }
    if (truthy(z.tabnum)) { s += "font-variant-numeric:tabular-nums;"; }
    // GLOW 霓虹发光字（当红显大屏效果；颜色可 GLOW=#hex，默认青色）
    if (z.glow != null && z.glow !== "" && !perfLow()) {
      var gc = String(truthy(z.glow) ? "" : z.glow).trim() || "#38e8ff";
      s += "text-shadow:0 0 .8vh " + gc + ",0 0 2.2vh " + gc + ",0 0 4.5vh " + gc + ";";
    }
    return s;
  }

  // ---------- 性能档位 ----------
  var PERF = P.perf || "high";
  function perfLow() { return PERF === "low"; }
  function perfMid() { return PERF === "mid"; }

  // ---------- 自定义字体包 ----------
  var fontsInjected = false;
  function injectFonts() {
    if (fontsInjected) { return; }
    fontsInjected = true;
    (P.fontfaces || []).forEach(function (f) {
      try {
        var s = document.createElement("style");
        s.textContent = "@font-face{font-family:'" + f.family + "';"
          + "src:url('" + f.url + "') format('" + (f.format || "truetype") + "');}";
        document.head.appendChild(s);
      } catch (e) {}
    });
  }
  injectFonts();

  // ---------- SVG 图标集（内联零依赖） ----------
  var ICONS = {
    info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="10.5" x2="12" y2="16"/><circle cx="12" cy="7" r="1.1" fill="currentColor" stroke="none"/>',
    warn: '<path d="M12 3 L22 20 L2 20 Z"/><line x1="12" y1="9.5" x2="12" y2="15"/><circle cx="12" cy="17.3" r="1" fill="currentColor" stroke="none"/>',
    star: '<path d="M12 2 L14.6 8.6 L21.5 9 L16 13.6 L18 20.5 L12 16.6 L6 20.5 L8 13.6 L2.5 9 L9.4 8.6 Z"/>',
    clock: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="12" x2="12" y2="6"/><line x1="12" y1="12" x2="16" y2="14"/>',
    horn: '<path d="M3 10 v4 h3 l5 4 V6 l-5 4 Z"/><path d="M15 9 a4 4 0 0 1 0 6"/><path d="M17.5 7 a7 7 0 0 1 0 10"/>',
    check: '<circle cx="12" cy="12" r="10"/><path d="M8 12 l3 3 l5 -6"/>',
    flag: '<path d="M5 3 v18"/><path d="M5 4 h12 l-3 4 l3 4 h-12"/>',
    // ---- v4 扩充：状态/箭头/业务类，纯几何路径，零依赖零字体 ----
    arrowR: '<line x1="4" y1="12" x2="20" y2="12"/><path d="M14 6 l6 6 l-6 6"/>',
    arrowL: '<line x1="20" y1="12" x2="4" y2="12"/><path d="M10 6 l-6 6 l6 6"/>',
    arrowUp: '<line x1="12" y1="20" x2="12" y2="4"/><path d="M6 10 l6 -6 l6 6"/>',
    arrowDown: '<line x1="12" y1="4" x2="12" y2="20"/><path d="M6 14 l6 6 l6 -6"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="3" x2="8" y2="7"/><line x1="16" y1="3" x2="16" y2="7"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21 a8 8 0 0 1 16 0"/>',
    phone: '<path d="M7 3 h10 v18 h-10 Z"/><line x1="11" y1="18" x2="13" y2="18"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7 l9 6 l9 -6"/>',
    pin: '<path d="M12 2 a7 7 0 0 1 7 7 c0 5 -7 13 -7 13 s-7 -8 -7 -13 a7 7 0 0 1 7 -7 Z"/><circle cx="12" cy="9" r="2.5"/>',
    chart: '<line x1="4" y1="20" x2="20" y2="20"/><rect x="6" y="12" width="3" height="8"/><rect x="11" y="7" width="3" height="13"/><rect x="16" y="10" width="3" height="10"/>',
    gear: '<line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/><circle cx="9" cy="7" r="2.1" fill="currentColor"/><circle cx="15" cy="12" r="2.1" fill="currentColor"/><circle cx="10" cy="17" r="2.1" fill="currentColor"/>',
    sun: '<circle cx="12" cy="12" r="4.2"/><path d="M12 2 v2.5 M12 19.5 v2.5 M2 12 h2.5 M19.5 12 h2.5 M4.9 4.9 l1.8 1.8 M17.3 17.3 l1.8 1.8 M19.1 4.9 l-1.8 1.8 M6.7 17.3 l-1.8 1.8"/>',
    moon: '<path d="M20 14 a8.5 8.5 0 1 1 -9.5 -11 a7 7 0 0 0 9.5 11 Z"/>',
    cloud: '<path d="M7 18 h10 a4 4 0 0 0 0 -8 a6 6 0 0 0 -11.6 1.6 A3.4 3.4 0 0 0 7 18 Z"/>',
    battery: '<rect x="2" y="8" width="17" height="8" rx="2"/><line x1="21" y1="11" x2="21" y2="13"/><rect x="4" y="10" width="9" height="4" fill="currentColor" stroke="none"/>',
    wifi: '<path d="M3 9 a14 14 0 0 1 18 0"/><path d="M6.5 12.5 a9 9 0 0 1 11 0"/><path d="M10 16 a4.2 4.2 0 0 1 4 0"/><circle cx="12" cy="19.2" r="1.1" fill="currentColor" stroke="none"/>',
    heart: '<path d="M12 20 C4 14.5 3 10 5.6 7.4 a4.4 4.4 0 0 1 6.4 .6 a4.4 4.4 0 0 1 6.4 -.6 C21 10 20 14.5 12 20 Z"/>',
    shield: '<path d="M12 3 l8 3 v6 c0 5 -4 8 -8 9 c-4 -1 -8 -4 -8 -9 V6 Z"/><path d="M8.5 12 l2.6 2.6 l4.6 -5"/>',
    fire: '<path d="M12 3 c1 4 5 5 5 9 a5 5 0 0 1 -10 0 c0 -2 1 -3 2 -4 c0 2 1 3 2 3 c1 -2 -1 -5 1 -8 Z"/>',
    doc: '<path d="M6 3 h8 l4 4 v14 h-12 Z"/><path d="M14 3 v4 h4"/><line x1="9" y1="12" x2="15" y2="12"/><line x1="9" y1="16" x2="15" y2="16"/>',
    speaker: '<rect x="5" y="9" width="4" height="6"/><path d="M9 9 l6 -4 v14 l-6 -4 Z"/><path d="M18 9 a4 4 0 0 1 0 6"/>',
    play: '<circle cx="12" cy="12" r="9.4"/><polygon points="10,7.6 17.4,12 10,16.4" fill="currentColor" stroke="none"/>',
    // ---- v5 天气窗扩充（纯几何路径） ----
    rain: '<path d="M7 14 h10 a4 4 0 0 0 0 -8 a6 6 0 0 0 -11.6 1.6 A3.4 3.4 0 0 0 7 14 Z"/><line x1="9" y1="17.5" x2="8" y2="20.5"/><line x1="13" y1="17.5" x2="12" y2="20.5"/><line x1="17" y1="17.5" x2="16" y2="20.5"/>',
    snow: '<path d="M7 14 h10 a4 4 0 0 0 0 -8 a6 6 0 0 0 -11.6 1.6 A3.4 3.4 0 0 0 7 14 Z"/><line x1="10" y1="17" x2="10" y2="21"/><line x1="8.4" y1="18" x2="11.6" y2="20"/><line x1="11.6" y1="18" x2="8.4" y2="20"/><line x1="15" y1="17" x2="15" y2="21"/><line x1="13.4" y1="18" x2="16.6" y2="20"/><line x1="16.6" y1="18" x2="13.4" y2="20"/>',
    fog: '<path d="M7 13 h10 a4 4 0 0 0 0 -8 a6 6 0 0 0 -11.6 1.6 A3.4 3.4 0 0 0 7 13 Z"/><line x1="5" y1="17" x2="17" y2="17"/><line x1="7" y1="20" x2="15" y2="20"/>',
    wind: '<path d="M4 9 h11 a2.6 2.6 0 1 0 -2.6 -2.6"/><path d="M4 13 h15 a2.8 2.8 0 1 1 -2.8 2.8"/><line x1="4" y1="5" x2="9" y2="5"/>',
    temp: '<line x1="12" y1="14" x2="12" y2="4"/><path d="M12 14 a3 3 0 1 0 0.1 0"/><path d="M12 4 l-1.6 2 h3.2 Z" fill="currentColor" stroke="none"/>'
  };
  // ---------- v6 党团宣传文化图标（纯几何路径，零依赖） ----------
  var ICONS6 = {
    starF: '<path d="M12 2 L14.6 8.6 L21.5 9 L16 13.6 L18 20.5 L12 16.6 L6 20.5 L8 13.6 L2.5 9 L9.4 8.6 Z" fill="currentColor" stroke="none"/>',
    torch: '<path d="M12 2 c2.4 1.6 4 4.4 4 7 0 2.2-1.2 3.8-2.6 4.6 h-2.8 C9.2 12.8 8 11.2 8 9 c0-2.6 1.6-5.4 4-7 Z"/><path d="M10 12 h4 v8 a2 2 0 0 1-4 0 Z"/><line x1="8" y1="21.5" x2="16" y2="21.5"/>',
    medal: '<circle cx="12" cy="9" r="5"/><path d="M9.2 13.4 l-2.2 8 5-3 5 3 -2.2-8"/><path d="M12 7 v4 M10.4 9 h3.2"/>',
    landmark: '<line x1="3" y1="20" x2="21" y2="20"/><rect x="5" y="15" width="14" height="5"/><rect x="9.5" y="10.5" width="5" height="4.5"/><path d="M4 10.5 h16 M12 5.5 v5 M8.5 8 h7"/><path d="M6 5.5 l6-3 6 3"/>',
    book: '<path d="M12 6 c-2-2-5.6-2-8-1.2 v13.4 c2.4-0.8 6-0.8 8 1.2 2-2 5.6-2 8-1.2 V4.8 C17.6 4 14 4 12 6 Z"/><line x1="12" y1="6" x2="12" y2="19.4"/>',
    dove: '<path d="M21 8 c-2.5-1-4.5-.4-5.8 1.4 C14 6.5 10 6 8 8 c-2.4 2.4-1.4 6 .8 7.6 L6 19 l4.4-1.6 c4.6.6 8.6-2.6 10.6-7.4 Z"/><path d="M4 19 l2.6-1"/>'
  };
  for (var ik in ICONS6) { if (ICONS6.hasOwnProperty(ik)) { ICONS[ik] = ICONS6[ik]; } }
  function iconSvg(name, hVh) {
    if (!ICONS[name]) { return null; }
    var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", hVh + "vh");
    svg.setAttribute("height", hVh + "vh");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.7");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("stroke-linecap", "round");
    svg.innerHTML = ICONS[name];
    return svg;
  }
  // ---------- v6 框型库 / 磨砂玻璃 / 地图窗 全局样式（一次性注入） ----------
  // FRAME= 30 种（v6 13 种 + v7 扩充 17 种）:
  //   基础族: rounded capsule notch cutcorner arch trapezoid bookmark doc bracket stamp ribbon hexagon shield
  //   v7 新增: ticket wave leaf slash doubleline tag label photo film screen terminal bubble
  //            octagon diamond chevron cornerfold panel
  // 颜色用 FRAME_COLOR=#hex 与 FRAME_COLOR2=#hex 定制（默认鎏金/正红）。
  var FRAMES = "rounded capsule notch cutcorner arch trapezoid bookmark doc bracket stamp ribbon hexagon shield "
    + "ticket wave leaf slash doubleline tag label photo film screen terminal bubble "
    + "octagon diamond chevron cornerfold panel".split(" ");
  var FRAMES_CLIP = { notch: 1, cutcorner: 1, trapezoid: 1, ribbon: 1, hexagon: 1, shield: 1,
    slash: 1, tag: 1, octagon: 1, diamond: 1, chevron: 1, cornerfold: 1 };
  function frameOf(z) {
    var f = String(z.frame || "").trim().toLowerCase();
    return FRAMES.indexOf(f) >= 0 ? f : "";
  }
  function hexToRgba(hex, alpha) {
    var m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex || "").trim());
    if (!m) { return null; }
    var hx = m[1];
    if (hx.length === 3) { hx = hx.charAt(0) + hx.charAt(0) + hx.charAt(1) + hx.charAt(1) + hx.charAt(2) + hx.charAt(2); }
    return "rgba(" + parseInt(hx.slice(0, 2), 16) + "," + parseInt(hx.slice(2, 4), 16) + "," + parseInt(hx.slice(4, 6), 16) + "," + alpha + ")";
  }
  function ensureFrameCss() {
    if (ensureFrameCss._done) { return; }
    ensureFrameCss._done = true;
    var st = document.createElement("style");
    st.textContent = ""
      /* 磨砂玻璃卡（v6 参数化：GLASS_ALPHA/GLASS_COLOR/GLASS_BLUR） */
      + ".mb-glass{background-image:linear-gradient(160deg,rgba(255,255,255,.10),rgba(255,255,255,0) 40%);"
      + "box-shadow:inset 0 0 0 1px rgba(255,255,255,.18),0 0 0 1px rgba(0,0,0,.35),0 1vh 3vh rgba(0,0,0,.45);}"
      + ".mb-glass::before{content:'';position:absolute;top:0;left:1.2vh;right:1.2vh;height:.25vh;z-index:1;pointer-events:none;"
      + "background:linear-gradient(90deg,transparent,var(--mbfa,#4d9fff),transparent);opacity:.8;}"
      /* 框型库 */
      + ".mb-f-capsule{border-radius:99vh;}"
      + ".mb-f-notch{clip-path:polygon(0 0,100% 0,100% calc(100% - 3.5vh),calc(100% - 3.5vh) 100%,0 100%);}"
      + ".mb-f-cutcorner{clip-path:polygon(0 0,calc(100% - 3vh) 0,100% 3vh,100% 100%,3vh 100%,0 calc(100% - 3vh));}"
      + ".mb-f-arch{border-radius:1.2vh 1.2vh 50% 50%/1.2vh 1.2vh 22% 22%;}"
      + ".mb-f-trapezoid{clip-path:polygon(3% 0,97% 0,100% 100%,0 100%);}"
      + ".mb-f-bookmark{border-radius:1vh 1vh 0 0;}"
      + ".mb-f-doc::before{content:'';position:absolute;top:1vh;bottom:1vh;left:.6vh;width:.45vh;border-radius:99vh;z-index:1;pointer-events:none;"
      + "background:linear-gradient(180deg,var(--mbf2,#c8102e),var(--mbf,#ffd54a));}"
      + ".mb-f-bracket::before{content:'';position:absolute;top:1vh;left:1vh;width:2.2vh;height:2.2vh;z-index:1;pointer-events:none;"
      + "border-top:.3vh solid var(--mbf,#ffd54a);border-left:.3vh solid var(--mbf,#ffd54a);}"
      + ".mb-f-bracket::after{content:'';position:absolute;bottom:1vh;right:1vh;width:2.2vh;height:2.2vh;z-index:1;pointer-events:none;"
      + "border-bottom:.3vh solid var(--mbf,#ffd54a);border-right:.3vh solid var(--mbf,#ffd54a);}"
      + ".mb-f-stamp{border:.3vh solid var(--mbf,#ffd54a);box-sizing:border-box;}"
      + ".mb-f-stamp::after{content:'';position:absolute;top:.8vh;left:.8vh;right:.8vh;bottom:.8vh;z-index:1;pointer-events:none;"
      + "border:.15vh dashed var(--mbf,#ffd54a);border-radius:inherit;}"
      + ".mb-f-ribbon{clip-path:polygon(0 0,100% 0,96% 100%,4% 100%);"
      + "background:linear-gradient(90deg,var(--mbf2,#c8102e),var(--mbf,#ffd54a))!important;}"
      + ".mb-f-hexagon{clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%);}"
      + ".mb-f-shield{clip-path:polygon(0 0,100% 0,100% 62%,50% 100%,0 62%);}"
      /* ---- v7 框体扩充（17 种，总数 30） ---- */
      + ".mb-f-ticket{border-radius:1.6vh;}"
      + ".mb-f-ticket::before{content:'';position:absolute;top:14%;bottom:14%;left:50%;width:0;"
      + "border-left:.22vh dashed var(--mbf,#ffd54a);z-index:1;pointer-events:none;}"
      + ".mb-f-wave{border-radius:1.4vh 1.4vh 0 0;}"
      + ".mb-f-wave::after{content:'';position:absolute;left:-.4vh;right:-.4vh;bottom:-1.1vh;height:2.2vh;"
      + "z-index:1;pointer-events:none;background:radial-gradient(circle at 1vh 0,var(--mbf,#ffd54a) .95vh,transparent 1.05vh);"
      + "background-size:2vh 2.2vh;background-repeat:repeat-x;}"
      + ".mb-f-leaf{border-radius:0 50% 50% 50%/0 50% 50% 50%;}"
      + ".mb-f-slash{clip-path:polygon(14% 0,100% 0,86% 100%,0 100%);}"
      + ".mb-f-doubleline{box-shadow:inset 0 0 0 .22vh var(--mbf,#ffd54a);}"
      + ".mb-f-doubleline::before{content:'';position:absolute;top:.55vh;bottom:.55vh;left:.55vh;right:.55vh;"
      + "border:.08vh solid var(--mbf,#ffd54a);border-radius:inherit;z-index:1;pointer-events:none;}"
      + ".mb-f-tag{clip-path:polygon(0 0,84% 0,100% 50%,84% 100%,0 100%);}"
      + ".mb-f-label{border-radius:.6vh;}"
      + ".mb-f-label::before{content:'';position:absolute;top:-1.1vh;left:7%;width:22%;height:2.2vh;"
      + "background:var(--mbf2,#c8102e);border-radius:.4vh .4vh 0 0;z-index:1;pointer-events:none;}"
      + ".mb-f-photo{border:.6vh solid #f2f0eb;border-bottom:3.2vh solid #f2f0eb;}"
      + ".mb-f-film::before,.mb-f-film::after{content:'';position:absolute;left:0;right:0;height:.7vh;"
      + "z-index:1;pointer-events:none;background:repeating-linear-gradient(90deg,transparent 0 1.1vh,var(--mbf,#ffd54a) 1.1vh 2.2vh);}"
      + ".mb-f-film::before{top:.5vh;}.mb-f-film::after{bottom:.5vh;}"
      + ".mb-f-screen{border-radius:3vh 3vh 1vh 1vh;}"
      + ".mb-f-screen::before{content:'';position:absolute;top:.8vh;left:50%;width:.7vh;height:.7vh;border-radius:50%;"
      + "background:var(--mbf2,#c8102e);transform:translateX(-50%);z-index:1;pointer-events:none;}"
      + ".mb-f-terminal{border-radius:1vh 1vh 0 0;}"
      + ".mb-f-terminal::after{content:'';position:absolute;top:0;left:0;right:0;height:2.6vh;"
      + "background:rgba(0,0,0,.55);border-radius:1vh 1vh 0 0;z-index:1;pointer-events:none;}"
      + ".mb-f-terminal::before{content:'';position:absolute;top:.95vh;left:.8vh;width:.55vh;height:.55vh;border-radius:50%;"
      + "background:#ff5f56;box-shadow:.85vh 0 #ffbd2e,1.7vh 0 #27c93f;z-index:2;pointer-events:none;}"
      + ".mb-f-bubble{border-radius:2.4vh;}"
      + ".mb-f-bubble::after{content:'';position:absolute;left:14%;bottom:-1.3vh;width:0;height:0;"
      + "border-left:.95vh solid transparent;border-right:.95vh solid transparent;"
      + "border-top:1.35vh solid var(--mbf2,#c8102e);z-index:1;pointer-events:none;}"
      + ".mb-f-octagon{clip-path:polygon(30% 0,70% 0,100% 30%,100% 70%,70% 100%,30% 100%,0 70%,0 30%);}"
      + ".mb-f-diamond{clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);}"
      + ".mb-f-chevron{clip-path:polygon(0 0,100% 0,100% 76%,50% 100%,0 76%);}"
      + ".mb-f-cornerfold{clip-path:polygon(0 0,calc(100% - 3.4vh) 0,100% 3.4vh,100% 100%,0 100%);}"
      + ".mb-f-cornerfold::after{content:'';position:absolute;top:0;right:0;width:3.4vh;height:3.4vh;"
      + "background:linear-gradient(135deg,transparent 49%,var(--mbf,#ffd54a) 50%);z-index:1;pointer-events:none;}"
      + ".mb-f-panel{border:.26vh solid var(--mbf,#ffd54a);}"
      + ".mb-f-panel::before{content:'';position:absolute;top:.8vh;left:.8vh;right:.8vh;bottom:.8vh;z-index:1;"
      + "pointer-events:none;background:radial-gradient(circle at 0 0,var(--mbf,#ffd54a) .34vh,transparent .4vh),"
      + "radial-gradient(circle at 100% 0,var(--mbf,#ffd54a) .34vh,transparent .4vh),"
      + "radial-gradient(circle at 0 100%,var(--mbf,#ffd54a) .34vh,transparent .4vh),"
      + "radial-gradient(circle at 100% 100%,var(--mbf,#ffd54a) .34vh,transparent .4vh);}"
      /* 地图窗 */
      + ".mb-map{position:absolute;top:0;left:0;width:100%;height:100%;overflow:hidden;}"
      + ".mb-map-canvas{position:absolute;top:0;left:0;width:100%;height:100%;}"
      + ".mb-map-canvas svg{width:100%;height:100%;display:block;}"
      + ".mb-map [data-region]{fill:var(--mbmfill,rgba(90,140,255,.10));stroke:var(--mbmstroke,rgba(230,240,255,.30));"
      + "stroke-width:1.6px;transition:fill .4s;}"
      + ".mb-map .mb-map-hi{fill:var(--mbmhi,rgba(255,213,74,.20));stroke:var(--mbma,#ffd54a);stroke-width:2.2px;"
      + "filter:drop-shadow(0 0 6px var(--mbma,#ffd54a));animation:mbmap-breathe 3s ease-in-out infinite;}"
      + "@keyframes mbmap-breathe{0%,100%{opacity:.82}50%{opacity:1}}"
      + ".mb-map-pin{position:absolute;width:1.1vh;height:1.1vh;border-radius:50%;transform:translate(-50%,-50%);"
      + "background:var(--mbma2,#c8102e);box-shadow:0 0 .8vh var(--mbma2,#c8102e);}"
      + ".mb-map-pin::before{content:'';position:absolute;top:50%;left:50%;width:1.1vh;height:1.1vh;border-radius:50%;"
      + "border:.14vh solid var(--mbma2,#c8102e);transform:translate(-50%,-50%);animation:mbmap-pulse 2s ease-out infinite;}"
      + "@keyframes mbmap-pulse{0%{transform:translate(-50%,-50%) scale(1);opacity:.9}100%{transform:translate(-50%,-50%) scale(4.5);opacity:0}}"
      + ".mb-map-label{position:absolute;transform:translate(-50%,130%);white-space:nowrap;z-index:3;"
      + "font:1.5vh 'Noto Sans CJK SC','WenQuanYi Micro Hei',sans-serif;color:#fff;"
      + "background:rgba(8,12,22,.55);padding:.25vh .8vh;border-radius:99vh;"
      + "box-shadow:inset 0 0 0 1px rgba(255,255,255,.16);}"
      + ".mb-map-legend{position:absolute;right:1vh;bottom:1vh;display:flex;z-index:3;}"
      + ".mb-map-legend span{display:flex;align-items:center;margin-left:1vh;"
      + "font:1.4vh 'Noto Sans CJK SC','WenQuanYi Micro Hei',sans-serif;color:#dfe8f5;"
      + "background:rgba(8,12,22,.5);padding:.3vh 1vh;border-radius:99vh;box-shadow:inset 0 0 0 1px rgba(255,255,255,.14);}"
      + ".mb-map-legend i{display:inline-block;width:1.1vh;height:1.1vh;border-radius:50%;margin-right:.5vh;background:var(--mbma2,#c8102e);}"
      + ".mb-map-title{position:absolute;top:1vh;left:50%;transform:translateX(-50%);z-index:3;white-space:nowrap;"
      + "font:bold 2vh 'Noto Sans CJK SC','WenQuanYi Micro Hei',sans-serif;color:#fff;"
      + "background:rgba(8,12,22,.55);padding:.4vh 1.6vh;border-radius:99vh;"
      + "box-shadow:inset 0 0 0 1px rgba(255,255,255,.16);}"
      /* 分屏容器 */
      + ".mb-pane{position:absolute;overflow:hidden;box-shadow:0 0 0 .12vh rgba(160,190,230,.10);}";
    document.head.appendChild(st);
  }
  ensureFrameCss();

  // 装饰线 / 角标（伪元素式附加 div，零成本精致度）
  function applyDecor(z, el) {
    if (z.decor === "line") {
      var ln = document.createElement("div");
      ln.style.cssText = "position:absolute;top:0;left:0;width:100%;height:.5vh;"
        + "background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgba(255,255,255,.85) 18%,rgba(255,255,255,0) 90%);z-index:2;pointer-events:none;";
      el.appendChild(ln);
    } else if (z.decor === "corner") {
      ["t l", "t r", "b l", "b r"].forEach(function (pos) {
        var d = document.createElement("div");
        var t = pos.charAt(0) === "t", l = pos.charAt(2) === "l";
        d.style.cssText = "position:absolute;" + (t ? "top:0.8vh;" : "bottom:0.8vh;")
          + (l ? "left:0.8vh;" : "right:0.8vh;") + "width:2.2vh;height:2.2vh;pointer-events:none;"
          + "border-" + (t ? "top" : "bottom") + ":2px solid rgba(255,255,255,.55);"
          + "border-" + (l ? "left" : "right") + ":2px solid rgba(255,255,255,.55);";
        el.appendChild(d);
      });
    } else if (z.decor === "goldline") {
      // v6 鎏金双线（党团红金模板点睛）
      ["0", "calc(100% - .4vh)"].forEach(function (tp) {
        var ln = document.createElement("div");
        ln.style.cssText = "position:absolute;top:" + tp + ";left:0;width:100%;height:.4vh;"
          + "background:linear-gradient(90deg,rgba(255,213,74,0) 8%,#ffd54a 50%,rgba(255,213,74,0) 92%);"
          + "z-index:2;pointer-events:none;";
        el.appendChild(ln);
      });
    } else if (z.decor === "star") {
      // v6 五角星角饰（党建/荣誉分区）
      var si = iconSvg("starF", 3.2);
      if (si) {
        si.style.cssText += "position:absolute;top:1vh;right:1.2vh;color:#ffd54a;z-index:2;pointer-events:none;";
        el.appendChild(si);
      }
    } else if (z.decor === "redveil") {
      // v6 红色薄纱滤镜（图片统一压红，党团宣传整体色调统一）
      var v = document.createElement("div");
      v.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
        + "background:linear-gradient(160deg,rgba(200,16,46,.14),rgba(120,10,25,.10));"
        + "mix-blend-mode:multiply;z-index:1;pointer-events:none;";
      el.appendChild(v);
    }
  }

  // ---------- 通用跑马灯 ----------
  function makeMarquee(host, inner, opts) {
    var speed = Math.max(5, num(opts.speed, opts.vertical ? 40 : 90));
    var anim = null;
    function stop() { if (anim) { try { anim.cancel(); } catch (e) {} anim = null; } }
    function build() {
      stop();
      // v5：同宿主元素重建时先取消上一次的无限动画（避免双动画叠加）
      if (inner._mbAnim) { try { inner._mbAnim.cancel(); } catch (e) {} }
      var probe = document.createElement("div");
      probe.style.cssText = "position:absolute;visibility:hidden;pointer-events:none;white-space:nowrap;font:" + (opts.font || "");
      host.appendChild(probe);
      var unit, dist, i, d;
      if (opts.vertical) {
        opts.lines.forEach(function (ln) {
          d = document.createElement("div");
          d.style.whiteSpace = "nowrap";
          d.textContent = ln;
          probe.appendChild(d);
        });
        unit = probe.offsetHeight;
        if (unit <= 0) { host.removeChild(probe); return; }
        // fromTop: 内容已在顶部，滚一整份高度即可循环；否则从底边进场
        dist = opts.fromTop ? unit : host.clientHeight + unit;
        inner.innerHTML = "";
        var n = Math.min(200, Math.ceil(dist / unit) + 1);
        for (i = 0; i < n; i++) {
          opts.lines.forEach(function (ln) {
            d = document.createElement("div");
            d.style.whiteSpace = "nowrap";
            d.textContent = ln;
            inner.appendChild(d);
          });
        }
        anim = inner.animate(
          [{ transform: "translateY(" + (opts.fromTop ? 0 : host.clientHeight) + "px)" }, { transform: "translateY(" + (-unit) + "px)" }],
          { duration: dist / speed * 1000, iterations: Infinity, easing: "linear" });
        inner._mbAnim = anim;
      } else {
        var line = opts.lines.join(opts.sep != null ? String(opts.sep) : "　　") + (opts.sep != null ? String(opts.sep) : "　　");
        probe.textContent = line;
        unit = probe.offsetWidth;
        if (unit <= 0) { host.removeChild(probe); return; }
        dist = host.clientWidth + unit;
        var rep = Math.min(200, Math.ceil(dist / unit) + 1);
        inner.textContent = new Array(rep + 1).join(line);
        anim = inner.animate(
          [{ transform: "translateX(" + host.clientWidth + "px)" }, { transform: "translateX(" + (-unit) + "px)" }],
          { duration: dist / speed * 1000, iterations: Infinity, easing: "linear" });
        inner._mbAnim = anim;
      }
      host.removeChild(probe);
    }
    var t0 = setTimeout(build, 60);
    if (document.fonts && document.fonts.ready && document.fonts.ready.then) {
      document.fonts.ready.then(function () { clearTimeout(t0); build(); });
    }
    return { rebuild: build };
  }

  // ---------- 切换特效（22 种；v5 增 push 推挤与 rotate-3d，出场同族衔接） ----------
  var TLIST = ["fade", "fade-zoom", "blur-fade", "slide-soft", "flip-3d", "depth-zoom",
    "cover-l", "cover-r", "cover-u", "cover-d",
    "push-l", "push-r", "push-u", "push-d", "rotate-3d",
    "wipe-l", "wipe-r", "wipe-u", "wipe-d", "wipe-lu", "wipe-ru"];
  function pickTransition(z) {
    // 分区级 TRANSITION 覆盖全局；global SETTINGS 仍是默认
    var t = (z && z.transition) || P.transition || "fade";
    if (perfLow()) { return "fade"; }              // 低档位统一降级为淡入淡出
    if (perfMid() && (t === "blur-fade" || t === "flip-3d" || t === "depth-zoom" || t === "rotate-3d")) { return "fade"; } // 中档位重转场降级
    if (t === "random") { return TLIST[Math.floor(Math.random() * TLIST.length)]; }
    return TLIST.indexOf(t) >= 0 ? t : "fade";
  }
  var EASE_STD = "cubic-bezier(.4,0,.2,1)";
  function animFrames(eff) {
    switch (eff) {
      case "fade-zoom": return [{ opacity: 0, transform: "scale(1.06)" }, { opacity: 1, transform: "scale(1)" }];
      case "blur-fade": return [{ opacity: 0, filter: "blur(14px)" }, { opacity: 1, filter: "blur(0px)" }];
      case "slide-soft": return [{ opacity: 0, transform: "translateX(4%)" }, { opacity: 1, transform: "translateX(0)" }];
      case "flip-3d": return [{ opacity: 0, transform: "perspective(1200px) rotateY(58deg)" },
        { opacity: 1, transform: "perspective(1200px) rotateY(0deg)" }];
      case "depth-zoom": return [{ opacity: 0, transform: "perspective(900px) translateZ(-260px)" },
        { opacity: 1, transform: "perspective(900px) translateZ(0)" }];
      case "cover-l": return [{ transform: "translateX(-100%)" }, { transform: "translateX(0)" }];
      case "cover-r": return [{ transform: "translateX(100%)" }, { transform: "translateX(0)" }];
      case "cover-u": return [{ transform: "translateY(-100%)" }, { transform: "translateY(0)" }];
      case "cover-d": return [{ transform: "translateY(100%)" }, { transform: "translateY(0)" }];
      // push：新素材推进来、旧素材同时退出（LEDvision「衔接」式同步出场）
      case "push-l": return [{ transform: "translateX(100%)" }, { transform: "translateX(0)" }];
      case "push-r": return [{ transform: "translateX(-100%)" }, { transform: "translateX(0)" }];
      case "push-u": return [{ transform: "translateY(100%)" }, { transform: "translateY(0)" }];
      case "push-d": return [{ transform: "translateY(-100%)" }, { transform: "translateY(0)" }];
      case "rotate-3d": return [{ opacity: 0, transform: "perspective(1100px) rotateX(52deg) translateY(14%)" },
        { opacity: 1, transform: "perspective(1100px) rotateX(0deg) translateY(0)" }];
      case "wipe-l": return [{ clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0 0 0)" }];
      case "wipe-r": return [{ clipPath: "inset(0 0 0 100%)" }, { clipPath: "inset(0 0 0 0)" }];
      case "wipe-u": return [{ clipPath: "inset(0 0 100% 0)" }, { clipPath: "inset(0 0 0 0)" }];
      case "wipe-d": return [{ clipPath: "inset(100% 0 0 0)" }, { clipPath: "inset(0 0 0 0)" }];
      case "wipe-lu": return [{ clipPath: "polygon(0% 0%,0% 0%,0% 0%,0% 0%,0% 0%,0% 0%)" },
        { clipPath: "polygon(0% 0%,100% 0%,100% 55%,55% 100%,0% 100%,0% 0%)" }];
      case "wipe-ru": return [{ clipPath: "polygon(100% 0%,100% 0%,100% 0%,100% 0%,100% 0%,100% 0%)" },
        { clipPath: "polygon(0% 0%,100% 0%,100% 100%,45% 100%,0% 45%,0% 0%)" }];
      default: return [{ opacity: 0 }, { opacity: 1 }];
    }
  }

  // 出场特效（旧内容退出；与入场同族，即 LEDvision 的「衔接」）
  function exitFrames(eff) {
    switch (eff) {
      case "push-l": return [{ transform: "translateX(0)" }, { transform: "translateX(-100%)" }];
      case "push-r": return [{ transform: "translateX(0)" }, { transform: "translateX(100%)" }];
      case "push-u": return [{ transform: "translateY(0)" }, { transform: "translateY(-100%)" }];
      case "push-d": return [{ transform: "translateY(0)" }, { transform: "translateY(100%)" }];
      case "rotate-3d": return [{ opacity: 1, transform: "perspective(1100px) rotateX(0)" },
        { opacity: 0, transform: "perspective(1100px) rotateX(-52deg) translateY(-14%)" }];
      default: return [{ opacity: 1 }, { opacity: 0 }];
    }
  }

  function dimLabel(text) {
    var d = document.createElement("div");
    d._mbLabel = true;
    d.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;display:flex;"
      + "align-items:center;justify-content:center;color:#666;background:#111;"
      + "font:2.5vh 'Noto Sans CJK SC',sans-serif;";
    d.textContent = text;
    return d;
  }

  // ---------- 媒体分区：轮播 + 特效 + Ken Burns；或 GROUP=grid 九宫格 ----------
  function makeMediaZone(z, el) {
    if (!z.slides || !z.slides.length) {
      el.appendChild(dimLabel("分区[" + z.name + "] 待放素材"));
      return;
    }
    if (z.group === "grid") { makeGridZone(z, el); return; }
    if (z.group === "waterfall") { makeWaterfallZone(z, el); return; }
    var idx = 0, rotateTimer = null, alive = true;
    function next() {
      if (!alive || !el.isConnected) { alive = false; return; }
      idx = (idx + 1) % z.slides.length;
      show();
    }
    function show() {
      if (rotateTimer) { clearTimeout(rotateTimer); rotateTimer = null; }
      if (!alive || !el.isConnected) { alive = false; return; }
      var src = z.slides[idx];
      var fit = P.fill || "contain";
      var node, i, media;
      var eff = pickTransition(z);
      var dur = clamp(num(P.transitionTime, 0.8), 0, 5);
      // 外层 wrapper 承接转场，内层 img/video 承接 Ken Burns，互不冲突
      node = document.createElement("div");
      node.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;background:#000";
      if (isVideo(src)) {
        media = document.createElement("video");
        media.autoplay = true;
        media.muted = (P.sound === false);
        media.onended = next;
        media.onerror = function () { rotateTimer = setTimeout(next, 4000); };
        media.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;object-fit:" + fit;
        node.appendChild(media);
      } else {
        media = document.createElement("img");
        media.onerror = function () { rotateTimer = setTimeout(next, 4000); };
        media.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
          + "object-fit:" + fit + ";background:#000";
        node.appendChild(media);
        // Ken Burns 缓推（静图变"活"）；低档位关闭
        if (truthy(P.kenburns) && !perfLow() && !perfMid()) {
          try {
            media.animate(
              [{ transform: "scale(1) translate(0,0)" }, { transform: "scale(1.07) translate(-1.4%,-.8%)" }],
              { duration: Math.min(clamp(num(z.duration, num(P.duration, 10)), 1, 86400), 40) * 1000,
                easing: "ease-out", fill: "forwards" });
          } catch (e) {}
        }
      }
      media.src = src;
      var olds = [];
      for (i = 0; i < el.children.length; i++) {
        if (!el.children[i]._mbLabel) { olds.push(el.children[i]); }
      }
      if (dur > 0) {
        // 出场衔接：push/rotate 族旧素材同步退出，其余淡出
        olds.forEach(function (o) {
          try { o.animate(exitFrames(eff),
            { duration: Math.round(dur * 1000), easing: EASE_STD, fill: "forwards" }); } catch (e) {}
        });
      }
      el.appendChild(node);
      if (dur > 0 && eff !== "none") {
        try { node.animate(animFrames(eff),
          { duration: Math.round(dur * 1000), easing: EASE_STD, fill: "forwards" }); } catch (e) {}
      }
      setTimeout(function () {
        olds.forEach(function (o) { if (o.parentNode === el) { el.removeChild(o); } });
      }, Math.round(dur * 1000) + 150);
      if (isVideo(src)) {
        var pr = media.play();
        if (pr && pr.catch) { pr.catch(function () {}); }
      } else {
        rotateTimer = setTimeout(next,
          clamp(num(z.duration, num(P.duration, 10)), 1, 86400) * 1000);
      }
      if (truthy(P.twinkle) && !isVideo(src)) {
        try { media.animate([{ opacity: 1 }, { opacity: 0.35 }, { opacity: 1 }],
          { duration: 1100, iterations: Infinity }); } catch (e) {}
      }
    }
    z._next = next;
    show();
  }

  // 图片组九宫格：分区内全部素材一次性网格铺开（不再轮播）
  function makeGridZone(z, el) {
    var n = z.slides.length;
    var cols = clamp(Math.round(num(z.groupcols, Math.ceil(Math.sqrt(n)))), 1, 8);
    var rows = Math.ceil(n / cols);
    var gap = 0.8; // vh
    var grid = document.createElement("div");
    grid.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
      + "display:grid;padding:" + (num(z.padding, 0) + 0.8) + "vh;box-sizing:border-box;"
      + "grid-template-columns:repeat(" + cols + ",1fr);grid-template-rows:repeat(" + rows + ",1fr);"
      + "gap:" + gap + "vh;background:" + (z.gradient ? "" : "#101010") + ";";
    z.slides.slice(0, cols * rows).forEach(function (src) {
      var cell = document.createElement("div");
      cell.style.cssText = "position:relative;overflow:hidden;background:#000;border-radius:.6vh;"
        + (truthy(z.card) && !perfLow() ? "box-shadow:0 .4vh 1.2vh rgba(0,0,0,.3);" : "");
      if (isVideo(src)) {
        var v = document.createElement("video");
        v.autoplay = true; v.muted = true; v.loop = true;
        // 注意: #stage img/video 全局 CSS 带 position:absolute，格内必须显式改回 static 否则四图叠在左上角
        v.style.cssText = "position:static;display:block;width:100%;height:100%;object-fit:" + (P.fill || "contain");
        v.src = src;
        cell.appendChild(v);
        var pr = v.play(); if (pr && pr.catch) { pr.catch(function () {}); }
      } else {
        var im = document.createElement("img");
        im.style.cssText = "position:static;display:block;width:100%;height:100%;object-fit:" + (P.fill || "contain");
        im.src = src;
        cell.appendChild(im);
      }
      grid.appendChild(cell);
    });
    el.appendChild(grid);
  }

  // 图片组瀑布流（v5：CSS 多列流式排布，多图信息墙场景）
  function makeWaterfallZone(z, el) {
    var cols = clamp(Math.round(num(z.groupcols, 3)), 1, 6);
    var wall = document.createElement("div");
    wall.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
      + "padding:" + (num(z.padding, 0) + 0.8) + "vh;box-sizing:border-box;overflow:hidden;"
      + "column-count:" + cols + ";column-gap:.8vh;background:" + (z.gradient ? "" : "#101010") + ";";
    z.slides.forEach(function (src, i) {
      if (isVideo(src)) { return; } // 瀑布流只放图片，视频请用轮播或九宫格
      var cell = document.createElement("div");
      cell.style.cssText = "break-inside:avoid;margin-bottom:.8vh;overflow:hidden;"
        + "border-radius:.6vh;position:relative;background:#000;"
        + (truthy(z.card) && !perfLow() ? "box-shadow:0 .4vh 1.2vh rgba(0,0,0,.3);" : "");
      var im = document.createElement("img");
      // 注意: #stage img 全局 CSS 带 position:absolute，列内必须显式改回块级
      im.style.cssText = "position:static;display:block;width:100%;object-fit:cover;";
      im.src = src;
      cell.appendChild(im);
      wall.appendChild(cell);
      try {
        cell.animate([{ opacity: 0, transform: "translateY(3vh)" }, { opacity: 1, transform: "translateY(0)" }],
          { duration: 480, delay: (i % 12) * 70, easing: EASE_STD, fill: "backwards" });
      } catch (e) {}
    });
    el.appendChild(wall);
  }

  // ---------- 文本窗 ----------
  function makeTextZone(z, el) {
    var t = z.text || {};
    var content = t.content || "";
    if (!content.trim()) {
      el.appendChild(dimLabel("文本窗[" + z.name + "] 缺 text.txt"));
      return;
    }
    var lines = String(content).replace(/\r/g, "").split("\n")
      .filter(function (s) { return s.trim() !== ""; });
    if (!lines.length) { el.appendChild(dimLabel("文本窗[" + z.name + "] 内容为空")); return; }
    var eff = t.effect || "static";
    var fcss = fontCss(t, 6);
    if (!z.gradient) { zoneBg(el, z, t.bgcolor || "rgba(0,0,0,0.45)"); }
    var extra = visCss(z);
    var pad = num(z.padding, 0);
    var alignv = z.alignv === "top" ? "flex-start" : (z.alignv === "bottom" ? "flex-end" : "center");

    if (eff === "scroll-left" || eff === "scroll-up") {
      var inner = document.createElement("div");
      inner.style.cssText = "position:absolute;white-space:nowrap;will-change:transform;"
        + "color:" + (t.color || "#ffffff") + ";font:" + fcss + ";" + extra
        + (eff === "scroll-up" ? "line-height:" + clamp(num(t.linespacing, 1.5), 1, 3) + "em;" : "");
      el.appendChild(inner);
      makeMarquee(el, inner, {
        lines: lines, speed: t.speed, vertical: eff === "scroll-up", sep: "　　", font: fcss
      });
      return;
    }
    if (eff === "typewriter") {
      var boxT = document.createElement("div");
      boxT.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
        + "display:flex;align-items:center;justify-content:center;"
        + "padding:" + (pad + 1) + "vh " + (pad + 2) + "vh;box-sizing:border-box;"
        + "text-align:" + (t.align || "center") + ";white-space:pre-wrap;"
        + "color:" + (t.color || "#ffffff") + ";font:" + fcss + ";" + extra;
      el.appendChild(boxT);
      var chars = Array.from(String(content).replace(/\r/g, ""));
      var cps = clamp(num(t.speed, 6), 0.5, 50);
      var ms = Math.round(1000 / cps);
      var i = 0, iv = null;
      function step() {
        if (!el.isConnected) { if (iv) { clearInterval(iv); } return; }
        i++;
        boxT.textContent = chars.slice(0, i).join("");
        if (i >= chars.length) {
          clearInterval(iv); iv = null;
          setTimeout(function () {
            if (!el.isConnected) { return; }
            i = 0; boxT.textContent = "";
            iv = setInterval(step, ms);
          }, 3000);
        }
      }
      iv = setInterval(step, ms);
      return;
    }
    var box = document.createElement("div");
    box.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
      + "display:flex;flex-direction:column;align-items:center;justify-content:" + alignv + ";"
      + "padding:" + (pad + 1) + "vh " + (pad + 2) + "vh;box-sizing:border-box;"
      + "text-align:" + (t.align || "center") + ";white-space:pre-wrap;"
      + "color:" + (t.color || "#ffffff") + ";font:" + fcss + ";"
      + "line-height:" + clamp(num(t.linespacing, 1.5), 1, 3) + ";" + extra;
    // v7 竖排文本（党政竖联/古风排版）：VERTICAL=yes -> writing-mode:vertical-rl
    if (truthy(t.vertical)) {
      box.style.cssText += "writing-mode:vertical-rl;text-orientation:upright;"
        + "align-items:" + (z.alignv === "top" ? "flex-start" : "center") + ";";
    }
    // 图标行（可选）
    if (z.icon && ICONS[z.icon]) {
      var irow = document.createElement("div");
      irow.style.cssText = "display:flex;align-items:center;margin-bottom:1.2vh;color:" + (t.color || "#ffffff") + ";";
      var isize = clamp(num(t.size, 6) * 1.4, 2, 30);
      var ic = iconSvg(z.icon, isize);
      if (ic) { irow.appendChild(ic); }
      if (z.icontext) {
        var ilab = document.createElement("span");
        ilab.style.cssText = "margin-left:1vh;font:" + fcss;
        ilab.textContent = z.icontext;
        irow.appendChild(ilab);
      }
      box.appendChild(irow);
    }
    box.textContent = String(content).replace(/\r/g, "");
    if (eff === "blink") {
      try { box.animate([{ opacity: 1 }, { opacity: 0.15 }, { opacity: 1 }],
        { duration: 900, iterations: Infinity }); } catch (e) {}
    }
    el.appendChild(box);
  }

  // ---------- 时钟窗 ----------
  var WEEKS = ["日", "一", "二", "三", "四", "五", "六"];
  function alignvCss(z) {
    return z.alignv === "top" ? "flex-start" : (z.alignv === "bottom" ? "flex-end" : "center");
  }
  function makeClock(z, el) {
    var c = z.clock || {};
    if ((c.mode || "digital") === "dial") { makeDialClock(z, el, c); return; }
    var presets = {
      datetime: "{Y}-{M}-{D} {h}:{m}:{s}",
      date: "{Y}-{M}-{D}",
      time: "{h}:{m}:{s}",
      week: "{Y}-{M}-{D} 星期{W}",
      weektime: "星期{W} {h}:{m}:{s}",
      // v5 大时钟双行排版：上行日期下行时间（现代看板最常用）
      big: "{Y}-{M}-{D} 星期{W}|{h}:{m}:{s}"
    };
    var pat = presets[c.format] || c.format || presets.datetime;
    var pad = num(z.padding, 0);
    el.style.cssText += ";display:flex;align-items:center;justify-content:center;"
      + "color:" + (c.color || "#ffffff") + ";background-color:" + (z.gradient ? "" : (c.bgcolor || "rgba(0,0,0,0.55)"))
      + ";font:" + fontCss(c, 4.5) + ";" + visCss(z) + "font-variant-numeric:tabular-nums;"
      + "padding:" + pad + "vh;box-sizing:border-box;";
    // 「|」分行：首行 0.45 倍字号，末行（大时间）1 倍；v5 翻牌模式 MODE=flip
    var linesPat = pat.split("|");
    var flip = (c.mode === "flip") && !perfLow() && !perfMid();
    var box = document.createElement("div");
    box.style.cssText = "display:flex;flex-direction:column;align-items:center;justify-content:center;";
    el.appendChild(box);
    var rowEls = linesPat.map(function (lp, li) {
      var r = document.createElement("div");
      r.style.cssText = "display:flex;align-items:center;justify-content:center;"
        + (linesPat.length > 1 ? "font-size:" + (li === linesPat.length - 1 ? "1em" : ".45em") + ";line-height:1.25;margin:.2vh 0;" : "");
      box.appendChild(r);
      return r;
    });
    function fillRow(r, text) {
      if (!flip) { r.textContent = text; return; }
      // 翻牌：按字符建卡，仅变化的字符翻动（rotateX）
      var need = text.split("");
      while (r.children.length > need.length) { r.removeChild(r.lastChild); }
      need.forEach(function (ch, i) {
        var card = r.children[i];
        if (!card) {
          card = document.createElement("span");
          card.style.cssText = "display:inline-block;padding:0 .18em;margin:0 .04em;"
            + "border-radius:.12em;";
          r.appendChild(card);
        }
        var span = card.firstChild;
        if (!span) {
          span = document.createElement("span");
          card.appendChild(span);
        }
        if (card._mbCh !== ch) {
          card._mbCh = ch;
          span.textContent = ch;
          try {
            card.animate(
              [{ transform: "rotateX(90deg)", opacity: 0.2 }, { transform: "rotateX(0deg)", opacity: 1 }],
              { duration: 380, easing: "ease-out" });
          } catch (e) {}
        }
      });
    }
    function render() {
      var d = new Date();
      linesPat.forEach(function (lp, li) {
        var text = lp
          .replace(/\{Y\}/g, d.getFullYear())
          .replace(/\{M\}/g, pad2(d.getMonth() + 1))
          .replace(/\{D\}/g, pad2(d.getDate()))
          .replace(/\{h\}/g, pad2(d.getHours()))
          .replace(/\{m\}/g, pad2(d.getMinutes()))
          .replace(/\{s\}/g, pad2(d.getSeconds()))
          .replace(/\{W\}/g, WEEKS[d.getDay()]);
        fillRow(rowEls[li], text);
      });
    }
    render();
    var iv = setInterval(function () {
      if (el.isConnected) { render(); } else { clearInterval(iv); }
    }, 200);
  }
  function makeDialClock(z, el, c) {
    var pad = num(z.padding, 0);
    el.style.cssText += ";display:flex;align-items:center;justify-content:center;"
      + "color:" + (c.color || "#ffffff") + ";background-color:" + (z.gradient ? "" : (c.bgcolor || "rgba(0,0,0,0.55)"))
      + ";padding:" + pad + "vh;box-sizing:border-box;";
    var NS = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", "0 0 100 100");
    var face = document.createElementNS(NS, "circle");
    face.setAttribute("cx", "50"); face.setAttribute("cy", "50"); face.setAttribute("r", "47");
    face.setAttribute("fill", "none"); face.setAttribute("stroke", "currentColor");
    face.setAttribute("stroke-width", "2.5");
    svg.appendChild(face);
    var i, a;
    for (i = 0; i < 12; i++) {
      var tk = document.createElementNS(NS, "line");
      a = i * 30 * Math.PI / 180;
      tk.setAttribute("x1", 50 + Math.sin(a) * 40); tk.setAttribute("y1", 50 - Math.cos(a) * 40);
      tk.setAttribute("x2", 50 + Math.sin(a) * 44); tk.setAttribute("y2", 50 - Math.cos(a) * 44);
      tk.setAttribute("stroke", "currentColor");
      tk.setAttribute("stroke-width", i % 3 === 0 ? "3" : "1.5");
      svg.appendChild(tk);
    }
    function hand(len, w) {
      var h = document.createElementNS(NS, "line");
      h.setAttribute("x1", "50"); h.setAttribute("y1", "50");
      h.setAttribute("x2", "50"); h.setAttribute("y2", String(50 - len));
      h.setAttribute("stroke", "currentColor");
      h.setAttribute("stroke-width", String(w));
      h.setAttribute("stroke-linecap", "round");
      svg.appendChild(h);
      return h;
    }
    var hh = hand(24, 4.5), mh = hand(35, 3), sh = hand(40, 1.5);
    var cap = document.createElementNS(NS, "circle");
    cap.setAttribute("cx", "50"); cap.setAttribute("cy", "50"); cap.setAttribute("r", "2.5");
    cap.setAttribute("fill", "currentColor");
    svg.appendChild(cap);
    el.appendChild(svg);
    requestAnimationFrame(function () {
      var s = Math.min(el.clientWidth, el.clientHeight) * 0.86;
      svg.setAttribute("width", String(Math.max(10, s)));
      svg.setAttribute("height", String(Math.max(10, s)));
    });
    function tick() {
      if (!el.isConnected) { clearInterval(iv); return; }
      var d = new Date();
      var sec = d.getSeconds() + d.getMilliseconds() / 1000;
      sh.setAttribute("transform", "rotate(" + sec * 6 + " 50 50)");
      mh.setAttribute("transform", "rotate(" + (d.getMinutes() + sec / 60) * 6 + " 50 50)");
      hh.setAttribute("transform", "rotate(" + ((d.getHours() % 12) + d.getMinutes() / 60) * 30 + " 50 50)");
    }
    tick();
    var iv = setInterval(tick, 200);
  }

  // ---------- 计时窗 ----------
  function parseTarget(str) {
    if (!str) { return null; }
    var m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?$/.exec(String(str).trim());
    if (!m) { return null; }
    return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
  }
  function makeCountdown(z, el) {
    var cd = z.countdown || {};
    var target = parseTarget(cd.target);
    var since = parseTarget(cd.since);
    var start = Date.now();
    var size = num(cd.size, 4.5);
    var pad = num(z.padding, 0);
    // v7 主题化倒计时：TOPIC=安全生产100天 + TARGET -> 横幅主题 + 大字「倒计时 N 天」；
    // SINCE=YYYY-MM-DD -> 「第 N 天」累计模式（COUNTUP=yes 同效）
    var topic = String(cd.topic || "").trim();
    var label = String(cd.label || "").trim();
    var unit = String(cd.unit || "天").trim() || "天";
    var thematic = !!(topic || since || label || (cd.unit && target));
    el.style.cssText += ";display:flex;flex-direction:column;align-items:center;justify-content:" + alignvCss(z) + ";"
      + "color:" + (cd.color || "#ffffff") + ";background-color:" + (z.gradient ? "" : (cd.bgcolor || "rgba(0,0,0,0.55)"))
      + ";padding:" + pad + "vh;box-sizing:border-box;";
    var fam = "'" + (cd.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif";
    if (thematic) {
      // ---- 主题化渲染（可编辑主题横幅 + 大字天数） ----
      if (topic) {
        var ban = document.createElement("div");
        ban.style.cssText = "width:100%;display:flex;align-items:center;justify-content:center;"
          + "padding:.8vh 1.2vh;margin-bottom:1.6vh;box-sizing:border-box;font:bold " + (size * 0.42) + "vh " + fam + ";"
          + "background:linear-gradient(90deg," + (cd.topic_bg || "#c8102e") + "," + (cd.topic_bg2 || "#8f0718") + ");"
          + "clip-path:polygon(0 0,100% 0,96.5% 100%,3.5% 100%);color:" + (cd.topic_color || "#ffe9b0") + ";" + visCss(z);
        ban.textContent = topic;
        el.appendChild(ban);
      }
      var lab = document.createElement("div");
      lab.style.cssText = "font:" + (size * 0.34) + "vh " + fam + ";opacity:.8;letter-spacing:.6vh;margin-bottom:.4vh;" + visCss(z);
      el.appendChild(lab);
      var row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:baseline;line-height:1;";
      var big = document.createElement("div");
      big.style.cssText = "font:bold " + size + "vh " + fam + ";font-variant-numeric:tabular-nums;" + visCss(z);
      row.appendChild(big);
      var ut = document.createElement("div");
      ut.style.cssText = "font:bold " + (size * 0.4) + "vh " + fam + ";margin-left:.8vh;opacity:.9;" + visCss(z);
      ut.textContent = unit;
      row.appendChild(ut);
      el.appendChild(row);
      var sub = document.createElement("div");
      sub.style.cssText = "font:" + (size * 0.26) + "vh " + fam + ";opacity:.65;margin-top:.8vh;font-variant-numeric:tabular-nums;";
      el.appendChild(sub);
      function renderTheme() {
        if (target) {
          var diff = target.getTime() - Date.now();
          var days = diff > 0 ? Math.ceil(diff / 86400000) : 0;
          big.textContent = days;
          lab.textContent = label || "倒计时";
          sub.textContent = diff > 0
            ? pad2(Math.floor(diff / 3600000) % 24) + "小时"
              + pad2(Math.floor(diff / 60000) % 60) + "分"
              + pad2(Math.floor(diff / 1000) % 60) + "秒" : "已到目标时间";
        } else if (since) {
          var up = Date.now() - since.getTime();
          var n = Math.floor(up / 86400000) + 1; // 含首日：第 1 天
          big.textContent = n;
          lab.textContent = label || "第";
          sub.textContent = since.getFullYear() + "-" + pad2(since.getMonth() + 1) + "-" + pad2(since.getDate()) + " 起";
        } else {
          big.textContent = "--"; lab.textContent = label || "倒计时"; sub.textContent = "";
        }
      }
      renderTheme();
      var ivT = setInterval(function () {
        if (el.isConnected) { renderTheme(); } else { clearInterval(ivT); }
      }, 500);
      return;
    }
    if (cd.title) {
      var title = document.createElement("div");
      title.style.cssText = "font:" + (truthy(cd.bold) ? "bold " : "") + (size * 0.45) + "vh " + fam
        + ";opacity:.85;margin-bottom:1vh;" + visCss(z);
      title.textContent = cd.title;
      el.appendChild(title);
    }
    var big = document.createElement("div");
    big.style.cssText = "font:bold " + size + "vh " + fam + ";font-variant-numeric:tabular-nums;" + visCss(z);
    el.appendChild(big);
    function render() {
      if (target) {
        var diff = target.getTime() - Date.now();
        if (diff <= 0) { big.textContent = "0天 00:00:00"; return; }
        var sec = Math.floor(diff / 1000);
        var days = Math.floor(sec / 86400);
        big.textContent = days + "天 " + pad2(Math.floor(sec % 86400 / 3600))
          + ":" + pad2(Math.floor(sec % 3600 / 60)) + ":" + pad2(sec % 60);
      } else {
        var up = Math.floor((Date.now() - start) / 1000);
        var d2 = Math.floor(up / 86400);
        big.textContent = (d2 > 0 ? d2 + "天 " : "")
          + pad2(Math.floor(up % 86400 / 3600)) + ":"
          + pad2(Math.floor(up % 3600 / 60)) + ":" + pad2(up % 60);
      }
    }
    render();
    var iv = setInterval(function () {
      if (el.isConnected) { render(); } else { clearInterval(iv); }
    }, 250);
  }

  // ---------- 二维码窗（qr.js 本地生成，离网可用，中文支持） ----------
  function makeQrZone(z, el) {
    var q = z.qr || {};
    var text = String(q.content || "").trim();
    if (!text) { el.appendChild(dimLabel("二维码窗[" + z.name + "] 缺 text.txt")); return; }
    if (typeof window.qrcode !== "function") {
      el.appendChild(dimLabel("二维码窗[" + z.name + "] 缺 qr.js 库文件")); return;
    }
    var pad = num(z.padding, 0);
    el.style.cssText += ";background-color:" + (z.gradient ? "" : (q.bgcolor || "#ffffff"))
      + ";padding:" + pad + "vh;box-sizing:border-box;";
    var qr = null;
    for (var t = 1; t <= 40 && !qr; t++) {
      try {
        var g = window.qrcode(t, q.ecl || "M");
        g.addData(text);
        g.make();
        qr = g;
      } catch (e) {}
    }
    if (!qr) { el.appendChild(dimLabel("二维码内容过长，生成失败")); return; }
    var wrap = document.createElement("div");
    wrap.style.cssText = "width:100%;height:100%;display:flex;flex-direction:column;"
      + "align-items:center;justify-content:" + alignvCss(z) + ";";
    var cv = document.createElement("canvas");
    var n = qr.getModuleCount();
    var quiet = 4; // 静区
    var scale = 8;
    cv.width = cv.height = (n + quiet * 2) * scale;
    var ctx = cv.getContext("2d");
    ctx.fillStyle = q.bgcolor || "#ffffff";
    ctx.fillRect(0, 0, cv.width, cv.height);
    ctx.fillStyle = q.color || "#111111";
    for (var r = 0; r < n; r++) {
      for (var c2 = 0; c2 < n; c2++) {
        if (qr.isDark(r, c2)) {
          ctx.fillRect((c2 + quiet) * scale, (r + quiet) * scale, scale, scale);
        }
      }
    }
    cv.style.cssText = "max-width:100%;max-height:100%;object-fit:contain;";
    wrap.appendChild(cv);
    if (q.title) {
      var lab = document.createElement("div");
      lab.style.cssText = "margin-top:.8vh;color:" + (q.titlecolor || (q.color || "#111111"))
        + ";font:2.2vh 'Noto Sans CJK SC','WenQuanYi Micro Hei',sans-serif;" + visCss(z);
      lab.textContent = q.title;
      wrap.appendChild(lab);
    }
    el.appendChild(wrap);
  }

  // ---------- 公告列表窗（本地 text.txt 或 data/*.json 定时刷新） ----------
  function makeNoticeZone(z, el) {
    var n0 = z.notice || {};
    var items = (String(n0.content || "").replace(/\r/g, "").split("\n"))
      .filter(function (s) { return s.trim() !== ""; });
    var pad = num(z.padding, 0);
    var fcss = fontCss(n0, 3.2);
    var icon = z.icon || n0.icon;
    // 分区底色挂在 el 上：内容超出切到自动上滚时会清空内层盒子，底色不能跟着丢
    if (!z.gradient) { zoneBg(el, z, n0.bgcolor || "rgba(0,0,0,0.55)"); }
    function render(list) {
      if (!list.length) { el.appendChild(dimLabel("公告窗[" + z.name + "] 内容为空")); return; }
      var box = document.createElement("div");
      box.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
        + "display:flex;flex-direction:column;justify-content:" + alignvCss(z) + ";"
        + "padding:" + (pad + 1.2) + "vh " + (pad + 1.6) + "vh;box-sizing:border-box;"
        + "overflow:hidden;color:" + (n0.color || "#ffffff") + ";"
        + (z.gradient ? "" : "background:" + (n0.bgcolor || "rgba(0,0,0,0.55)") + ";") + visCss(z);
      if (n0.title) {
        var hd = document.createElement("div");
        hd.style.cssText = "flex:0 0 auto;display:flex;align-items:center;margin-bottom:1vh;"
          + "padding-bottom:.6vh;border-bottom:1px solid rgba(255,255,255,.25);"
          + "color:" + (n0.titlecolor || n0.color || "#ffffff") + ";font:" + (truthy(n0.bold) ? "bold " : "") + num(n0.size, 3.2) * 1.15 + "vh '"
          + (n0.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;" + visCss(z);
        var hi = iconSvg(icon || "horn", num(n0.size, 3.2) * 1.15);
        if (hi) { hd.appendChild(hi); }
        var ht = document.createElement("span");
        ht.style.cssText = "margin-left:.8vh;";
        ht.textContent = n0.title;
        hd.appendChild(ht);
        box.appendChild(hd);
      }
      // 列表放进独立滚动区：标题固定钉在顶上，只让列表滚
      var body = document.createElement("div");
      body.style.cssText = "position:relative;flex:1 1 auto;min-height:0;overflow:hidden;"
        + "display:flex;flex-direction:column;justify-content:" + alignvCss(z) + ";";
      box.appendChild(body);
      list.forEach(function (it, i) {
        var row = document.createElement("div");
        row.style.cssText = "flex:0 0 auto;display:flex;align-items:center;margin:.55vh 0;font:" + fcss + ";";
        if (!n0.title) {
          var idx = document.createElement("span");
          idx.style.cssText = "flex:0 0 auto;margin-right:.8vh;opacity:.75;";
          idx.textContent = "•";
          row.appendChild(idx);
        }
        var tx = document.createElement("span");
        tx.style.cssText = "white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
        tx.textContent = it;
        row.appendChild(tx);
        body.appendChild(row);
      });
      el.appendChild(box);
      // 列表超出滚动区高度 -> 列表从第一行开始往上滚（标题不动，首屏不留空）
      requestAnimationFrame(function () {
        if (body.scrollHeight > body.clientHeight + 4) {
          body.innerHTML = "";
          // 滚动区上下渐隐：文字进出不留硬切口（低档位关掉）
          if (!perfLow()) {
            var mk = "linear-gradient(180deg,rgba(0,0,0,0) 0%,rgba(0,0,0,1) 9%,rgba(0,0,0,1) 91%,rgba(0,0,0,0) 100%)";
            try { body.style.webkitMaskImage = mk; body.style.maskImage = mk; } catch (e) {}
          }
          var inner = document.createElement("div");
          inner.style.cssText = "position:absolute;left:0;top:0;width:100%;"
            + "color:" + (n0.color || "#ffffff") + ";font:" + fcss + ";" + visCss(z);
          body.appendChild(inner);
          makeMarquee(body, inner, {
            lines: list, speed: num(n0.speed, 30), vertical: true, fromTop: true, font: fcss
          });
        }
      });
    }
    render(items);
    // DATASRC: data/*.json 定时刷新（离网本地数据源）
    if (n0.datasrc) {
      var refreshMs = clamp(num(n0.refresh, 0), 0, 1440) * 60000;
      function pull() {
        try {
          var xhr = new XMLHttpRequest();
          xhr.open("GET", n0.datasrc, true);
          xhr.onload = function () {
            try {
              var j = JSON.parse(xhr.responseText);
              var list = (Array.isArray(j) ? j : (j.items || [])).map(function (x) {
                return typeof x === "string" ? x : (x.text || x.title || "");
              }).filter(function (s) { return s; });
              if (list.length) { el.innerHTML = ""; render(list); }
            } catch (e) {}
          };
          xhr.onerror = function () {};
          xhr.send();
        } catch (e) {}
      }
      if (refreshMs > 0) { setInterval(pull, refreshMs); }
    }
  }

  // ---------- 本地 JSON 数据源轮询（DATASRC，公告/表格/数据/仪表共用） ----------
  function pollDatasrc(url, refreshMin, cb) {
    var refreshMs = clamp(num(refreshMin, 0), 0, 1440) * 60000;
    function pull() {
      try {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        xhr.onload = function () {
          try { cb(JSON.parse(xhr.responseText)); } catch (e) {}
        };
        xhr.onerror = function () {};
        xhr.send();
      } catch (e) {}
    }
    pull();
    if (refreshMs > 0) { setInterval(pull, refreshMs); }
  }

  // ---------- 表格窗（v5：值班表/课程表/价格表，对齐 LEDvision 表格窗） ----------
  // text.txt 每行一条记录，单元格用 Tab 或 | 分隔；首行自动做表头（HEADER=yes）
  function makeTableZone(z, el) {
    var tb = z.table || {};
    function splitRow(ln) {
      if (ln.indexOf("\t") >= 0) { return ln.split("\t"); }
      return ln.split("|");
    }
    function parseLines(content) {
      return String(content || "").replace(/\r/g, "").split("\n")
        .map(function (s) { return s.replace(/\s+$/, ""); })
        .filter(function (s) { return s.trim() !== ""; })
        .map(splitRow);
    }
    function render(rows) {
      if (!rows.length) { el.appendChild(dimLabel("表格窗[" + z.name + "] 缺 text.txt")); return; }
      el.innerHTML = "";
      var pad = num(z.padding, 1);
      var header = truthy(tb.header) || tb.header == null; // 默认首行做表头
      var zebra = truthy(tb.zebra) || tb.zebra == null;   // 默认斑马纹
      var fsize = clamp(num(tb.size, 2.6), 0.8, 12);
      // 行数多时自动缩字号（ARM 屏一屏放下优先于滚屏）
      var nRows = rows.length;
      if (nRows > 12) { fsize = Math.max(1.1, fsize * 12 / nRows); }
      var accent = tb.accent || (z.gradient ? String(z.gradient).split(",")[0].trim() : "#1d4ed8");
      var borderc = tb.bordercolor || "rgba(255,255,255,.16)";
      var box = document.createElement("div");
      box.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;display:flex;"
        + "flex-direction:column;padding:" + (pad + .6) + "vh " + (pad + 1) + "vh;box-sizing:border-box;"
        + "color:" + (tb.color || "#eaf1ff") + ";" + visCss(z);
      if (!z.gradient) { zoneBg(el, z, tb.bgcolor || "rgba(9,18,36,.82)"); }
      if (tb.title) {
        var hd = document.createElement("div");
        hd.style.cssText = "flex:0 0 auto;display:flex;align-items:center;margin-bottom:.9vh;"
          + "padding-bottom:.5vh;border-bottom:.35vh solid " + accent + ";"
          + "color:" + (tb.color || "#eaf1ff") + ";font:bold " + (fsize * 1.25) + "vh '"
          + (tb.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;";
        var ic = iconSvg(tb.icon || "doc", fsize * 1.25);
        if (ic) { hd.appendChild(ic); }
        var ht = document.createElement("span");
        ht.style.cssText = "margin-left:.8vh;";
        ht.textContent = tb.title;
        hd.appendChild(ht);
        box.appendChild(hd);
      }
      var gridBox = document.createElement("div");
      gridBox.style.cssText = "flex:1 1 auto;min-height:0;display:flex;flex-direction:column;overflow:hidden;";
      box.appendChild(gridBox);
      var nCols = Math.max.apply(null, rows.map(function (r) { return r.length; }));
      rows.forEach(function (row, ri) {
        var isHead = header && ri === 0;
        var tr = document.createElement("div");
        tr.style.cssText = "flex:1 1 0;display:flex;align-items:center;"
          + (isHead ? "background:" + accent + ";color:#fff;font-weight:bold;" : "")
          + (zebra && !isHead && ri % 2 === 0 ? "background:rgba(255,255,255,.06);" : "")
          + "border-bottom:1px solid " + borderc + ";min-height:0;";
        for (var ci = 0; ci < nCols; ci++) {
          var td = document.createElement("div");
          td.style.cssText = "flex:1 1 0;padding:.32vh .6vh;overflow:hidden;white-space:nowrap;"
            + "text-overflow:ellipsis;text-align:" + (tb.align || (ci === 0 ? "left" : "center"))
            + ";font:" + (isHead ? "bold " : "") + fsize + "vh '"
            + (tb.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;";
          td.textContent = row[ci] != null ? String(row[ci]).trim() : "";
          tr.appendChild(td);
        }
        gridBox.appendChild(tr);
      });
      el.appendChild(box);
    }
    render(parseLines(tb.content));
    if (tb.datasrc) {
      pollDatasrc(tb.datasrc, tb.refresh, function (j) {
        var list = Array.isArray(j) ? j : (j.items || j.rows || []);
        var rows = list.map(function (x) {
          if (Array.isArray(x)) { return x.map(String); }
          if (typeof x === "object" && x) { return Object.keys(x).map(function (k) { return k + ":" + x[k]; }); }
          return [String(x)];
        });
        if (rows.length) { render(rows); }
      });
    }
  }

  // ---------- 数据统计窗（v5：大数字指标卡 + 数字滚动 + 迷你进度条） ----------
  // text.txt 每行: 标签|数值|单位|进度%(0-100，可空)
  function makeDataZone(z, el) {
    var dd = z.data || {};
    var fsize = clamp(num(dd.size, 5), 1, 16);
    var accent = dd.accent || (z.gradient ? String(z.gradient).split(",")[0].trim() : "#38bdf8");
    var barColor = dd.barcolor || accent;
    var valueColor = dd.valuecolor || dd.color || "#ffffff";
    var pad = num(z.padding, 1);
    if (!z.gradient) { zoneBg(el, z, dd.bgcolor || "rgba(9,18,36,.82)"); }
    function parse(content) {
      return String(content || "").replace(/\r/g, "").split("\n")
        .filter(function (s) { return s.trim() !== ""; })
        .map(function (s) {
          var p = s.split("|").map(function (x) { return x.trim(); });
          return { label: p[0] || "", value: p[1] || "0", unit: p[2] || "", bar: p[3] || "" };
        });
    }
    function render(items) {
      if (!items.length) { el.appendChild(dimLabel("数据窗[" + z.name + "] 缺 text.txt")); return; }
      el.innerHTML = "";
      var box = document.createElement("div");
      box.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;display:flex;"
        + "flex-direction:column;padding:" + (pad + .6) + "vh " + (pad + 1) + "vh;box-sizing:border-box;"
        + "color:" + (dd.color || "#eaf1ff") + ";" + visCss(z);
      if (dd.title) {
        var hd = document.createElement("div");
        hd.style.cssText = "flex:0 0 auto;display:flex;align-items:center;margin-bottom:.8vh;"
          + "color:" + (dd.color || "#eaf1ff") + ";font:bold " + (fsize * .55) + "vh '"
          + (dd.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;";
        var ic = iconSvg(dd.icon || "chart", fsize * .55);
        if (ic) { hd.appendChild(ic); }
        var ht = document.createElement("span");
        ht.style.cssText = "margin-left:.8vh;";
        ht.textContent = dd.title;
        hd.appendChild(ht);
        box.appendChild(hd);
      }
      var body = document.createElement("div");
      body.style.cssText = "flex:1 1 auto;min-height:0;display:grid;gap:.9vh;"
        + "grid-template-columns:repeat(" + Math.min(items.length, 2) + ",1fr);"
        + "grid-template-rows:repeat(" + Math.ceil(items.length / Math.min(items.length, 2)) + ",1fr);";
      box.appendChild(body);
      items.forEach(function (it, i) {
        var card = document.createElement("div");
        card.style.cssText = "display:flex;flex-direction:column;justify-content:center;padding:.8vh 1vh;"
          + "border-radius:1vh;background:rgba(255,255,255,.055);overflow:hidden;"
          + (truthy(z.card) && !perfLow() ? "box-shadow:0 .3vh .9vh rgba(0,0,0,.35);" : "");
        var lab = document.createElement("div");
        lab.style.cssText = "font:" + (fsize * .32) + "vh '" + (dd.font || "sans-serif")
          + "','Noto Sans CJK SC',sans-serif;opacity:.75;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
        lab.textContent = it.label;
        var vrow = document.createElement("div");
        vrow.style.cssText = "display:flex;align-items:baseline;margin-top:.25vh;";
        var val = document.createElement("span");
        val.style.cssText = "font:bold " + fsize + "vh '" + (dd.font || "sans-serif")
          + "','Noto Sans CJK SC',sans-serif;font-variant-numeric:tabular-nums;color:" + valueColor + ";" + visCss(z);
        var unit = document.createElement("span");
        unit.style.cssText = "font:" + (fsize * .35) + "vh '" + (dd.font || "sans-serif")
          + "','Noto Sans CJK SC',sans-serif;margin-left:.5vh;opacity:.8;";
        unit.textContent = it.unit;
        vrow.appendChild(val); vrow.appendChild(unit);
        card.appendChild(lab); card.appendChild(vrow);
        if (it.bar !== "" && isFinite(parseFloat(it.bar))) {
          var track = document.createElement("div");
          track.style.cssText = "margin-top:.7vh;height:.5vh;border-radius:.3vh;background:rgba(255,255,255,.14);overflow:hidden;";
          var bar = document.createElement("div");
          var pctv = clamp(parseFloat(it.bar), 0, 100);
          bar.style.cssText = "height:100%;border-radius:.3vh;background:" + barColor + ";width:0%;transition:width 1.2s cubic-bezier(.4,0,.2,1);";
          track.appendChild(bar);
          card.appendChild(track);
          requestAnimationFrame(function () { bar.style.width = pctv + "%"; });
        }
        body.appendChild(card);
        // 数字滚动（COUNTUP=yes 或不写都滚动；=no 直接显示）
        var target = parseFloat(String(it.value).replace(/[^\d.\-]/g, ""));
        if (!isFinite(target)) { val.textContent = it.value; return; }
        if (truthy(dd.countup) || dd.countup == null) {
          var t0 = null, DURC = 1400;
          function stepC(ts) {
            if (t0 === null) { t0 = ts; }
            var p = clamp((ts - t0) / DURC, 0, 1);
            var e = 1 - Math.pow(1 - p, 3);
            var cur = target * e;
            val.textContent = (String(it.value).indexOf(".") >= 0)
              ? cur.toFixed(1) : Math.round(cur);
            if (p < 1) { requestAnimationFrame(stepC); }
          }
          requestAnimationFrame(stepC);
        } else {
          val.textContent = it.value;
        }
      });
      el.appendChild(box);
    }
    render(parse(dd.content));
    if (dd.datasrc) {
      pollDatasrc(dd.datasrc, dd.refresh, function (j) {
        var list = Array.isArray(j) ? j : (j.items || []);
        var items = list.map(function (x) {
          if (Array.isArray(x)) { return { label: x[0] || "", value: x[1] || "0", unit: x[2] || "", bar: x[3] || "" }; }
          return { label: x.label || x.name || "", value: String(x.value != null ? x.value : "0"), unit: x.unit || "", bar: x.bar != null ? String(x.bar) : "" };
        });
        if (items.length) { render(items); }
      });
    }
  }

  // ---------- 仪表盘窗（v5：SVG 半圆仪表，指针/弧长动画） ----------
  // 单表：style.txt VALUE/LABEL/MIN/MAX/UNIT；多表：text.txt 每行 标签=值[,max]
  function makeGaugeZone(z, el) {
    var gg = z.gauge || {};
    var pad = num(z.padding, 1);
    if (!z.gradient) { zoneBg(el, z, gg.bgcolor || "rgba(9,18,36,.82)"); }
    var ringCol = gg.ring || "rgba(255,255,255,.14)";
    var cols = (String(gg.colors || "#22c55e,#f59e0b,#ef4444").split(",")).map(function (s) { return s.trim(); });
    function valColor(pct) {
      if (pct < 55) { return cols[0] || "#22c55e"; }
      if (pct < 85) { return cols[1] || "#f59e0b"; }
      return cols[2] || "#ef4444";
    }
    function parseMulti(content) {
      return String(content || "").replace(/\r/g, "").split("\n")
        .filter(function (s) { return s.trim() !== ""; })
        .map(function (s) {
          var kv = s.split("=");
          var parts = String(kv[1] || "").split(",");
          return { label: kv[0].trim(), value: parseFloat(parts[0]) || 0, max: parseFloat(parts[1]) || 100 };
        });
    }
    var items = [];
    var single = parseTarget2(gg.value);
    function parseTarget2(v) {
      var n = parseFloat(v);
      return isFinite(n) ? n : null;
    }
    if (single != null) {
      items = [{ label: gg.label || "", value: single, max: num(gg.max, 100) }];
    } else {
      items = parseMulti(gg.content);
    }
    function render(items) {
      if (!items.length) {
        items = [{ label: gg.label || "仪表", value: num(gg.value, 0) || 0, max: num(gg.max, 100) }];
      }
      el.innerHTML = "";
      var box = document.createElement("div");
      box.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;display:flex;"
        + "flex-direction:column;padding:" + (pad + .6) + "vh " + (pad + 1) + "vh;box-sizing:border-box;" + visCss(z);
      if (gg.title) {
        var hd = document.createElement("div");
        hd.style.cssText = "flex:0 0 auto;display:flex;align-items:center;margin-bottom:.4vh;"
          + "color:" + (gg.color || "#eaf1ff") + ";font:bold " + clamp(num(gg.size, 2.4), .8, 8) + "vh '"
          + (gg.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;";
        var ic = iconSvg(gg.icon || "chart", clamp(num(gg.size, 2.4), .8, 8));
        if (ic) { hd.appendChild(ic); }
        var ht = document.createElement("span");
        ht.style.cssText = "margin-left:.8vh;";
        ht.textContent = gg.title;
        hd.appendChild(ht);
        box.appendChild(hd);
      }
      var body = document.createElement("div");
      body.style.cssText = "flex:1 1 auto;min-height:0;display:flex;align-items:stretch;justify-content:space-around;";
      box.appendChild(body);
      items.slice(0, 4).forEach(function (it) {
        body.appendChild(makeGauge(it, clamp(num(gg.size, 4), 1, 12)));
      });
      el.appendChild(box);
    }
    function makeGauge(it, size) {
      var gbox = document.createElement("div");
      gbox.style.cssText = "flex:1 1 0;display:flex;flex-direction:column;align-items:center;justify-content:center;"
        + "min-width:0;color:" + (gg.color || "#eaf1ff") + ";";
      var NS = "http://www.w3.org/2000/svg";
      var svg = document.createElementNS(NS, "svg");
      svg.setAttribute("viewBox", "0 0 200 120");
      svg.style.cssText = "width:100%;max-height:72%;flex:0 1 auto;";
      var cx = 100, cy = 100, r = 82;
      function arcPath(a0, a1) {
        // 半圆仪表：180°~360°(即左到右)
        var x0 = cx + r * Math.cos(a0), y0 = cy + r * Math.sin(a0);
        var x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
        var large = (a1 - a0) > Math.PI ? 1 : 0;
        return "M " + x0 + " " + y0 + " A " + r + " " + r + " 0 " + large + " 1 " + x1 + " " + y1;
      }
      var bgArc = document.createElementNS(NS, "path");
      bgArc.setAttribute("d", arcPath(Math.PI, 2 * Math.PI));
      bgArc.setAttribute("fill", "none");
      bgArc.setAttribute("stroke", ringCol);
      bgArc.setAttribute("stroke-width", "14");
      bgArc.setAttribute("stroke-linecap", "round");
      svg.appendChild(bgArc);
      var valArc = document.createElementNS(NS, "path");
      valArc.setAttribute("d", arcPath(Math.PI, 2 * Math.PI));
      valArc.setAttribute("fill", "none");
      valArc.setAttribute("stroke-width", "14");
      valArc.setAttribute("stroke-linecap", "round");
      svg.appendChild(valArc);
      var txt = document.createElementNS(NS, "text");
      txt.setAttribute("x", "100"); txt.setAttribute("y", "86");
      txt.setAttribute("text-anchor", "middle");
      txt.setAttribute("fill", gg.color || "#ffffff");
      txt.setAttribute("font-size", "30");
      txt.setAttribute("font-weight", "bold");
      svg.appendChild(txt);
      var lab = document.createElementNS(NS, "text");
      lab.setAttribute("x", "100"); lab.setAttribute("y", "108");
      lab.setAttribute("text-anchor", "middle");
      lab.setAttribute("fill", gg.color || "#ffffff");
      lab.setAttribute("opacity", ".75");
      lab.setAttribute("font-size", "15");
      svg.appendChild(lab);
      gbox.appendChild(svg);
      var capt = document.createElement("div");
      capt.style.cssText = "font:" + (size * .34) + "vh '" + (gg.font || "sans-serif")
        + "','Noto Sans CJK SC',sans-serif;opacity:.85;white-space:nowrap;overflow:hidden;"
        + "text-overflow:ellipsis;max-width:100%;margin-top:.3vh;color:inherit;";
      capt.textContent = it.label;
      gbox.appendChild(capt);
      // 弧长动画（0 -> 值）
      var pct = clamp(it.value / (it.max || 100), 0, 1);
      var col = valColor(pct * 100);
      valArc.setAttribute("stroke", col);
      txt.textContent = Math.round(it.value * 10) / 10 + (gg.unit || "");
      if (it.label) { lab.textContent = ""; capt.textContent = it.label; }
      var totLen = Math.PI * r;
      valArc.style.strokeDasharray = "0 " + totLen;
      try {
        valArc.animate(
          [{ strokeDasharray: "0 " + totLen }, { strokeDasharray: (totLen * pct) + " " + totLen }],
          { duration: 1400, easing: "cubic-bezier(.4,0,.2,1)", fill: "forwards" });
      } catch (e) { valArc.style.strokeDasharray = (totLen * pct) + " " + totLen; }
      return gbox;
    }
    render(items);
    if (gg.datasrc) {
      pollDatasrc(gg.datasrc, gg.refresh, function (j) {
        var list = Array.isArray(j) ? j : (j.items || []);
        var its = list.map(function (x) {
          return { label: x.label || x.name || "", value: parseFloat(x.value) || 0, max: parseFloat(x.max) || 100 };
        });
        if (its.length) { render(its); }
      });
    }
  }

  // ---------- 天气窗（v5：离网静态数据；LEDvision 天气窗的离线等价物） ----------
  // text.txt：首行 城市；之后每行 日期,天气,最高,最低（支持 DATASRC JSON 刷新）
  function makeWeatherZone(z, el) {
    var ww = z.weather || {};
    var pad = num(z.padding, 1);
    var wsz = clamp(num(ww.size, 3.2), .8, 12);
    if (!z.gradient) { zoneBg(el, z, ww.bgcolor || "linear-gradient(160deg,#123a5e,#0b1a2e)"); }
    function iconOf(text) {
      var t = String(text || "");
      if (/雨/.test(t)) { return "rain"; }
      if (/雪/.test(t)) { return "snow"; }
      if (/雾|霾/.test(t)) { return "fog"; }
      if (/阴/.test(t)) { return "cloud"; }
      if (/多云/.test(t)) { return "cloud"; }
      if (/晴/.test(t)) { return "sun"; }
      return "cloud";
    }
    function parse(content) {
      var lines = String(content || "").replace(/\r/g, "").split("\n")
        .filter(function (s) { return s.trim() !== ""; });
      if (!lines.length) { return null; }
      var city = lines[0].split(",")[0].trim();
      var days = lines.slice(1).map(function (ln) {
        var p = ln.split(",").map(function (x) { return x.trim(); });
        return { date: p[0] || "", text: p[1] || "", hi: p[2] || "", lo: p[3] || "" };
      });
      return { city: city, days: days };
    }
    function render(w) {
      if (!w || !w.days || !w.days.length) { el.appendChild(dimLabel("天气窗[" + z.name + "] 缺 text.txt")); return; }
      el.innerHTML = "";
      var box = document.createElement("div");
      box.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;display:flex;"
        + "flex-direction:column;padding:" + (pad + .8) + "vh " + (pad + 1.2) + "vh;box-sizing:border-box;"
        + "color:" + (ww.color || "#eaf4ff") + ";" + visCss(z);
      var today = w.days[0];
      var top = document.createElement("div");
      top.style.cssText = "flex:0 0 auto;display:flex;align-items:center;justify-content:space-between;";
      var city = document.createElement("div");
      city.style.cssText = "font:bold " + clamp(wsz, .8, 10) + "vh '"
        + (ww.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;opacity:.92;";
      city.textContent = w.city || "本地";
      top.appendChild(city);
      var dnow = document.createElement("div");
      dnow.style.cssText = "font:" + clamp(wsz * .8, .6, 8) + "vh '"
        + (ww.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;opacity:.7;";
      var d = new Date();
      dnow.textContent = "{Y}-{M}-{D} 星期{W}".replace(/\{Y\}/g, d.getFullYear())
        .replace(/\{M\}/g, pad2(d.getMonth() + 1)).replace(/\{D\}/g, pad2(d.getDate()))
        .replace(/\{W\}/g, WEEKS[d.getDay()]);
      top.appendChild(dnow);
      box.appendChild(top);
      var mid = document.createElement("div");
      mid.style.cssText = "flex:1 1 auto;min-height:0;display:flex;align-items:center;justify-content:center;gap:2.4vh;";
      var bigIcon = iconSvg(iconOf(today.text), clamp(wsz * 2.4, 2, 24));
      if (bigIcon) { mid.appendChild(bigIcon); }
      var tcol = document.createElement("div");
      tcol.style.cssText = "display:flex;flex-direction:column;align-items:flex-start;";
      var hi = document.createElement("div");
      hi.style.cssText = "font:bold " + clamp(wsz * 2, 1, 14) + "vh '"
        + (ww.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;font-variant-numeric:tabular-nums;";
      hi.textContent = today.hi + "°";
      var lo = document.createElement("div");
      lo.style.cssText = "font:" + clamp(wsz * 1.1, .6, 7) + "vh '"
        + (ww.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;opacity:.75;";
      lo.textContent = today.lo + "°";
      tcol.appendChild(hi); tcol.appendChild(lo);
      mid.appendChild(tcol);
      var txt = document.createElement("div");
      txt.style.cssText = "font:" + clamp(wsz * 1.05, .6, 7) + "vh '"
        + (ww.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;";
      txt.textContent = today.text;
      mid.appendChild(txt);
      box.appendChild(mid);
      if (w.days.length > 1) {
        var fc = document.createElement("div");
        fc.style.cssText = "flex:0 0 auto;display:flex;justify-content:space-around;"
          + "border-top:1px solid rgba(255,255,255,.18);padding-top:.8vh;";
        w.days.slice(1, 6).forEach(function (dy) {
          var cell = document.createElement("div");
          cell.style.cssText = "flex:1 1 0;display:flex;flex-direction:column;align-items:center;gap:.3vh;"
            + "font:" + clamp(wsz * .8, .6, 6) + "vh '"
            + (ww.font || "sans-serif") + "','Noto Sans CJK SC',sans-serif;";
          var dd = document.createElement("div");
          dd.style.cssText = "opacity:.7;";
          dd.textContent = dy.date;
          var ic2 = iconSvg(iconOf(dy.text), clamp(wsz * 1.15, 1, 9));
          var tx2 = document.createElement("div");
          tx2.textContent = dy.text;
          var tr2 = document.createElement("div");
          tr2.style.cssText = "font-variant-numeric:tabular-nums;";
          tr2.textContent = dy.hi + "°/" + dy.lo + "°";
          cell.appendChild(dd);
          if (ic2) { cell.appendChild(ic2); }
          cell.appendChild(tx2); cell.appendChild(tr2);
          fc.appendChild(cell);
        });
        box.appendChild(fc);
      }
      el.appendChild(box);
    }
    render(parse(ww.content));
    if (ww.datasrc) {
      pollDatasrc(ww.datasrc, ww.refresh, function (j) {
        var w2 = { city: j.city || "本地", days: (j.days || []).map(function (x) {
          return { date: x.date || "", text: x.text || "", hi: String(x.hi != null ? x.hi : ""), lo: String(x.lo != null ? x.lo : "") };
        }) };
        if (w2.days.length) { render(w2); }
      });
    }
  }

  // ---------- 地图窗（v6：离线自定义 SVG 地图，区域高亮呼吸 + 脉冲标记 + 底图模糊/压暗/透明叠加） ----------
  // text.txt 第 1 行: SVG 相对路径（如 maps/china.svg）或内置名（中国/世界/园区/楼层）
  // 其后每行: 标题:xx / 域:名称1,名称2（高亮区，按 data-region 匹配）
  //           点:名称,x%,y%[,数值] / 图例:项1,项2
  // style.txt: MAP_COLOR=强调色 MAP_COLOR2=标记色 MAP_FILL=区域底色rgba MAP_TINT=0-90压暗
  //           MAP_BLUR=vh底图模糊(标记点不糊) TITLE=角标标题
  var MAP_BUILTIN = { "中国": "maps/china.svg", "中国地图": "maps/china.svg",
    "世界": "maps/world.svg", "世界地图": "maps/world.svg",
    "园区": "maps/campus.svg", "园区地图": "maps/campus.svg", "园区平面": "maps/campus.svg",
    "楼层": "maps/floor.svg", "楼层地图": "maps/floor.svg", "楼层平面": "maps/floor.svg" };
  function makeMapZone(z, el) {
    var mp = z.map || {};
    var lines = String(mp.content || "").replace(/\r/g, "").split("\n")
      .map(function (s) { return s.trim(); })
      .filter(function (s) { return s !== "" && s.charAt(0) !== "#"; });
    if (!lines.length) {
      el.appendChild(dimLabel("地图窗[" + z.name + "] text.txt 写 SVG 路径，如 maps/china.svg"));
      return;
    }
    var src = lines[0];
    if (MAP_BUILTIN[src]) { src = MAP_BUILTIN[src]; }
    var accent = String(mp.map_color || "#ffd54a").trim();
    var accent2 = String(mp.map_color2 || "#c8102e").trim();
    var baseFill = String(mp.map_fill || "").trim();
    var tint = clamp(num(mp.map_tint, 0), 0, 90);
    var mblur = num(mp.map_blur, 0);
    var title = mp.title ? String(mp.title) : "";
    var regions = [], pins = [], legend = [];
    // v7 分区颜色/透明度定制：text.txt 写  色:北京=#ff4d4f,上海=#ffd54a  明度:北京=60,上海=35
    // 全局未高亮分区透明度：style.txt REGION_ALPHA=0-100
    var regionColor = {}, regionAlpha = {};
    var baseAlpha = clamp(num(mp.region_alpha, -1), -1, 100);
    function splitList(s) {
      return String(s).split(/[,，、]/).map(function (x) { return x.trim(); })
        .filter(function (x) { return x !== ""; });
    }
    lines.slice(1).forEach(function (ln) {
      var ci = ln.indexOf(":");
      if (ci < 0) { return; }
      var key = ln.slice(0, ci).trim();
      var val = ln.slice(ci + 1).trim();
      if (key === "标题") { title = val; }
      else if (key === "域") { regions = regions.concat(splitList(val)); }
      else if (key === "图例") { legend = legend.concat(splitList(val)); }
      else if (key === "色") {
        splitList(val).forEach(function (pair) {
          var ei = pair.indexOf("=");
          if (ei > 0) { regionColor[pair.slice(0, ei).trim()] = pair.slice(ei + 1).trim(); }
        });
      }
      else if (key === "明度") {
        splitList(val).forEach(function (pair) {
          var ei = pair.indexOf("=");
          if (ei > 0) { regionAlpha[pair.slice(0, ei).trim()] = parseFloat(pair.slice(ei + 1)); }
        });
      }
      else if (key === "点") {
        var f = val.split(",");
        if (f.length >= 3) {
          pins.push({ name: f[0].trim(), x: parseFloat(f[1]), y: parseFloat(f[2]), value: (f[3] || "").trim() });
        }
      }
    });
    var wrap = document.createElement("div");
    wrap.className = "mb-map";
    wrap.style.setProperty("--mbma", accent);
    wrap.style.setProperty("--mbma2", accent2);
    wrap.style.setProperty("--mbmhi", baseFill || "rgba(255,213,74,.20)");
    wrap.style.setProperty("--mbmfill", baseFill || "rgba(90,140,255,.10)");
    el.appendChild(wrap);
    var canvas = document.createElement("div");
    canvas.className = "mb-map-canvas";
    if (mblur > 0 && !perfLow()) { canvas.style.filter = "blur(" + clamp(mblur, 0.2, 12) + "vh)"; }
    wrap.appendChild(canvas);
    // 压暗层（底图与高亮之上、标记之下，半透明叠加）
    if (tint > 0) {
      var tv = document.createElement("div");
      tv.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
        + "background:rgba(4,8,16," + (tint / 100).toFixed(2) + ");";
      wrap.appendChild(tv);
    }
    try {
      var xhr = new XMLHttpRequest();
      xhr.open("GET", src, true);
      xhr.onload = function () {
        if (xhr.status !== 0 && xhr.status !== 200) {
          canvas.appendChild(dimLabel("地图加载失败: " + src));
          return;
        }
        canvas.innerHTML = String(xhr.responseText || "");
        var sv = canvas.querySelector("svg");
        if (!sv) { canvas.appendChild(dimLabel("非 SVG 文件: " + src)); return; }
        sv.removeAttribute("width"); sv.removeAttribute("height");
        // v6.1 域高亮支持短名匹配（写"北京"可命中 data-region="北京市"）
        var hiList = regions.map(function (r) { return String(r); });
        var hiTest = function (rn, rid) {
          if (!rn && !rid) { return false; }
          for (var i = 0; i < hiList.length; i++) {
            var t = hiList[i];
            if (rn === t || rid === t) { return true; }              // 全名精确
            if ((rn && (rn.indexOf(t) === 0 || rn.indexOf(t) > 0)) ||
                (rid && (rid.indexOf(t) === 0 || rid.indexOf(t) > 0))) { return true; } // 短名包含（北京市/广东省/…自治区）
          }
          return false;
        };
        var nodes = canvas.querySelectorAll("[data-region]");
        // v7 分区颜色/透明度：命中即改内联 fill / fill-opacity（优先级高于高亮类）
        function regionHit(map, rn, rid) {
          for (var kk in map) {
            if (!map.hasOwnProperty(kk)) { continue; }
            if (rn === kk || rid === kk) { return map[kk]; }
            if ((rn && rn.indexOf(kk) >= 0) || (rid && rid.indexOf(kk) >= 0)) { return map[kk]; }
          }
          return null;
        }
        for (var k = 0; k < nodes.length; k++) {
          var rname = nodes[k].getAttribute("data-region") || "";
          var rid2 = nodes[k].getAttribute("id") || "";
          if (hiTest(rname, rid2)) {
            nodes[k].classList.add("mb-map-hi");
          }
          var rc = regionHit(regionColor, rname, rid2);
          if (rc) {
            var rca = regionHit(regionAlpha, rname, rid2);
            var alphaV = (rca != null && isFinite(rca)) ? clamp(rca, 0, 100) / 100
              : (baseAlpha >= 0 ? baseAlpha / 100 : 0.82);
            var rgba = hexToRgba(rc, alphaV);
            if (rgba) { nodes[k].style.fill = rgba; nodes[k].classList.remove("mb-map-hi"); }
          } else {
            var ra = regionHit(regionAlpha, rname, rid2);
            if (ra != null && isFinite(ra)) {
              nodes[k].style.fillOpacity = String(clamp(ra, 0, 100) / 100);
            } else if (baseAlpha >= 0) {
              nodes[k].style.fillOpacity = String(baseAlpha / 100);
            }
          }
        }
      };
      xhr.onerror = function () { canvas.appendChild(dimLabel("地图加载失败: " + src)); };
      xhr.send();
    } catch (e) {
      canvas.appendChild(dimLabel("地图加载失败: " + src));
    }
    pins.forEach(function (p) {
      if (!isFinite(p.x) || !isFinite(p.y)) { return; }
      var pin = document.createElement("div");
      pin.className = "mb-map-pin";
      pin.style.left = clamp(p.x, 0, 100) + "%";
      pin.style.top = clamp(p.y, 0, 100) + "%";
      wrap.appendChild(pin);
      var lab = document.createElement("div");
      lab.className = "mb-map-label";
      lab.textContent = p.name + (p.value ? " · " + p.value : "");
      lab.style.left = clamp(p.x, 0, 100) + "%";
      lab.style.top = clamp(p.y, 0, 100) + "%";
      wrap.appendChild(lab);
    });
    if (legend.length) {
      var lg = document.createElement("div");
      lg.className = "mb-map-legend";
      legend.forEach(function (t) {
        var sp = document.createElement("span");
        var dot = document.createElement("i");
        sp.appendChild(dot);
        sp.appendChild(document.createTextNode(t));
        lg.appendChild(sp);
      });
      wrap.appendChild(lg);
    }
    if (title) {
      var tb = document.createElement("div");
      tb.className = "mb-map-title";
      tb.textContent = title;
      wrap.appendChild(tb);
    }
  }

  // ---------- 网页窗（v5：本地 HTML 内嵌 iframe，离网交互挂件位） ----------
  function makeWebZone(z, el) {
    var wb = z.web || {};
    var src = String(wb.url || wb.content || "").trim();
    if (!src) { el.appendChild(dimLabel("网页窗[" + z.name + "] text.txt 里写本地html路径")); return; }
    var ifr = document.createElement("iframe");
    ifr.src = src;
    ifr.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;border:0;background:#fff;";
    el.appendChild(ifr);
  }

  // ---------- 节目页（分区容器与分块特效） ----------
  function zoneBoxCss(z) {
    var m = clamp(num(z.margin, 0), 0, 20);
    var css = "position:absolute;overflow:hidden;"
      + "left:" + (num(z.x, 0) + m) + "%;top:" + (num(z.y, 0) + m) + "%;"
      + "width:" + Math.max(2, num(z.w, 100) - 2 * m) + "%;height:" + Math.max(2, num(z.h, 100) - 2 * m) + "%;";
    // LAYER: 1 为最顶层，数字越大越靠后（与 LEDvision 一致）；未设置则按书写顺序叠放
    if (z.layer) { css += "z-index:" + Math.max(1, 101 - clamp(Math.round(num(z.layer, 0)), 1, 99)) + ";"; }
    if (z.opacity != null && z.opacity !== "") {
      css += "opacity:" + (clamp(num(z.opacity, 100), 0, 100) / 100) + ";";
    }
    // v6 框型：切角族(clip-path)会裁掉边框与投影，自动忽略 BORDER/CARD
    var frame = frameOf(z);
    var clipFrame = FRAMES_CLIP[frame] ? frame : "";
    if (z.radius) { css += "border-radius:" + clamp(num(z.radius, 1), 0, 10) + "vh;"; }
    else if (frame === "capsule") { css += "border-radius:99vh;"; }
    else if (truthy(z.card) || frame === "rounded" || frame === "arch" || frame === "bookmark") { css += "border-radius:1.2vh;"; }
    if (truthy(z.card) && !perfLow() && !clipFrame && !truthy(z.glass)) {
      css += "box-shadow:0 .3vh .8vh rgba(0,0,0,.45),0 1.2vh 3vh rgba(0,0,0,.25);";
    }
    // v6 磨砂玻璃参数化：GLASS_ALPHA(0-100)/GLASS_COLOR=#hex/GLASS_BLUR=vh；双边框与高光由 .mb-glass 提供
    if (truthy(z.glass) && !perfLow() && !z.gradient) {
      var gA = clamp(num(z.glass_alpha, 10), 0, 100) / 100;
      var gC = hexToRgba(z.glass_color, gA);
      css += "background:" + (gC || "rgba(255,255,255," + gA + ")") + ";";
      var gB = clamp(num(z.glass_blur, 1.5), 0.2, 6);
      css += "-webkit-backdrop-filter:blur(" + gB + "vh) saturate(1.35);backdrop-filter:blur(" + gB + "vh) saturate(1.35);";
    }
    // v5 分区背景图（ZBG=textures/vignette.png 或任意相对路径；v7 增 ZBG_FIT/ZBG_POS）
    if (z.zbg) {
      css += "background-image:url('" + z.zbg + "');background-size:" + (z.zbg_fit || "cover")
        + ";background-position:" + (z.zbg_pos || "center") + ";background-repeat:no-repeat;";
    }
    // v5 分区边框：BORDER=#hex 或 BORDER=#hex,宽vh（0.3 默认）；LEDvision 窗口边框等价物
    if (z.border && !clipFrame) {
      var bparts = String(z.border).split(",");
      var bcol = (bparts[0] || "#ffffff").trim();
      var bw = clamp(parseFloat(bparts[1]) || 0.3, 0, 5);
      css += "border:" + bw + "vh solid " + bcol + ";box-sizing:border-box;";
    }
    if (z.gradient) {
      var ab = String(z.gradient).split(",");
      var a = (ab[0] || "#101820").trim(), b = (ab[1] || ab[0] || "#1a3a6b").trim();
      css += "background:linear-gradient(135deg," + a + "," + b + ");";
    }
    // v6 区域整体模糊（图片/PPT 区打底模糊，与半透明层叠加出景深）
    if (z.blur != null && z.blur !== "" && !perfLow()) {
      css += "filter:blur(" + clamp(num(z.blur, 2), 0.2, 30) + "vh);";
    }
    // EDGE_MASK：四边渐隐融入背景（柔和边缘）。yes=6%，或 EDGE_MASK=4~30 自定义百分比
    if (z.edge_mask && !perfLow()) {
      var emp = truthy(z.edge_mask) ? 6 : clamp(num(z.edge_mask, 0), 0, 30);
      if (emp > 0) {
        var mh = "linear-gradient(90deg,rgba(0,0,0,0),rgba(0,0,0,1) " + emp + "%,rgba(0,0,0,1) " + (100 - emp) + "%,rgba(0,0,0,0))";
        var mv = "linear-gradient(180deg,rgba(0,0,0,0),rgba(0,0,0,1) " + emp + "%,rgba(0,0,0,1) " + (100 - emp) + "%,rgba(0,0,0,0))";
        css += "-webkit-mask-image:" + mh + "," + mv + ";-webkit-mask-composite:source-in;"
          + "mask-image:" + mh + "," + mv + ";mask-composite:intersect;";
      }
    }
    return css;
  }
  // F-07 修复（v7.1）：窗型底色与分区背景图(ZBG)共存。
  // 根因：各窗型用 el.style.background 简写赋底色，简写会连带清空 zoneBoxCss
  // 已写入的 background-image，导致 ZBG 对 12 种窗口全部不生效。
  // 修复：统一走本助手——纯色改 backgroundColor 长属性（不清图）；渐变仅在
  // 无 ZBG 时使用（有 ZBG 时图优先，渐变忽略）。
  function zoneBg(el, z, v) {
    v = v || "";
    if (!v) { return; }
    if (z && z.zbg) {
      if (!/gradient\(/.test(v)) { el.style.backgroundColor = v; }
      return;
    }
    if (/gradient\(/.test(v)) { el.style.background = v; }
    else { el.style.backgroundColor = v; }
  }
  function makeZone(z, host) {
    var el = document.createElement("div");
    el.style.cssText = zoneBoxCss(z);
    el._mbZone = z;
    // v6 框型类与颜色变量（颜色用 FRAME_COLOR / FRAME_COLOR2 定制，默认鎏金/正红）
    var frame = frameOf(z);
    if (frame && frame !== "rounded" && frame !== "capsule" && frame !== "arch" && frame !== "bookmark") {
      el.classList.add("mb-f-" + frame);
      el.style.setProperty("--mbf", String(z.frame_color || "#ffd54a").trim());
      el.style.setProperty("--mbf2", String(z.frame_color2 || "#c8102e").trim());
      el.style.setProperty("--mbfa", String(z.frame_color || "#4d9fff").trim());
    }
    if (truthy(z.glass) && !perfLow() && !z.gradient) { el.classList.add("mb-glass"); }
    (host || stage).appendChild(el);
    // v5 分区标题栏（LEDvision 窗口带标题条的形态）：TITLEBAR=yes 时用 TITLE 或分区名
    // v6：TITLEBAR_SHAPE=ribbon 丝带梯形标题栏（党团宣传用）
    if (truthy(z.titlebar)) {
      var tbar = document.createElement("div");
      var tcol = z.titlebar_color || (z.gradient ? String(z.gradient).split(",")[0].trim() : "#1d4ed8");
      tbar.style.cssText = "position:absolute;top:0;left:0;width:100%;height:4.6vh;display:flex;"
        + "align-items:center;padding:0 1.2vh;box-sizing:border-box;z-index:3;"
        + "background:" + tcol + ";color:#fff;font:bold 2.1vh 'Noto Sans CJK SC','WenQuanYi Micro Hei',sans-serif;";
      if (String(z.titlebar_shape || "").toLowerCase() === "ribbon") {
        tbar.style.cssText += "clip-path:polygon(0 0,100% 0,96.5% 100%,3.5% 100%);"
          + "background:linear-gradient(90deg," + (z.frame_color2 || "#c8102e") + "," + (z.frame_color || "#ffd54a") + ");";
      }
      var ti = iconSvg(z.icon || "info", 2.3);
      if (ti) { tbar.appendChild(ti); }
      var tspan = document.createElement("span");
      tspan.style.cssText = "margin-left:.7vh;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
      tspan.textContent = z.title || z.name || "";
      tbar.appendChild(tspan);
      el.appendChild(tbar);
      // 内容整体下让：后续内容渲染完后再加 padding-top
      setTimeout(function () {
        for (var k = 0; k < el.children.length; k++) {
          var ck = el.children[k];
          if (ck !== tbar && ck.style && ck.style.top === "0px" && ck.style.position === "absolute") {
            ck.style.top = "4.6vh"; ck.style.height = "calc(100% - 4.6vh)";
          }
        }
      }, 0);
    }
    if (z.clock) { makeClock(z, el); }
    else if (z.countdown) { makeCountdown(z, el); }
    else if (z.text) { makeTextZone(z, el); }
    else if (z.qr) { makeQrZone(z, el); }
    else if (z.notice) { makeNoticeZone(z, el); }
    else if (z.table) { makeTableZone(z, el); }
    else if (z.data) { makeDataZone(z, el); }
    else if (z.gauge) { makeGaugeZone(z, el); }
    else if (z.weather) { makeWeatherZone(z, el); }
    else if (z.web) { makeWebZone(z, el); }
    else if (z.map) { makeMapZone(z, el); }
    else { makeMediaZone(z, el); }
    applyDecor(z, el);
    applyGridFx(z, el);
    currentZones.push(z);
    // v6 TRANSPARENT=yes：强制清掉各窗型默认底色，做纯透明叠层（与 BLUR/OPACITY 组合出层次）
    // v7.1：改长属性清底色；分区背景图（ZBG）不被清掉，透明与分区底图可共存
    if (truthy(z.transparent)) {
      setTimeout(function () {
        el.style.backgroundColor = "transparent";
        if (!z.zbg) { el.style.backgroundImage = "none"; }
      }, 0);
    }
    return el;
  }
  // ---------- 分块特效 GRID_FX=4|9|16|25（对齐 LEDvision 16 分块；静态内容启用） ----------
  // 适用：文本/公告/计时/表格/数据/单张图片分区。视频、多图轮播、二维码、时钟为动态内容，
  // 分块克隆会丢状态或重复解码，自动降级为整窗入场（与 LEDvision 对视频的处理一致）。
  // GRID_FX_ORDER=diag(默认斜向)|random(随机)|row(逐行)|col(逐列)
  function gridFxAllowed(z) {
    if (perfLow() || perfMid()) { return false; }
    if (z.qr || z.clock || z.web || z.map) { return false; }
    if (z.slides) {
      if (z.slides.length !== 1) { return false; }
      if (isVideo(z.slides[0])) { return false; }
    }
    return true;
  }
  function applyGridFx(z, el) {
    var n = clamp(Math.round(num(z.grid_fx, 0)), 0, 25);
    var root = Math.round(Math.sqrt(n));
    if (root < 2 || root * root !== n) { return; }
    if (!gridFxAllowed(z)) { return; }
    var html = el.innerHTML;
    if (!html || !html.trim()) { return; }
    var cols = root, rows = root;
    var order = String(z.grid_fx_order || "diag");
    el.innerHTML = "";
    var blocks = [];
    var r, c, i = 0;
    for (r = 0; r < rows; r++) {
      for (c = 0; c < cols; c++, i++) {
        var b = document.createElement("div");
        b.style.cssText = "position:absolute;overflow:hidden;"
          + "left:" + (c * 100 / cols) + "%;top:" + (r * 100 / rows) + "%;"
          + "width:" + (100 / cols) + "%;height:" + (100 / rows) + "%;";
        var inner = document.createElement("div");
        inner.style.cssText = "position:absolute;width:" + (cols * 100) + "%;height:" + (rows * 100) + "%;"
          + "left:" + (-c * 100) + "%;top:" + (-r * 100) + "%;";
        inner.innerHTML = html;
        b.appendChild(inner);
        el.appendChild(b);
        blocks.push({ b: b, r: r, c: c });
      }
    }
    // 错峰顺序：斜向 / 随机 / 逐行 / 逐列
    function delayOf(bl, i2) {
      if (order === "random") { return Math.floor(Math.random() * blocks.length) * 55; }
      if (order === "row") { return i2 * 55; }
      if (order === "col") { return (bl.c * rows + bl.r) * 55; }
      return (bl.r + bl.c) * 90;
    }
    blocks.forEach(function (bl, i2) {
      try {
        bl.b.animate([{ opacity: 0, transform: "scale(.94)" }, { opacity: 1, transform: "scale(1)" }],
          { duration: 420, delay: delayOf(bl, i2), easing: EASE_STD, fill: "backwards" });
      } catch (e) {}
    });
  }
  // ---------- 播放规则：VALID 有效期 / PLAYS 播放次数 ----------
  var playCounts = {};
  var pausedBySchedule = false;
  var screenOffBySchedule = false;
  function todayStr() {
    var d = new Date();
    function p2(x) { return (x < 10 ? "0" : "") + x; }
    return d.getFullYear() + "-" + p2(d.getMonth() + 1) + "-" + p2(d.getDate());
  }
  function pageValid(p) {
    if (!p.valid) { return true; }
    var ab = String(p.valid).split("~");
    var t = todayStr();
    if (ab[0] && t < ab[0]) { return false; }
    if (ab[1] && t > ab[1]) { return false; }
    return true;
  }
  function pagePlayable(i) {
    var p = pages[i];
    if (!pageValid(p)) { return false; }
    // 时段节目单：只在指定页间循环（schedule.txt 的 HH:MM-HH:MM=pages:1,2 行）
    if (pageFilter && pageFilter.length) {
      if (pageFilter.indexOf(i) < 0) { return false; }
    }
    var lim = Math.round(num(p.plays, 0));
    if (lim > 0 && (playCounts[i] || 0) >= lim) { return false; }
    return true;
  }
  function anyPlayable() {
    for (var i = 0; i < pages.length; i++) { if (pagePlayable(i)) { return true; } }
    return false;
  }
  function nextPageIdx(from) {
    // 全部播完（PLAYS 用尽）时清零重新轮；VALID 过期的不复活
    if (!anyPlayable()) { playCounts = {}; }
    for (var k = 1; k <= pages.length; k++) {
      var j = (from + k) % pages.length;
      if (pagePlayable(j)) { return j; }
    }
    return (from + 1) % pages.length;
  }
  function firstPageIdx() {
    if (!anyPlayable()) { playCounts = {}; }
    for (var i = 0; i < pages.length; i++) { if (pagePlayable(i)) { return i; } }
    return 0;
  }
  // ---------- v6 分屏播放（SPLIT=2H/2V/3H/3V/3T/3L/4G/4H/4V；@PANE=N 把页归到第 N 屏） ----------
  // 各分屏独立轮播互不同步（LEDvision 分屏节目等价物）；未标 @PANE 的页归第 1 屏。
  var paneEls = [], panePages = [], paneStates = [];
  function splitRects(mode) {
    switch (String(mode || "").toUpperCase()) {
      case "2H": return [{ x: 0, y: 0, w: 50, h: 100 }, { x: 50, y: 0, w: 50, h: 100 }];
      case "2V": return [{ x: 0, y: 0, w: 100, h: 50 }, { x: 0, y: 50, w: 100, h: 50 }];
      case "3H": return [{ x: 0, y: 0, w: 33.34, h: 100 }, { x: 33.33, y: 0, w: 33.34, h: 100 }, { x: 66.66, y: 0, w: 33.34, h: 100 }];
      case "3V": return [{ x: 0, y: 0, w: 100, h: 33.34 }, { x: 0, y: 33.33, w: 100, h: 33.34 }, { x: 0, y: 66.66, w: 100, h: 33.34 }];
      case "3T": return [{ x: 0, y: 0, w: 100, h: 50 }, { x: 0, y: 50, w: 50, h: 50 }, { x: 50, y: 50, w: 50, h: 50 }];
      case "3L": return [{ x: 0, y: 0, w: 50, h: 100 }, { x: 50, y: 0, w: 50, h: 50 }, { x: 50, y: 50, w: 50, h: 50 }];
      case "4G": return [{ x: 0, y: 0, w: 50, h: 50 }, { x: 50, y: 0, w: 50, h: 50 }, { x: 0, y: 50, w: 50, h: 50 }, { x: 50, y: 50, w: 50, h: 50 }];
      case "4H": return [{ x: 0, y: 0, w: 25, h: 100 }, { x: 25, y: 0, w: 25, h: 100 }, { x: 50, y: 0, w: 25, h: 100 }, { x: 75, y: 0, w: 25, h: 100 }];
      case "4V": return [{ x: 0, y: 0, w: 100, h: 25 }, { x: 0, y: 25, w: 100, h: 25 }, { x: 0, y: 50, w: 100, h: 25 }, { x: 0, y: 75, w: 100, h: 25 }];
      default: return null;
    }
  }
  function hasSplit() { return !!splitRects(P.split); }
  function bootPanes() {
    var rects = splitRects(P.split);
    paneStates.forEach(function (st) { if (st.timer) { clearTimeout(st.timer); } });
    if (pageTimer) { clearTimeout(pageTimer); pageTimer = null; }
    stage.innerHTML = "";
    paneEls = []; panePages = []; paneStates = [];
    currentZones = [];
    var byPane = {};
    pages.forEach(function (pg, gi) {
      pg._gi = gi;
      var pn = clamp(Math.round(num(pg.pane, 1)), 1, rects.length);
      (byPane[pn] = byPane[pn] || []).push(pg);
    });
    rects.forEach(function (r, idx) {
      var n = idx + 1;
      var el = document.createElement("div");
      el.className = "mb-pane";
      el.style.cssText = "left:" + r.x + "%;top:" + r.y + "%;width:" + r.w + "%;height:" + r.h + "%;";
      stage.appendChild(el);
      paneEls.push(el);
      panePages.push(byPane[n] || []);
      paneStates.push({ idx: -1, timer: null });
      if ((byPane[n] || []).length) { renderPane(idx); }
      else { el.appendChild(dimLabel("分屏" + n + " 待编排（layout.txt 页内加 @PANE=" + n + "）")); }
    });
    updateDiag();
  }
  function panePick(pi, from) {
    var list = panePages[pi];
    if (!list.length) { return -1; }
    if (!list.some(function (pg) { return pagePlayable(pg._gi); })) {
      list.forEach(function (pg) { playCounts[pg._gi] = 0; });
    }
    for (var k = 1; k <= list.length; k++) {
      var j = (from + k) % list.length;
      if (pagePlayable(list[j]._gi)) { return j; }
    }
    return (from + 1) % list.length;
  }
  function renderPane(pi, li) {
    var st = paneStates[pi], list = panePages[pi], el = paneEls[pi];
    if (!list.length) { return; }
    if (st.timer) { clearTimeout(st.timer); st.timer = null; }
    st.idx = (li != null && li >= 0) ? li : panePick(pi, st.idx < 0 ? -1 : st.idx);
    if (st.idx < 0) { return; }
    var pg = list[st.idx];
    pageIdx = pg._gi;
    playCounts[pg._gi] = (playCounts[pg._gi] || 0) + 1;
    el.innerHTML = "";
    pg.zones.forEach(function (z) { makeZone(z, el); });
    updateDiag();
    if (!pausedBySchedule && list.length > 1 && num(pg.duration, 0) > 0) {
      st.timer = setTimeout(function () { paneSwitch(pi); }, num(pg.duration, 0) * 1000);
    }
  }
  function paneSwitch(pi) {
    var el = paneEls[pi];
    if (!el) { return; }
    el.style.transition = "opacity 350ms linear";
    el.style.opacity = "0";
    setTimeout(function () {
      renderPane(pi);
      el.style.opacity = "1";
      setTimeout(function () { el.style.transition = ""; }, 420);
    }, 360);
  }
  function gotoGlobalPage(n) {
    if (n < 0 || n >= pages.length) { return false; }
    if (hasSplit()) {
      for (var pi = 0; pi < panePages.length; pi++) {
        for (var li = 0; li < panePages[pi].length; li++) {
          if (panePages[pi][li]._gi === n) { pausedBySchedule = false; renderPane(pi, li); return true; }
        }
      }
      return false;
    }
    pausedBySchedule = false;
    renderPage(n);
    return true;
  }
  function renderPage(i) {
    if (pageTimer) { clearTimeout(pageTimer); pageTimer = null; }
    currentZones = [];
    stage.innerHTML = "";
    pageIdx = i;
    playCounts[i] = (playCounts[i] || 0) + 1;
    pages[i].zones.forEach(function (z) { makeZone(z, stage); });
    updateDiag();
    if (pages.length > 1 && num(pages[i].duration, 0) > 0 && !pausedBySchedule) {
      pageTimer = setTimeout(switchPage, num(pages[i].duration, 0) * 1000);
    }
  }
  function switchPage() {
    if (pageTimer) { clearTimeout(pageTimer); pageTimer = null; }
    if (pausedBySchedule) { return; }
    stage.style.transition = "opacity 350ms linear";
    stage.style.opacity = "0";
    setTimeout(function () {
      renderPage(nextPageIdx(pageIdx));
      stage.style.opacity = "1";
      setTimeout(function () { stage.style.transition = ""; }, 420);
    }, 360);
  }

  // ---------- 定时指令表 schedule.txt（v5 扩展） ----------
  // 每 20 秒对齐一次本机时钟；单点指令同一分钟只执行一次；
  // 时段行 HH:MM-HH:MM=pages:1,3 持续生效（在时段内只循环指定页，时段外自动解除）。
  // 单点指令: play:N pause resume screenoff screenon dim:N notify:文字 ticker:文字 reload
  var schedLast = "";
  var pageFilter = [];   // 时段节目单当前生效的页号集合
  var schedRange = null; // {a:分钟,b:分钟,pageNos:[]}
  function schedNow() {
    var d = new Date();
    return d.getHours() * 60 + d.getMinutes();
  }
  function applySchedule() {
    var list = P.schedule || [];
    if (!list.length) { return; }
    var d = new Date();
    var hm = (d.getHours() < 10 ? "0" : "") + d.getHours() + ":" + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes();
    // 时段行：持续判断（跨天区间允许，如 22:00-07:00）
    for (var i = 0; i < list.length; i++) {
      var it = list[i];
      if (it.range) {
        var now = schedNow();
        var on = it.a <= it.b ? (now >= it.a && now < it.b) : (now >= it.a || now < it.b);
        if (on && (!schedRange || schedRange.src !== it)) {
          schedRange = it;
          pageFilter = it.pageNos.slice();
          // 若当前页不在时段页集合里，立即切到集合内第一页
          if (pageFilter.indexOf(pageIdx) < 0) {
            var firstOk = -1;
            for (var k = 0; k < pageFilter.length; k++) { if (pagePlayable(pageFilter[k])) { firstOk = pageFilter[k]; break; } }
            if (firstOk >= 0) { gotoGlobalPage(firstOk); }
          }
        } else if (!on && schedRange === it) {
          schedRange = null; pageFilter = [];
        }
      }
    }
    if (hm === schedLast) { return; }
    for (var j = 0; j < list.length; j++) {
      if (list[j].range) { continue; }
      if (String(list[j].t) !== hm) { continue; }
      schedLast = hm;
      runScheduleCmd(String(list[j].cmd || ""));
    }
  }
  function runScheduleCmd(cmd) {
    if (cmd.indexOf("play:") === 0) {
      var n = Math.round(num(cmd.slice(5), 0)) - 1;
      gotoGlobalPage(n);
    } else if (cmd.indexOf("scheme:") === 0) {
      // v6 多方案热切换（schedule.txt: HH:MM=scheme:党建文化）
      loadScheme(cmd.slice(7).trim());
    } else if (cmd === "pause") {
      pausedBySchedule = true;
      if (pageTimer) { clearTimeout(pageTimer); pageTimer = null; }
      paneStates.forEach(function (st) { if (st.timer) { clearTimeout(st.timer); st.timer = null; } });
    } else if (cmd === "resume") {
      pausedBySchedule = false;
      if (hasSplit()) {
        paneStates.forEach(function (st, pi) {
          if (panePages[pi].length > 1 && st.idx >= 0 && num(panePages[pi][st.idx].duration, 0) > 0) {
            st.timer = setTimeout(function () { paneSwitch(pi); }, num(panePages[pi][st.idx].duration, 0) * 1000);
          }
        });
      } else if (pages.length > 1 && num(pages[pageIdx].duration, 0) > 0) {
        pageTimer = setTimeout(switchPage, num(pages[pageIdx].duration, 0) * 1000);
      }
    } else if (cmd === "screenoff" || cmd === "screenon") {
      screenOffBySchedule = (cmd === "screenoff");
      var ov = document.getElementById("mb-screenoff");
      if (screenOffBySchedule && !ov) {
        ov = document.createElement("div");
        ov.id = "mb-screenoff";
        ov.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;background:#000;z-index:99999;";
        document.body.appendChild(ov);
      } else if (!screenOffBySchedule && ov) {
        ov.parentNode.removeChild(ov);
      }
    } else if (cmd.indexOf("dim:") === 0) {
      // 亮度模拟（LED 屏硬调光做不到，用叠加层模拟调暗/调亮，0=全黑 100=原亮）
      var pct = clamp(num(cmd.slice(4), 100), 0, 100);
      var dv = document.getElementById("mb-dim");
      if (pct >= 100) {
        if (dv) { dv.parentNode.removeChild(dv); }
      } else {
        if (!dv) {
          dv = document.createElement("div");
          dv.id = "mb-dim";
          dv.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;background:#000;"
            + "z-index:99998;pointer-events:none;opacity:0;transition:opacity 1s linear;";
          document.body.appendChild(dv);
        }
        dv.style.opacity = String((100 - pct) / 100);
      }
    } else if (cmd.indexOf("notify:") === 0) {
      // 定时紧急插播（LEDvision 紧急通知等价物）
      showNotifyText(cmd.slice(7), num(P.notify && P.notify.minutes, 5));
    } else if (cmd.indexOf("ticker:") === 0) {
      // 定时换字幕内容（保留字幕样式，仅换文字）
      applyTicker(cmd.slice(7));
    } else if (cmd === "reload") {
      location.reload();
    }
  }

  // ---------- 动态背景 BGFX（v5：极光 aurora / 流动网格 gridmove / 粒子 particles） ----------
  // 零素材、纯 CSS/Canvas；PERF=low 全关，mid 只留 CSS 类，particles 仅 high。
  var bgfxRaf = null;
  function applyBgfx() {
    var bg = document.getElementById("bg");
    var old = document.getElementById("mb-bgfx");
    if (old) { old.parentNode && old.parentNode.removeChild(old); }
    if (bgfxRaf) { cancelAnimationFrame(bgfxRaf); bgfxRaf = null; }
    var mode = String(P.bgfx || "").trim().toLowerCase();
    if (!mode || mode === "off" || mode === "no") { return; }
    if (perfLow()) { return; }
    if (mode === "particles" && perfMid()) { mode = "aurora"; }
    if (mode === "particles") {
      var cv = document.createElement("canvas");
      cv.id = "mb-bgfx";
      cv.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;";
      bg.appendChild(cv);
      bg.style.display = "block";
      var ctx = cv.getContext("2d");
      if (!ctx) { return; }
      function resize() {
        cv.width = Math.max(320, window.innerWidth);
        cv.height = Math.max(240, window.innerHeight);
      }
      resize();
      window.addEventListener("resize", resize);
      var N = 70, dots = [];
      for (var i = 0; i < N; i++) {
        dots.push({ x: Math.random() * cv.width, y: Math.random() * cv.height,
          r: 0.6 + Math.random() * 2.2, vx: (Math.random() - 0.5) * 0.22, vy: (Math.random() - 0.5) * 0.18,
          a: 0.25 + Math.random() * 0.55, tw: Math.random() * Math.PI * 2 });
      }
      var last = 0;
      function loop(ts) {
        bgfxRaf = requestAnimationFrame(loop);
        if (ts - last < 33) { return; } // ~30fps 封顶，ARM 软渲染省电
        last = ts;
        ctx.clearRect(0, 0, cv.width, cv.height);
        for (var k = 0; k < dots.length; k++) {
          var dt = dots[k];
          dt.x += dt.vx; dt.y += dt.vy; dt.tw += 0.02;
          if (dt.x < -5) { dt.x = cv.width + 5; }
          if (dt.x > cv.width + 5) { dt.x = -5; }
          if (dt.y < -5) { dt.y = cv.height + 5; }
          if (dt.y > cv.height + 5) { dt.y = -5; }
          var al = dt.a * (0.55 + 0.45 * Math.sin(dt.tw));
          ctx.beginPath();
          ctx.arc(dt.x, dt.y, dt.r, 0, Math.PI * 2);
          ctx.fillStyle = "rgba(190,225,255," + al.toFixed(3) + ")";
          ctx.fill();
        }
      }
      bgfxRaf = requestAnimationFrame(loop);
      return;
    }
    // CSS 类动态背景：aurora（极光色块漂浮）/ gridmove（流动网格）
    if (!document.getElementById("mb-bgfx-css")) {
      var st = document.createElement("style");
      st.id = "mb-bgfx-css";
      st.textContent =
        "@keyframes mbfx-a1{0%{transform:translate(-10%,-8%) scale(1)}50%{transform:translate(8%,6%) scale(1.18)}100%{transform:translate(-10%,-8%) scale(1)}}"
        + "@keyframes mbfx-a2{0%{transform:translate(12%,10%) scale(1.12)}50%{transform:translate(-8%,-6%) scale(1)}100%{transform:translate(12%,10%) scale(1.12)}}"
        + "@keyframes mbfx-a3{0%{transform:translate(0%,4%) scale(1)}50%{transform:translate(4%,-6%) scale(1.22)}100%{transform:translate(0%,4%) scale(1)}}"
        + "@keyframes mbfx-grid{0%{background-position:0 0,0 0}100%{background-position:8vh 8vh,-8vh -8vh}}";
      document.head.appendChild(st);
    }
    var fx = document.createElement("div");
    fx.id = "mb-bgfx";
    fx.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;overflow:hidden;";
    if (mode === "aurora") {
      [["18%", "26%", "rgba(56,120,255,.36)", "26s", "mbfx-a1"],
       ["24%", "30%", "rgba(64,220,214,.30)", "34s", "mbfx-a2"],
       ["16%", "22%", "rgba(168,85,247,.26)", "44s", "mbfx-a3"]].forEach(function (cfg) {
        var blob = document.createElement("div");
        blob.style.cssText = "position:absolute;width:" + cfg[0] + ";height:" + cfg[1] + ";"
          + "background:radial-gradient(closest-side," + cfg[2] + ",rgba(0,0,0,0));"
          + "animation:" + cfg[4] + " " + cfg[3] + " linear infinite;";
        fx.appendChild(blob);
      });
    } else if (mode === "gridmove") {
      var gd = document.createElement("div");
      gd.style.cssText = "position:absolute;top:-8vh;left:-8vh;width:calc(100% + 16vh);height:calc(100% + 16vh);"
        + "background-image:linear-gradient(rgba(120,170,255,.14) 1px,transparent 1px),"
        + "linear-gradient(90deg,rgba(120,170,255,.14) 1px,transparent 1px);"
        + "background-size:8vh 8vh;animation:mbfx-grid 7s linear infinite;";
      fx.appendChild(gd);
    }
    bg.appendChild(fx);
    bg.style.display = "block";
  }

  // ---------- 背景 / 背景音乐 ----------
  function applyBackground() {
    document.body.style.background = P.bgcolor || "#000";
    var bg = document.getElementById("bg");
    var im = bg.querySelector(".mb-bg-img");
    if (P.bgimage) {
      bg.style.display = "block";
      if (!im) {
        im = document.createElement("div");
        im.className = "mb-bg-img";
        im.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;";
        bg.insertBefore(im, bg.firstChild); // 在 BGFX 动态层之下
      }
      im.style.display = "block";
      im.style.backgroundImage = "url('" + P.bgimage + "')";
      // v7 模板底图自定义可调：BG_FIT/BG_POS/BG_OPACITY/BG_BLUR/BG_DARKEN（settings.txt）
      im.style.backgroundSize = P.bg_fit || "cover";
      im.style.backgroundPosition = P.bg_pos || "center";
      im.style.backgroundRepeat = "no-repeat";
      im.style.opacity = (P.bg_opacity != null && P.bg_opacity !== "")
        ? String(clamp(num(P.bg_opacity, 100), 0, 100) / 100) : "1";
      if (num(P.bg_blur, 0) > 0 && !perfLow()) {
        im.style.filter = "blur(" + clamp(num(P.bg_blur, 0), 0.2, 12) + "vh)";
      } else { im.style.filter = ""; }
      // 底图压暗层（党政照片底图上放白字常用）
      var dark = clamp(num(P.bg_darken, 0), 0, 100);
      var tintEl = im.querySelector(".mb-bg-tint");
      if (dark > 0) {
        if (!tintEl) {
          tintEl = document.createElement("div");
          tintEl.className = "mb-bg-tint";
          im.appendChild(tintEl);
        }
        tintEl.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;"
          + "background:rgba(0,0,0," + (dark / 100).toFixed(2) + ");";
      } else if (tintEl) { tintEl.parentNode.removeChild(tintEl); }
    } else {
      bg.style.display = "none";
      if (im) { im.parentNode.removeChild(im); }
    }
  }
  function applyBgm() {
    var old = document.getElementById("mb-bgm");
    if (old) { old.parentNode.removeChild(old); }
    if (!P.bgmusic) { return; }
    try {
      var a = document.createElement("audio");
      a.id = "mb-bgm";
      a.src = P.bgmusic; a.loop = true; a.autoplay = true;
      a.volume = clamp(num(P.bgmusicVol, 0.6), 0, 1);
      document.body.appendChild(a);
      var pr = a.play();
      if (pr && pr.catch) { pr.catch(function () {}); }
    } catch (e) {}
  }

  // ---------- 通知插播（v5：支持定时指令与 notify.txt 热插播） ----------
  var notifyHideT = null;
  function showNotifyText(text, minutes) {
    if (!text || !String(text).trim()) { return; }
    var bar = document.getElementById("notify");
    var inner = document.getElementById("notify-inner");
    var h = clamp(num(P.notify && P.notify.height, 10), 4, 30);
    var fcss = "bold " + (h * 0.5) + "vh sans-serif";
    if (notifyHideT) { clearTimeout(notifyHideT); notifyHideT = null; }
    bar.style.display = "block";
    bar.style.height = h + "vh";
    bar.style.background = (P.notify && P.notify.bgcolor) || "#c00000";
    bar.style.color = (P.notify && P.notify.color) || "#ffffff";
    inner.style.cssText = "position:absolute;white-space:nowrap;will-change:transform;"
      + "line-height:" + h + "vh;font:" + fcss + ";color:inherit;"
      + "text-shadow:0 .2vh .6vh rgba(0,0,0,.5);";
    makeMarquee(bar, inner, {
      lines: [String(text).replace(/\r/g, "")], speed: 80, vertical: false, sep: "　　", font: fcss
    });
    notifyHideT = setTimeout(function () { bar.style.display = "none"; },
      clamp(num(minutes, 5), 0.2, 1440) * 60000);
  }
  function applyNotify() {
    document.getElementById("notify").style.display = "none";
    var nf = P.notify;
    if (!nf || !nf.text) { return; }
    showNotifyText(nf.text, num(nf.minutes, 5));
  }
  // notify.txt 文件热插播：每 30 秒 XHR 轮询，内容变化即插播（LEDvision 紧急通知等价）
  var notifyFileLast = null;
  function pollNotifyFile() {
    try {
      var xhr = new XMLHttpRequest();
      xhr.open("GET", "notify.txt", true);
      xhr.onload = function () {
        if (xhr.status === 0 || xhr.status === 200) {
          var txt = String(xhr.responseText || "").replace(/\r/g, "").trim();
          if (txt && txt !== notifyFileLast) {
            notifyFileLast = txt;
            showNotifyText(txt, num(P.notify && P.notify.minutes, 5));
          }
        }
      };
      xhr.onerror = function () {};
      xhr.send();
    } catch (e) {}
  }

  // ---------- 定时关屏 ----------
  function applyScreenOff() {
    var win = P.screenOff;
    if (!win) { return; }
    var m = /^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$/.exec(String(win).replace(/\s/g, ""));
    if (!m) { return; }
    var a = (+m[1]) * 60 + (+m[2]), b = (+m[3]) * 60 + (+m[4]);
    function check() {
      var d = new Date();
      var now = d.getHours() * 60 + d.getMinutes();
      var off = a <= b ? (now >= a && now < b) : (now >= a || now < b);
      document.getElementById("screenoff").style.display = off ? "block" : "none";
    }
    check();
    addIv(check, 20000);
  }

  // ---------- 底部滚动字幕（v5：支持定时指令换文字） ----------
  function applyTicker(textOverride) {
    var tk = P.ticker || {};
    var bar = document.getElementById("ticker");
    var inner = document.getElementById("ticker-inner");
    bar.style.display = "none";
    var srcText = (textOverride != null && String(textOverride).trim()) ? String(textOverride) : tk.text;
    if (!srcText || !String(srcText).trim()) { return; }
    var lines = String(srcText).replace(/\r/g, "").split("\n")
      .filter(function (s) { return s.trim() !== ""; });
    if (!lines.length) { return; }
    var h = clamp(num(tk.height, 9), 3, 30);
    var eff = tk.effect || "scroll-left";
    var fcss = fontCss(tk, 5.5);
    bar.style.display = "block";
    bar.style.height = h + "vh";
    // TICKER_POS=top|bottom；覆盖模式永远浮在所有分区之上（高于 LAYER 分区的 z-index）
    var posTop = String(tk.pos || "bottom") === "top";
    bar.style.top = posTop ? "0" : "auto";
    bar.style.bottom = posTop ? "auto" : "0";
    bar.style.zIndex = "9999";
    // TICKER_OVERLAY=no 时舞台给字幕条让位（分区不被压住）；yes（默认）浮在画面上
    var stageEl = document.getElementById("stage");
    if (stageEl) {
      if (tk.overlay === false) {
        stageEl.style.height = (100 - h) + "%";
        stageEl.style.top = posTop ? h + "%" : "0";
      } else {
        stageEl.style.height = "100%";
        stageEl.style.top = "0";
      }
    }
    bar.style.background = tk.bgcolor || "rgba(0,0,0,0.72)";
    bar.style.color = tk.color || "#ffff00";
    // 两端渐隐（Chromium 83: -webkit-mask-image 可用；低档位关闭）
    bar.style.webkitMaskImage = bar.style.maskImage = "";
    if (truthy(tk.mask) && !perfLow()) {
      var mk = "linear-gradient(90deg,rgba(0,0,0,0),rgba(0,0,0,1) 4%,rgba(0,0,0,1) 96%,rgba(0,0,0,0))";
      try { bar.style.webkitMaskImage = mk; bar.style.maskImage = mk; } catch (e) {}
    }
    var shadowCss = perfLow() ? "" : "text-shadow:0 .2vh .8vh rgba(0,0,0,.7);";
    var centered = "display:block;width:100%;text-align:center;line-height:" + h + "vh;"
      + "font:" + fcss + ";color:inherit;overflow:hidden;white-space:nowrap;" + shadowCss;
    if (eff === "static" || eff === "blink") {
      inner.style.cssText = centered;
      if (eff === "static") {
        inner.style.textOverflow = "ellipsis";
      } else {
        try { inner.animate([{ opacity: 1 }, { opacity: 0.15 }, { opacity: 1 }],
          { duration: 900, iterations: Infinity }); } catch (e) {}
      }
      inner.textContent = lines.join("　");
      return;
    }
    if (eff === "typewriter") {
      inner.style.cssText = centered;
      var chars = Array.from(lines.join("　"));
      var cps = clamp(num(tk.speed, 6), 0.5, 50);
      var ms = Math.round(1000 / cps);
      var i = 0, iv = null;
      function step() {
        i++;
        inner.textContent = chars.slice(0, i).join("");
        if (i >= chars.length) {
          clearInterval(iv); iv = null;
          setTimeout(function () {
            i = 0; inner.textContent = "";
            iv = setInterval(step, ms);
          }, 3000);
        }
      }
      iv = setInterval(step, ms);
      return;
    }
    inner.style.cssText = "position:absolute;white-space:nowrap;will-change:transform;"
      + "color:inherit;font:" + fcss + ";" + shadowCss
      + (eff === "scroll-up" ? "line-height:" + clamp(num(tk.linespacing, 1.4), 1, 3) + "em;"
         : "line-height:" + h + "vh;");
    makeMarquee(bar, inner, {
      lines: lines, speed: tk.speed, vertical: eff === "scroll-up",
      sep: tk.sep != null ? String(tk.sep) : "　　●　　", font: fcss
    });
  }

  // ---------- 诊断 ----------
  var diagOn = location.search.indexOf("diag") >= 0 && location.search.indexOf("selftest") < 0;
  function updateDiag() {
    if (!diagOn) { return; }
    var d = document.getElementById("mb-diag");
    if (!d) {
      d = document.createElement("pre");
      d.id = "mb-diag";
      d.style.cssText = "position:fixed;top:0;left:0;z-index:98;color:#0f0;background:#000;"
        + "font:12px monospace;margin:0;padding:3px;opacity:.85";
      document.body.appendChild(d);
    }
    var rects = [];
    for (var i = 0; i < stage.children.length; i++) {
      var el2 = stage.children[i];
      if (el2.classList && el2.classList.contains("mb-pane")) {
        rects.push("pane" + (i + 1) + "(页" + ((paneStates[i] && paneStates[i].idx >= 0 ? paneStates[i].idx + 1 : "-")) + ")");
        continue;
      }
      var z = el2._mbZone;
      var r = el2.getBoundingClientRect();
      rects.push((z && z.name ? z.name : "?") + "=" + Math.round(r.left) + "," + Math.round(r.top)
        + "," + Math.round(r.width) + "x" + Math.round(r.height));
    }
    d.textContent = "viewport=" + window.innerWidth + "x" + window.innerHeight
      + " dpr=" + (window.devicePixelRatio || 1)
      + " page=" + (pageIdx + 1) + "/" + pages.length
      + " | " + rects.join(" | ");
  }

  // ---------- 自检模式（?selftest=1：目标机拍照即证据） ----------
  function runSelftest() {
    var results = [];
    function add(name, ok, detail) {
      results.push({ name: name, ok: ok, detail: detail || "" });
    }
    add("WAAPI动画(el.animate)", typeof Element !== "undefined" && typeof Element.prototype.animate === "function", "特效引擎");
    add("CSS.supports", typeof CSS !== "undefined" && typeof CSS.supports === "function", "特性探测");
    if (typeof CSS !== "undefined" && CSS.supports) {
      add("clip-path 擦除转场", CSS.supports("clip-path", "inset(0 0 0 0)"));
      add("filter blur 模糊转场", CSS.supports("filter", "blur(2px)"));
      add("mask-image 字幕渐隐", CSS.supports("-webkit-mask-image", "linear-gradient(#000,#000)")
        || CSS.supports("mask-image", "linear-gradient(#000,#000)"));
      add("font-variant-numeric 等宽数字", CSS.supports("font-variant-numeric", "tabular-nums"));
      add("linear-gradient 渐变底", CSS.supports("background", "linear-gradient(135deg,#111,#222)")
        || CSS.supports("background-image", "linear-gradient(135deg,#111,#222)"));
      add("box-shadow 卡片投影", CSS.supports("box-shadow", "0 1px 2px rgba(0,0,0,.3)"));
      add("-webkit-text-stroke 描边", CSS.supports("-webkit-text-stroke", "1px #000"));
      add("backdrop-filter 玻璃拟态", CSS.supports("backdrop-filter", "blur(2px)")
        || CSS.supports("-webkit-backdrop-filter", "blur(2px)"));
      add("CSS 多列 瀑布流", CSS.supports("column-count", "2"));
      add("CSS animation 动态背景", CSS.supports("animation-name", "x"));
      add("CSS 变量 var()（框型/磨砂配色）", CSS.supports("color", "var(--x)"));
      add("conic-gradient 锥形渐变", CSS.supports("background", "conic-gradient(#fff,#fff)")
        || CSS.supports("background-image", "conic-gradient(#fff,#fff)"));
      add("mix-blend-mode 混合滤镜", CSS.supports("mix-blend-mode", "multiply"));
      add("writing-mode 竖排文本", CSS.supports("writing-mode", "vertical-rl"));
      add("clip-path polygon 多边形框型", CSS.supports("clip-path", "polygon(0 0,100% 0,100% 100%,0 100%)"));
      // F-07 回归防护（v7.1）：长属性 backgroundColor 不得清掉 background-image
      add("分区背景图 ZBG 装载", (function () {
        var d = document.createElement("div");
        d.style.cssText = "background-image:url(textures/vignette.png);background-size:cover;";
        d.style.backgroundColor = "rgba(0,0,0,.5)"; // 模拟窗型底色赋值
        return !!d.style.backgroundImage;
      })(), "background 简写隔离");
    }
    add("canvas 2D(二维码绘制)", (function () {
      try { return !!document.createElement("canvas").getContext("2d"); } catch (e) { return false; }
    })());
    add("二维码库 qr.js", typeof window.qrcode === "function");
    add("本地存储 localStorage", (function () {
      try { localStorage.setItem("mb_t", "1"); localStorage.removeItem("mb_t"); return true; }
      catch (e) { return false; }
    })());
    var v = document.createElement("video");
    add("H.264视频解码", /^(probably|maybe)$/.test(v.canPlayType('video/mp4; codecs="avc1.42E01E"'))
      ? v.canPlayType('video/mp4; codecs="avc1.42E01E"') : false, v.canPlayType('video/mp4; codecs="avc1.42E01E"'));
    add("MP3音频解码", /^(probably|maybe)$/.test(v.canPlayType("audio/mpeg")) ? v.canPlayType("audio/mpeg") : false);
    add("系统内存可见", !!(window.performance && performance.memory),
      performance && performance.memory ? Math.round(performance.memory.jsHeapSizeLimit / 1048576) + "MB上限" : "不可读(正常)");
    // 渲染结果页（大字，拍照即证据）
    document.body.innerHTML = "";
    var box = document.createElement("div");
    box.style.cssText = "position:absolute;top:0;left:0;width:100%;height:100%;overflow:auto;"
      + "background:#0a0a0a;color:#eee;padding:2vh 3vh;box-sizing:border-box;"
      + "font:2.6vh 'Noto Sans CJK SC','WenQuanYi Micro Hei',sans-serif;cursor:default;";
    var title = document.createElement("h1");
    title.style.cssText = "font-size:4vh;margin:.5vh 0 1.5vh;color:#ffd54a;";
    title.textContent = "MediaBoard v7.1 自检报告";
    box.appendChild(title);
    var pass = 0;
    results.forEach(function (r) {
      var row = document.createElement("div");
      var ok = r.ok === true || /^(probably|maybe)/.test(String(r.ok));
      if (ok) { pass++; }
      row.style.cssText = "margin:.6vh 0;padding:.6vh 1vh;background:#151515;border-radius:.6vh;"
        + "display:flex;align-items:center;";
      var tag = document.createElement("span");
      tag.style.cssText = "flex:0 0 14vh;font-weight:bold;color:" + (ok ? "#4caf50" : "#ff5252") + ";";
      tag.textContent = ok ? "✔ 通过" : "✘ 不支持";
      var nm = document.createElement("span");
      nm.style.cssText = "flex:1;";
      nm.textContent = r.name + (r.detail ? "（" + r.detail + "）" : "");
      row.appendChild(tag); row.appendChild(nm);
      box.appendChild(row);
    });
    var sum = document.createElement("div");
    sum.style.cssText = "margin-top:2vh;font-size:3.4vh;font-weight:bold;color:"
      + (pass === results.length ? "#4caf50" : "#ffb300") + ";";
    sum.textContent = "自检结果: " + pass + "/" + results.length + " 项通过 · 性能档位:" + PERF;
    box.appendChild(sum);
    var tip = document.createElement("div");
    tip.style.cssText = "margin-top:1vh;color:#888;font-size:2vh;";
    tip.textContent = "字体包逐项加载校验：" + ((P.fontfaces || []).map(function (f) { return f.family; }).join("、") || "（未安装自定义字体）") + " —— 见下方字体行";
    box.appendChild(tip);
    var st = document.createElement("span");
    st.id = "mb-state";
    st.style.display = "none";
    box.appendChild(st);
    document.body.appendChild(box);
    document.title = "selftest " + pass + "/" + results.length;
    setState("selftest:" + pass + "/" + results.length);
    // @font-face 异步校验追加
    if (document.fonts && document.fonts.check) {
      document.fonts.ready.then(function () {
        (P.fontfaces || []).forEach(function (f) {
          var ok = false;
          try { ok = document.fonts.check("12px '" + f.family + "'"); } catch (e) {}
          var row = document.createElement("div");
          row.style.cssText = "margin:.6vh 0;padding:.6vh 1vh;background:#151515;border-radius:.6vh;display:flex;";
          var tag = document.createElement("span");
          tag.style.cssText = "flex:0 0 14vh;font-weight:bold;color:" + (ok ? "#4caf50" : "#ff5252") + ";";
          tag.textContent = ok ? "✔ 加载" : "✘ 失败";
          var nm = document.createElement("span");
          nm.textContent = "字体包: " + f.family;
          row.appendChild(tag); row.appendChild(nm);
          box.insertBefore(row, sum);
        });
      });
    }
  }

  // ---------- 编辑器联动（editor.html iframe postMessage） ----------
  window.mbApply = function (cfg) {
    try {
      P = cfg || {};
      PERF = P.perf || "high";
      document.body.className = "perf-" + PERF;
      injectFonts();
      var tb = document.getElementById("ticker");
      tb.style.display = "none";
      tb.style.webkitMaskImage = tb.style.maskImage = "";
      applyBackground();
      applyBgfx();
      var fallback = [{ duration: 0, zones: [{ name: "全屏", x: 0, y: 0, w: 100, h: 100, slides: P.slides || [] }] }];
      pages = (P.pages && P.pages.length) ? P.pages : fallback;
      pageFilter = [];
      if (hasSplit()) { bootPanes(); } else { renderPage(firstPageIdx()); }
      applyTicker();
      applyNotify();
      setState("editor-live");
    } catch (e) { setState("error:" + (e.message || "apply")); }
  };
  window.addEventListener("message", function (ev) {
    if (ev.data && ev.data.mbConfig) { window.mbApply(ev.data.mbConfig); }
  });

  // ---------- v6 多方案热切换（schemes.js 索引 + playlist-<方案>.js，零刷新换整屏） ----------
  // start.sh 为 schemes/ 下每个方案目录生成独立 playlist 文件；settings.txt 的 SCHEME=名称
  // 决定开机方案；schedule.txt 的 scheme:名称 定时换方案；编辑器可另存多方案再导出。
  var ivs = [];
  function addIv(fn, ms) { var id = setInterval(fn, ms); ivs.push(id); return id; }
  var schemeBusy = false, schemeNow = "";
  function teardownRuntime() {
    if (pageTimer) { clearTimeout(pageTimer); pageTimer = null; }
    paneStates.forEach(function (st) { if (st.timer) { clearTimeout(st.timer); st.timer = null; } });
    ivs.forEach(function (id) { clearInterval(id); });
    ivs = [];
    if (bgfxRaf) { cancelAnimationFrame(bgfxRaf); bgfxRaf = null; }
    ["mb-bgfx", "mb-dim", "mb-screenoff"].forEach(function (id) {
      var o = document.getElementById(id);
      if (o && o.parentNode) { o.parentNode.removeChild(o); }
    });
  }
  function applyScheme(cfg, name) {
    teardownRuntime();
    P = cfg;
    schemeNow = name || "";
    PERF = P.perf || "high";
    document.body.className = "perf-" + PERF;
    injectFonts();
    applyBackground();
    applyBgfx();
    pageFilter = []; schedRange = null; schedLast = "";
    pausedBySchedule = false; playCounts = {};
    var fallback = [{ duration: 0, zones: [{ name: "全屏", x: 0, y: 0, w: 100, h: 100, slides: P.slides || [] }] }];
    pages = (P.pages && P.pages.length) ? P.pages : fallback;
    notifyFileLast = (P.notify && P.notify.text) ? String(P.notify.text).replace(/\r/g, "").trim() : "";
    if (hasSplit()) { bootPanes(); } else { renderPage(firstPageIdx()); }
    applyTicker();
    applyNotify();
    applyScreenOff();
    applyBgm();
    setState(name ? ("scheme:" + name) : "ready");
  }
  function loadScheme(name) {
    if (!name || schemeNow === name) { return; }
    var list = window.SCHEMES || [];
    var hit = null;
    for (var i = 0; i < list.length; i++) { if (list[i].name === name) { hit = list[i]; break; } }
    if (!hit) { setState("scheme:未知:" + name); return; }
    if (schemeBusy) { return; }
    schemeBusy = true;
    var s = document.createElement("script");
    s.src = hit.file + "?t=" + Date.now();
    s.onload = function () {
      schemeBusy = false;
      var cfg = window["MB_PLAYLIST_" + hit.key];
      if (cfg) { applyScheme(cfg, name); }
    };
    s.onerror = function () { schemeBusy = false; setState("scheme:加载失败"); };
    document.head.appendChild(s);
  }

  // ---------- 启动 ----------
  function init() {
    stage = document.getElementById("stage");
    msgBox = document.getElementById("msg");
    document.body.className = "perf-" + PERF;
    if (location.search.indexOf("selftest") >= 0) { runSelftest(); return; }
    applyBackground();
    applyBgfx();
    var fallback = [{ duration: 0, zones: [{ name: "全屏", x: 0, y: 0, w: 100, h: 100, slides: P.slides || [] }] }];
    pages = (P.pages && P.pages.length) ? P.pages : fallback;
    var hasContent = pages.some(function (pg) {
      return pg.zones.some(function (z) {
        return z.clock || z.countdown || z.text || z.qr || z.notice || z.table || z.data
          || z.gauge || z.weather || z.web || z.map || (z.slides && z.slides.length);
      });
    });
    if (!hasContent) {
      msgBox.textContent = "MediaBoard 已就绪：请把素材放进 content 目录后重启";
    }
    // 开机插播过的内容不重复触发（poll 基线）
    notifyFileLast = (P.notify && P.notify.text) ? String(P.notify.text).replace(/\r/g, "").trim() : "";
    if (hasSplit()) { bootPanes(); } else { renderPage(firstPageIdx()); }
    applyTicker();
    applyNotify();
    applyScreenOff();
    applyBgm();
    applySchedule();
    addIv(applySchedule, 20000);
    addIv(pollNotifyFile, 30000);
    document.addEventListener("keydown", function (e) {
      if (e.key !== "ArrowRight") { return; }
      for (var i = 0; i < currentZones.length; i++) {
        var z = currentZones[i];
        if (!z.clock && !z.countdown && !z.text && !z.qr && !z.notice && z._next) { z._next(); return; }
      }
    });
    if (P.reloadMinutes > 0) {
      addIv(function () { location.reload(); }, P.reloadMinutes * 60000);
    }
    // v6 开机方案优先级: URL ?scheme=名称 > settings.txt 的 SCHEME=名称（生成 schemes.js 的 active）
    var mS = /[?&]scheme=([^&]+)/.exec(location.search);
    if (mS) { loadScheme(decodeURIComponent(mS[1].replace(/\+/g, " "))); }
    else if (window.SCHEMES_ACTIVE && window.SCHEMES && schemeNow !== window.SCHEMES_ACTIVE) {
      loadScheme(window.SCHEMES_ACTIVE);
    }
    setState("ready");
  }
  init();
})();
