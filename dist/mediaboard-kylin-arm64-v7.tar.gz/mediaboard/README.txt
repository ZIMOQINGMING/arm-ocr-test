MediaBoard v7 离线多媒体看板（麒麟V10 ARM64 · LEDvision 同级编排 + 党团文化 + 排版库版）
====================================================================================

适用设备：麒麟 V10 ARM64 离网机（Ubuntu 20.04 底版 / glibc 2.31 / Chromium 83 / 完全离网）
定位：替代 Colorlight LEDvision 的本地多媒体看板，对齐其节目树/分屏/多节目单编排能力，
      同时补齐当下流行显示效果（玻璃拟态磨砂 / 框型库 / 数据看板 / 地图可视化 / 翻牌时钟）。
交付物：本目录（3 款子集字体 + 系统字体导入工具 / 6 张纹理 / 4 张内置地图 / 21 套模板 /
        25 种党政排版库 / 30 种区域框型 / 可视化编辑器 / 真机自检）。
零依赖：只用系统自带 chromium 浏览器，不联网、不装任何软件
        （qr.js 为包内自带离线二维码库，MIT 协议）。

────────────────────────────────────────────────────────
〇、版本沿革（七轮做了什么）
────────────────────────────────────────────────────────
v1  分区版            layout.txt 分区播放 + PPT/Word 转图管线
v2  对齐 LEDvision 基础面  6 种窗口、11 种转场、走马灯字幕、通知插播、多节目页、字体包机制
v3  "效果不够丰富"整改   视觉增强 CSS 全家桶、14 种转场、性能档位、12×12 栅格、九宫格/二维码/公告、6 套模板、可视化编辑器、自检
v4  编排差距补齐        图层叠加(LAYER/OPACITY)、字幕全局覆盖、分块特效(GRID_FX)、页级播放规则(@PLAYS/@VALID)、定时指令表(schedule.txt)、柔和边缘、3D 感转场、内置子集字体+纹理+图标
v5  同级对标 + 现代视觉  表格/数据/仪表/天气/网页五种新窗口、时段节目单、notify.txt 热插播、
                        翻牌时钟、分区转场覆盖、BGFX 动态背景、玻璃拟态/发光字/标题栏、瀑布流、GRID_FX 25 块、模板 9 套
v6  党团文化 + 磨砂视觉  党团宣传文化模式（红金模板/党团图标/丝带标题栏/鎏金装饰/红色滤镜）、
                        12 种磨砂半透底层模板（GLASS_ALPHA/GLASS_COLOR/GLASS_BLUR 参数化）、
                        框型库 FRAME 13 种（圆角/胶囊/斜切/对角切/拱门/梯形/书签/公文/角标/印章/丝带/六边/盾形）、
                        地图窗（内置中国/世界/园区/楼层 SVG，域高亮呼吸+脉冲标记+压暗/模糊/半透明叠加，支持自定义 SVG）、
                        分屏播放（SPLIT + @PANE，各分屏独立轮播）、多方案 schemes（热切换 + 定时 scheme: 指令 + 开机方案）、
                        分区整体模糊 BLUR 与全透明 TRANSPARENT
v7  排版库 + 全面自定义  党政排版库 layouts/ 25 种（@LAYOUT=党政·左3中2右3 一行引用整页版式）、
                        框型库扩到 30 种（+票券/波浪/叶片/斜杠/双线/标签/标牌/拍立得/胶片/屏幕/终端/
                        气泡/八边/菱形/山形/折角/面板 17 种新框体）、
                        地图分区颜色+分区透明度逐个可调（text.txt 色:/明度: 行 + style.txt REGION_ALPHA）、
                        倒计时主题化（TOPIC=安全生产 100 天 可编辑主题横幅 + SINCE 第 N 天累计）、
                        模板底图自定义五参（BG_FIT/BG_POS/BG_OPACITY/BG_BLUR/BG_DARKEN + 分区 ZBG_FIT/ZBG_POS）、
                        文本竖排 VERTICAL=yes（党政竖联排版）、系统字体导入工具 import-fonts.sh（麒麟系统字体一键入包）

【安装】U盘拷过来后执行一次
  tar xzf mediaboard-kylin-arm64-v7.tar.gz
  cd mediaboard
  bash install.sh

【五种使用方式，从易到难】
  A. 只想放图片/视频：素材丢进 content/，bash start.sh 就会全屏轮播。
  B. 想套现成版式：cp -r templates/磨砂·极光之夜/* .  然后改 content 下的文字。
     21 套模板 = 9 套场景模板 + 12 套磨砂半透模板（见 templates/README.txt）。
  C. 想套党政版式：layout.txt 页内写一行 @LAYOUT=党政·左3中2右3 即引用排版库
     （25 种党政版式见 layouts/README.txt；党建文化方案第 1/5 页即排版库演示）。
  D. 想整屏换方案：直接用包内两个现成方案——
     bash start.sh 后浏览器地址加 ?scheme=党建文化，或在 settings.txt 写 SCHEME=党建文化；
     也可自己建 schemes/我的方案/ 目录（拷一份 layout/settings/content 进去即可被自动识别）。
  E. 想可视化调：用浏览器打开 editor.html（见下"可视化编辑器"）。

【开箱演示】v6 默认 layout.txt 自带三页：
  第 1 页 = 经典分区版式（图片窗 + 文本通知 + 表盘时钟 + 倒计时）；
  第 2 页 = v5 新窗口演示（发光标题 + 数据指标卡 + 仪表盘 + 天气卡 + 表格议程）；
  第 3 页 = v6 新能力演示（中国地图域高亮 + 磨砂说明卡 + 数据指标，磨砂玻璃在动态背景上出效果）。
  20 秒左右自动换页，三页轮流播放；另有"党建文化""日常发布"两个完整方案在 schemes/ 下。

────────────────────────────────────────────────────────
一、党团宣传文化模式（v6 重点）
────────────────────────────────────────────────────────
  面向党建/团建文化阵地的成套素材，拿来即用、改字即播：
  1) 模板：templates/党建宣传（四页红金模板：主题页/党史长廊/组织生活/青年园地）
     完整方案：schemes/党建文化（六页：主题页/党史长廊/先锋榜样+组织数据/红色地图/青年园地/公示栏）
  2) 专属视觉件（分区 style.txt 直接可写）：
     TITLEBAR_SHAPE=ribbon   丝带梯形标题栏（红金渐变）
     FRAME=ribbon|stamp|doc  丝带框/印章框/公文框（配 FRAME_COLOR=#ffd54a FRAME_COLOR2=#c8102e）
     GLOW=#ffb84a            鎏金发光大标题
     DECOR=redveil           红色薄纱滤镜（图片统一压红色调，整体色调统一）
  3) 党团图标（ICON= 直接用）：starF 五角星 / torch 火炬 / medal 奖章 /
     landmark 会堂 / book 著作 / dove 和平鸽
  4) 红色地图窗：地图窗 text.txt 写"中国"+域高亮，做"红色教育基地巡礼"类版面（见七、地图窗）
  5) 字体搭配建议（庄重场合）：标题 FONT=思源宋体 粗（公文/庄重感），
     正文 FONT=思源黑体 常规（屏显清晰），数字报表 FONT=思源黑体 粗 + TABNUM=yes。
  内容均为通用规范表述与制度性条目（三会一课频次、党史大事记等公开事实），
  示例数据处已标注"示例 请按实际修改"。

────────────────────────────────────────────────────────
二、磨砂半透模板（12 套，底层 + 玻璃参数化）
────────────────────────────────────────────────────────
  磨砂玻璃三参数（任何分区 style.txt 可写）：
    GLASS=yes                 开启玻璃卡（已有 GRADIENT 时让位给渐变）
    GLASS_ALPHA=0-100         玻璃底不透明度%（越小越透；浅色版建议 30-40，深色 10-16）
    GLASS_COLOR=#hex          玻璃底色（决定磨砂的色调）
    GLASS_BLUR=vh             背景模糊强度（0.2-6；越大越"磨砂"）
  底层（settings.txt）三选一：BGFX=aurora/gridmove/particles 动态底（毛玻璃最出效果）、
    BGIMAGE=textures/*.png 纹理底、BGCOLOR 纯色底。
  12 套现成模板（templates/ 下，拷来即用）：
    磨砂·极光之夜（深蓝黑+极光底+青辉标题）      磨砂·鎏金岁月（光带底+公文框+金字）
    磨砂·红金礼堂（党建红底+丝带框+鎏金标题）    磨砂·青碧琉璃（流动网格+六边框+青碧调）
    磨砂·紫霞流动（极光紫底+胶囊框）              磨砂·碳纤工坊（碳纤纹理+斜切框+橙强调）
    磨砂·蓝调数据（细网格底+角标框+数据蓝）      磨砂·晨雾白（浅色磨砂，深字，办公风）
    磨砂·墨玉书房（中心提亮底+书签框+宋体题）    磨砂·琥珀宴会（光带暖底+印章框）
    磨砂·碧海潮生（星点粒子+盾形框+滨海蓝）      磨砂·会议纪要（中性灰底+梯形框，正式）
  注意：磨砂=backdrop-filter 真模糊，PERF=low 自动关闭、mid 保留；自检模式可验证支持情况。

────────────────────────────────────────────────────────
三、可视化编辑器 editor.html
────────────────────────────────────────────────────────
  用系统 chromium 打开本机文件：
    chromium --app=file:///opt/mediaboard/editor.html
  左侧表单改参数，右侧实时预览（拖滑块立刻变），支持：
    · 全局：22 种切换特效、特效时长、性能档位、填充方式、Ken Burns、背景色、
            动态背景 BGFX(极光/流动网格/粒子)、v6 分屏 SPLIT 与开机方案 SCHEME
    · 节目页时间轴：加页/删页/前移后移/每页停留秒/播放次数(@PLAYS)/有效期(@VALID)/
            分屏归属(@PANE)
    · 分区：位置大小、内外距、垂直对齐、圆角、卡片投影、渐变底色、文字阴影/描边、
            图标、装饰线、图层/透明/边缘渐隐、分块特效(4/9/16/25 与块序)、转场覆盖、
            边框(色+宽)、发光字、玻璃拟态、v7 框型库(30 种)+双色、磨砂三参数、
            整体模糊、全透明、丝带标题栏(形+色)、分区背景图、文本竖排勾选；
            12 种窗口类型全部可视化编辑（v6 新增地图窗：底图/域/点/图例/压暗/模糊）
    · 字幕条：内容/效果/速度/字号/条高/颜色/两端渐隐/字体
    · 定时指令表：直接在编辑器里写 schedule.txt（含时段节目单与 scheme: 方案切换）
    · 素材导入：选本机图片视频，立刻在预览里看到效果（仅预览用）
  【导出】点"导出配置包(ZIP)" → 得到 settings.txt / layout.txt / ticker.txt /
    schedule.txt / 各分区 content/<名字>/text.txt+style.txt / 素材清单.txt
    → 解压覆盖到安装目录 → bash stop.sh && bash start.sh
  草稿自动存本机浏览器，断电不丢；也能导入现有 layout/settings/ticker/schedule 改。

────────────────────────────────────────────────────────
四、布局 layout.txt
────────────────────────────────────────────────────────
  每行一个窗口，两种写法（可混用）：
    ① 百分比：名称=X,Y,宽,高[,素材停留秒][,窗口类型]
    ② 栅格：  名称=g:行,列,跨行,跨列[,秒][,类型]     —— 12×12 栅格，对齐更省心
      例：主画面=g:1,1,8,7  → 第1行第1列起，占8行7列
  「--- N」单独一行 = 结束上一页并另起一页，N 是【上一页】的停留秒数；
  多页按顺序循环。最后一页的时长用 PAGE_DURATION（settings.txt）。
  窗口类型（12 种）：
    文件(默认) / 文本 / 时钟 / 计时 / 二维码 / 公告
    + v5：表格 / 数据 / 仪表 / 天气 / 网页(本地HTML)
    + v6：地图（内置 4 张 SVG 底图，支持自定义）
  v7 排版库引用：页内一行 @LAYOUT=党政·左3中2右3（layouts/ 下 25 种党政版式，可嵌套 5 层）
  不写类型时按名字猜：含"时钟"→时钟，含"公告"→公告，含"二维码/扫码"→二维码，
    含"表格"→表格，含"数据/统计/指标"→数据，含"仪表"→仪表，含"天气"→天气，
    含"地图/分布"→地图，含"网页"→网页……

【页级播放规则（v4 起）】在 --- 之后、该页分区之前加：
    @PLAYS=3                      这一页播 3 次后跳过（不写=一直循环）
    @VALID=2026-01-01~2026-12-31  只在有效期播，过期自动跳过
  所有页都播完（次数用尽）会自动清零重新轮，不会停在最后一页。

【分屏归属（v6）】@PANE=N 把该页归到第 N 块分屏（配合 settings.txt 的 SPLIT=）。

────────────────────────────────────────────────────────
五、分屏播放 SPLIT（v6）
────────────────────────────────────────────────────────
  settings.txt 写 SPLIT=2H / 2V / 3H / 3V / 3T / 3L / 4G / 4H / 4V：
    2H=左右两块  2V=上下两块  3H=左中右  3V=上中下  3T=上1下2  3L=左1右2
    4G=田字格   4H=四竖条   4V=四横条
  整屏被切成多块，每块独立轮播自己的页（互不同步——LEDvision 分屏节目等价物）：
    页面归属用 layout.txt 页内 @PANE=N（不写归第 1 块）；
    没有页的分屏显示"待编排"占位，不黑屏。
  编辑器"分屏(v6)"下拉 + 每页"分屏归属"输入框即可鼠标操作。

────────────────────────────────────────────────────────
六、多方案 schemes/（v6：方案自定义存储 + 多方案制作）
────────────────────────────────────────────────────────
  一个方案 = 一套完整看板（layout + settings + ticker + content 素材）。
  目录结构：schemes/<方案名>/ 里放 layout.txt（必需）+ 可选 settings.txt /
    ticker.txt / notify.txt / schedule.txt / content/（分区素材同根目录用法）。
  生成：start.sh 自动为 schemes/ 下每个方案目录生成 playlist-<方案名>.js 并汇总进 schemes.js。
  使用：
    ① 开机方案：settings.txt 写 SCHEME=方案名（不写=播根目录 layout.txt）
    ② 定时换方案：schedule.txt 写 HH:MM=scheme:方案名（如 08:30=scheme:党建文化）
    ③ 临时换方案：浏览器地址加 ?scheme=方案名
  热切换：换方案零刷新（JS 动态装载新 playlist，字幕/背景/插播全部即时重建）。
  包内自带两个示范方案：党建文化（六页红金完整版）、日常发布（蓝调磨砂两页版）。
  自建方案最省事的办法：cp -r schemes/日常发布 schemes/我的方案，再改字。

────────────────────────────────────────────────────────
七、地图窗（v6：自定义地图 + 模糊/半透明/透明）
────────────────────────────────────────────────────────
  分区 text.txt 写法（每行一条，# 注释）：
    第 1 行 = 底图。内置四张：中国 / 世界 / 园区 / 楼层（写中文名即可），
              或写自定义 SVG 相对路径（如 maps/china.svg）。
    标题:大字标题            地图窗顶部居中大字
    域:名称1,名称2           高亮区域（呼吸闪烁；省名/楼栋名/房间名，对应 SVG 的 data-region）
    图例:已建,规划           右下角图例点
    点:名称,x%,y%,备注       脉冲标记点（x/y 为分区百分比；备注拼在标签后）
  style.txt 可调：
    MAP_COLOR=#ffd54a   高亮色     MAP_COLOR2=#c8102e  标记/图例色
    MAP_TINT=0-90       底图压暗% （半透明叠加，弱化底图突出高亮）
    MAP_BLUR=vh         底图模糊   （0.2-12；做"底图模糊+前景清晰"的景深效果）
    MAP_FILL=rgba(...)  普通区域填充色
    REGION_ALPHA=0-100  未高亮分区统一透明度%（v7）
    TITLE=标题          同"标题:"行
  v7 分区颜色/透明度逐个可调（text.txt 加行）：
    色:江西=#c8102e,陕西=#ffd54a,贵州=#8f2323     逐省配色（优先级高于域高亮）
    明度:江西=85,陕西=80,贵州=70                  逐省透明度%（与色: 合用即"半透明彩色分区"）
    写法与"域:"一致，短名可命中（写"北京"命中 data-region="北京市"）。
  整个地图分区本身还能用通用键：GLASS 磨砂边框卡、BLUR 整窗模糊、OPACITY、FRAME 等。
  自定义底图：任何 SVG 都行——给要高亮的形状加 data-region="名称" 属性即可
  （拷入 maps/ 或 content/ 下任意路径）。内置四张即按此约定制作，可作参考。

────────────────────────────────────────────────────────
八、分区样式 style.txt（content/分区名/style.txt，k=v 每行一条，均可选）
────────────────────────────────────────────────────────
  —— 通用（所有窗口类型都能用）——
    PADDING=2        内边距 vh        MARGIN=1         外边距 %
    ALIGNV=middle    垂直对齐 top/middle/bottom
    RADIUS=1         圆角 vh；CARD=yes 卡片模式（圆角+投影）
    GRADIENT=#0b1e3d,#1a3a6b   135°渐变底色
    SHADOW=yes       文字阴影       STROKE=yes       白字黑描边
    TABNUM=yes       等宽数字       ICON=horn        图标（40 种，见下）
    DECOR=line       装饰：line 顶部细线 / corner 四角角标 / redveil 红色薄纱滤镜
    LAYER=1          图层：1 最上层，数字越大越靠后
    OPACITY=70       分区透明度 0-100（"背景视频+半透明信息卡"用）
    EDGE_MASK=6      四边渐隐 %，让分区融进背景
    GRID_FX=4|9|16|25      分块特效（静态内容分块错峰入场）
    GRID_FX_ORDER=diag|random|row|col   块序：斜向/随机/逐行/逐列
    TRANSITION=push-l     本分区转场覆盖全局（22 种同 settings 的 TRANSITION）
    BORDER=#ffffff,0.3     分区边框（颜色,宽vh）；LEDvision 窗口边框等价物
    TITLEBAR=yes    分区标题栏（标题取 TITLE=，无则用分区名；色取 TITLEBAR_COLOR 或渐变首色）
    TITLEBAR_SHAPE=ribbon  丝带梯形标题栏（红金渐变，党团宣传用）
    TITLEBAR_COLOR=#7a0d0d 标题栏底色
    GLASS=yes       玻璃拟态卡（背景模糊+高透明底；视频/动态背景上最出效果）
    GLASS_ALPHA=12  磨砂底不透明度%（0-100，默认 10）
    GLASS_COLOR=#12233f 磨砂底色（决定玻璃色调）
    GLASS_BLUR=2.4  磨砂背景模糊强度 vh（0.2-6，默认 1.5）
    GLOW=#38e8ff    霓虹发光字（大标题横幅效果拔群）
    ZBG=textures/vignette.png   分区背景图（可用包内 6 张纹理）
    BLUR=3          分区整体模糊 vh（0.2-30；图片/PPT 区打底模糊出景深）
    TRANSPARENT=yes 分区全透明（纯内容悬浮在背景/视频上）
    FRAME=…         框型（13 种）：rounded 圆角 / capsule 胶囊 / notch 斜切 /
                    cutcorner 对角切 / arch 拱门 / trapezoid 梯形 / bookmark 书签 /
                    doc 公文 / bracket 角标 / stamp 印章 / ribbon 丝带 /
                    hexagon 六边 / shield 盾形
    FRAME_COLOR=#ffd54a    框型主线色（默认鎏金）
    FRAME_COLOR2=#c8102e   框型辅线色（默认正红；红金搭配最党团）
  —— 文本窗 ——
    FONT=字体名 SIZE=6 COLOR=#00ff00 BGCOLOR=#222222 BOLD=yes ITALIC=no
    ALIGN=center LINESPACING=1.5
    EFFECT=static|scroll-left|scroll-up|blink|typewriter   SPEED=60
  —— 时钟窗 ——
    FORMAT=datetime|date|time|week|weektime|big（big=上行日期下行大时间）
           也可自定义 {Y}{M}{D}{h}{m}{s}{W}，「|」=换行
    MODE=digital|dial|flip   flip=翻牌数字（中低档位自动退回数字）
  —— 计时窗 ——
    TARGET=2027-01-01 09:00（不写=从开机正计时） TITLE=距开幕还有
  —— 二维码窗 ——
    content/分区名/text.txt 写要编码的文字/网址（支持中文）
    TITLE=扫码报修 COLOR=#111111 BGCOLOR=#ffffff ECL=M(L/M/Q/H)
  —— 公告列表窗 ——
    text.txt 每行一条；行多自动上滚
    TITLE=今日通知 ICON=horn SIZE=3.2 SPEED=30
    DATASRC=data/值班.json REFRESH=10   本地JSON每10分钟刷一次
  —— 表格窗（v5）——
    text.txt 每行一条，单元格用「|」或 Tab 分隔；首行默认做表头
    TITLE=今日议程 ICON=calendar SIZE=2.8 ACCENT=#1d4ed8（表头/强调色）
    HEADER=yes/no ZEBRA=yes/no（表头与斑马纹开关）
    DATASRC=data/值表白.json REFRESH=10（可选：本地JSON刷新，数组或 rows/items）
  —— 数据统计窗（v5）——
    text.txt 每行：标签|数值|单位|进度%(0-100，可空)
    TITLE=生产总览 ICON=chart SIZE=5（数值字号vh）
    VALUECOLOR=#7dd3fc BARCOLOR=#38bdf8 COUNTUP=yes/no（数字滚动）
    DATASRC=data/产量.json REFRESH=10
  —— 仪表盘窗（v5）——
    text.txt 每行：标签=值,量程    （单表可直接 style 里 VALUE=72）
    TITLE=系统状态 ICON=gear UNIT=% COLORS=#22c55e,#f59e0b,#ef4444
    （色带：<55% 绿 / 55-85% 黄 / >85% 红，逗号分隔自定义三色）
    DATASRC=data/负载.json REFRESH=10（json: {"items":[{"label":..,"value":..,"max":..}]}）
  —— 天气窗（v5）——
    text.txt：首行城市；之后每行 日期,天气,最高,最低（离网静态数据）
    天气图标按"晴/多云/阴/雨/雪/雾"关键词自动匹配
    SIZE=3.2 COLOR=#eaf4ff BGCOLOR=…  DATASRC=data/天气.json REFRESH=30（可选）
  —— 网页窗（v5）——
    text.txt 写包内本地 HTML 相对路径（如 content/挂件/index.html），
    iframe 内嵌显示；适合放自制的交互/动画挂件，需完整 chromium 环境
  —— 地图窗（v6）——
    见"七、地图窗"整节
  —— 文件窗 ——
    GROUP=grid     九宫格：多图铺开（GROUPCOLS=2 指定列数）
    GROUP=waterfall  瀑布流（v5）：多图信息墙，CSS 多列流式排布
    DECOR=redveil   红色薄纱滤镜（v6：图片统一压红调，党团宣传整体色调统一）

【图标 40 种】info/warn/star/clock/horn/check/flag/arrowR/arrowL/arrowUp/arrowDown/
  calendar/user/phone/mail/pin/chart/gear/sun/moon/cloud/battery/wifi/heart/shield/
  fire/doc/speaker/play/rain/snow/fog/wind/temp + v6 党团：starF/torch/medal/
  landmark/book/dove

────────────────────────────────────────────────────────
九、定时指令表 schedule.txt（v6 扩展）
────────────────────────────────────────────────────────
  单点指令（HH:MM=指令，按本机时钟，同一分钟只执行一次）：
    play:2        跳到第 2 页        pause/resume   暂停/恢复自动换页
    screenoff     全屏黑            screenon       取消黑屏
    dim:50        亮度模拟（画面调暗，0-100；LED硬调光需硬件，此处模拟）
    notify:文字   紧急插播通知（滚 NOTIFY_MINUTES 分钟后自动消失）
    ticker:文字   立即换底部字幕文字（样式不变）
    reload        重载播放器（改完素材免重启）
    scheme:名称   v6 热切换方案（schemes/ 下目录名，如 scheme:党建文化）
  时段节目单（LEDvision「按时段播不同节目」的等价物）：
    09:00-17:30=pages:2      该时段只在第 2 页循环
    22:00-07:00=pages:1,2    跨天时段；出时段自动恢复全部页
  只做播放器内部动作，不重启、不关机（浏览器权限边界）。样例见 schedule.txt。
  另：插播不必改配置——运行中直接改 notify.txt 文件内容，30 秒内自动插播。

────────────────────────────────────────────────────────
十、滚动字幕 ticker.txt + settings.txt
────────────────────────────────────────────────────────
  ticker.txt 每行一段；settings.txt 调效果/速度/字体/字号/颜色/底色/条高/
  分隔符/两端渐隐(TICKER_MASK)/位置(TICKER_POS)/覆盖方式(TICKER_OVERLAY)。
  TICKER_OVERLAY=yes（默认）字幕浮在所有分区之上（视频全屏也能压字）；
  =no 时舞台给字幕让位，分区不被压住。

────────────────────────────────────────────────────────
十一、视觉增强与性能档位 settings.txt
────────────────────────────────────────────────────────
  TRANSITION=fade|fade-zoom|blur-fade|slide-soft|flip-3d|depth-zoom|cover-*|
             push-*|rotate-3d|wipe-*|random|none      （22 种；分区可各自覆盖）
             push=新旧同推（LEDvision"衔接"式出入同特效）；rotate-3d=立体旋入
  TRANSITION_TIME=0.8   特效时长
  KENBURNS=yes          图片缓慢推近（静图变"活"）
  BGFX=aurora|gridmove|particles   动态背景（v5）：极光色块漂浮/流动网格/星点粒子；
             零素材纯代码；PERF=low 自动关、mid 粒子降级极光；与 BGCOLOR/BGIMAGE 叠加
  SPLIT=2H|2V|3H|3V|3T|3L|4G|4H|4V  分屏播放（v6，见"五、分屏"）
  SCHEME=方案名          开机方案（v6，见"六、多方案"）
  PERF=high|mid|low     high 全效果 / mid 去模糊·KenBurns·粒子 / low 只留淡入淡出
                        —— ARM64 软渲染卡顿时直接调低，效果与流畅解耦
                        —— 磨砂玻璃(backdrop-filter)在 low 档自动关闭
  BGCOLOR / BGIMAGE / BGMUSIC / SCREEN_OFF(定时黑屏防烧屏) / TWINKLE

────────────────────────────────────────────────────────
十二、字体包（3 款子集字体，共约 4.5MB，按角色分工已够用）
────────────────────────────────────────────────────────
  fonts/ 里现成可用，style.txt 直接写中文显示名：
    FONT=思源黑体 常规   → 正文/表格/表格数字（屏显清晰、小字不糊）
    FONT=思源黑体 粗     → 大标题/数据数值/走马灯（重点强调）
    FONT=思源宋体 粗     → 庄重标题（党团宣传/公文/荣誉场合）
  三款分工覆盖"正文-强调-庄重"三个角色；子集范围：GB2312 常用字 + 英文数字标点
  （7545 字），正文/标题都够；生僻字回落系统字体。
  显示名映射在 fonts/FONTS.txt（文件名=显示名）。
  自己加字体：.ttf/.otf/.woff/.woff2 丢进 fonts/，名字默认=文件名（去扩展名）。
  完整中文字库 10MB+ 在 ARM64 离网机上加载慢，务必用子集：
  pyftsubset 一条命令压到 1/8（本包 3 款均按此法生成，字符集完全一致）。

────────────────────────────────────────────────────────
十三、纹理与地图素材（程序化生成、无版权风险）
────────────────────────────────────────────────────────
  textures/（6 张，1280x720，任何分辨率都能铺满）：
    brushed 金属拉丝 / grid 细网格 / carbon 碳纤维 / noise 细颗粒 /
    beams 斜向光带 / vignette 中心提亮
    用法：settings 写 BGIMAGE=textures/vignette.png；或分区 style 写 ZBG=…；
    也可拷进分区当图片素材。
  maps/（4 张，data-region 约定）：
    china.svg 中国分省（34 省级区域+省名标注）/ world.svg 世界（285 国区域）/
    campus.svg 园区平面（9 楼栋）/ floor.svg 楼层平面（11 房间）
    地图窗直接用；做自己的地图只需给 SVG 形状加 data-region="名称"。
  注意：真实 4K 动态背景视频请自行准备（离网机别同时解码多条视频）。

────────────────────────────────────────────────────────
十四、PPT/Word/Excel
────────────────────────────────────────────────────────
  直接放进 content/（或分区目录、方案目录），启动时自动转图（需 WPS 或
  LibreOffice）；转不了就在电脑上另存为图片再拷入。
  v6：方案目录 schemes/<方案>/content 下的文档同样自动转图。

────────────────────────────────────────────────────────
十五、启动/停止/校准
────────────────────────────────────────────────────────
  bash start.sh            开始播放（install.sh 已设开机自启）
  bash stop.sh             停止
  player.html?diag=1       左上角绿字显示视口与分区真实像素矩形（对位用）
  player.html?selftest=1   能力自检（v6 增检 backdrop-filter 磨砂 / clip-path 框型 /
                           地图 SVG 载入 / 多列瀑布流 / CSS 动画）
  player.html?scheme=党建文化   直接以某方案开播（调试用）

【支持格式】图片 jpg/jpeg/png/gif/webp/bmp   视频 mp4(H.264)/webm/ogg/mov/mkv

────────────────────────────────────────────────────────
十六、排查
────────────────────────────────────────────────────────
  黑屏无内容     content/ 空，或 layout 里分区名与 content/ 目录名不一致
  文本窗不显示   content/分区名/text.txt 缺失或为空
  字体不生效     文件在 fonts/？FONT 名与 FONTS.txt 显示名一致？
  画面有黑边     素材比例≠分区比例：FILL=cover，或按分区像素做素材
  视频不播       编码不兼容，转 H.264 mp4
  效果卡顿       PERF 调 mid 或 low；BGFX 关掉；磨砂玻璃/发光字酌情去除
  磨砂不生效     PERF=low 会关闭磨砂；自检模式确认 backdrop-filter 支持
  框型显示异常   斜切族框型(notch/cutcorner/trapezoid/ribbon/hexagon/shield)
                  会裁掉边框与投影，属正常；换 rounded/capsule 可保留边框
  二维码空白     分区 text.txt 为空；或内容过长（缩短文字）
  地图窗空白     首行没写底图；或自定义 SVG 路径不对；域高亮名与 data-region 不一致
  分屏某块空     该分屏没有归属页：页内加 @PANE=N
  方案不生效     schemes/ 目录名=方案名；settings 写 SCHEME= 时去掉行首 # ；
                  定时 scheme: 名称要与目录名完全一致
  编辑器预览白屏 用 chromium 打开（--allow-file-access-from-files 才行）
  时段节目不生效 schedule.txt 行首 # 没去掉；页号按 layout.txt 里 --- 的先后从 1 数
  表格字太小     行数多会自动缩字号；也可删行或调大分区
  与 LEDvision 的差距说明：多屏同步/远程集群/硬件亮度调光/亮度探头温湿度采集
  属于"联网+外设"能力，离网单机版用 dim:亮度模拟、DATASRC 本地JSON 数据源、
  分屏 SPLIT、多方案 schemes 等离线等价物替代（见 schedule.txt 与 style.txt 说明）。

────────────────────────────────────────────────────────
九B、v7 新功能速查
────────────────────────────────────────────────────────
【党政排版库 layouts/（25 种）】
  layout.txt 任意页写 @LAYOUT=党政·左3中2右3 → 整页引用该版式（可与自己手写的分区行混排）。
  25 种：左3中2右3 / 左2中3右2 / 左1中2右1 / 左窄右宽 / 左宽右窄 / 通栏标题三栏 /
  通栏标题双栏 / 四宫格 / 六宫格 / 中心四角 / 上中下三段 / 左竖联右内容 / 红头文件式 /
  一大多小公告墙 / 左时间轴右事件 / 左图右文 / 右图左文 / 中央仪表四角数据 / 门形 /
  品字形 / 倒品字形 / 阶梯错落 / 主副屏 / 横幅五列 / 地图主版。
  版式里分区名换成自己的 content/<名字>/ 素材名即可套用；排版引用可嵌套 5 层。

【框型库 FRAME=（30 种）】
  基础 13 种：rounded capsule notch cutcorner arch trapezoid bookmark doc bracket stamp
              ribbon hexagon shield
  v7 新 17 种：ticket 票券 / wave 波浪底 / leaf 叶片 / slash 斜切平行四边形 /
              doubleline 双线公文 / tag 箭头标签 / label 标牌舌 / photo 拍立得相框 /
              film 胶片 / screen 屏幕 / terminal 终端窗 / bubble 对话气泡 /
              octagon 八边 / diamond 菱形 / chevron 山形 / cornerfold 折角 / panel 铆钉面板
  颜色 FRAME_COLOR=#hex（主线）、FRAME_COLOR2=#hex（辅线/底渐变），默认鎏金/正红。

【倒计时主题化（计时窗 style.txt）】
  TOPIC=安全生产 100 天      主题横幅文字（任意可编辑，如"安全生产 100 天""距党代会开幕"）
  TOPIC_COLOR=#ffe9b0        主题横幅字色
  TOPIC_BG=#c8102e           主题横幅底色（另一端自动加深，红金渐变）
  TARGET=2026-12-31 00:00   目标时刻 → 显示「倒计时 N 天」+ 时分秒小字
  SINCE=2025-06-01           起算日 → 显示「第 N 天」累计（安全生产第 100 天式）
  LABEL=倒计时               标签文字（默认：TARGET 时"倒计时"、SINCE 时"第"）
  UNIT=天                    单位大字（默认"天"，可改"周/小时"）

【模板底图自定义（settings.txt）】
  BGIMAGE=bg/大厅.jpg        底图路径（不变）
  BG_FIT=cover|contain|fill   适配方式（默认 cover）
  BG_POS=center|top|bottom|left|right|左上/右上/左下/右下   位置（默认 center）
  BG_OPACITY=0-100           底图不透明度%（越低越淡，和 BGCOLOR 叠出浅色调）
  BG_BLUR=vh                 底图模糊（0.2-12；景深/弱化照片）
  BG_DARKEN=0-100            底图压暗%（照片底图上放白字必备）
  分区级：ZBG_FIT / ZBG_POS 同理控制分区背景图。

【文本竖排（style.txt）】
  VERTICAL=yes               文本竖排（writing-mode:vertical-rl，党政竖联/古风排版）
  建议配 LINESPACING=1.8、FONT=思源宋体 粗、FRAME=doc。

【系统字体导入（import-fonts.sh）】
  ./import-fonts.sh --list 楷           # 列出麒麟系统里含"楷"的字体
  ./import-fonts.sh 楷 金石             # 命中的复制进包内 fonts/（离线可用）
  ./import-fonts.sh /路径/xx.ttf        # 或直接指定字体文件
  导入后在 fonts/FONTS.txt 写别名（如 xxx=华文楷体），分区 style.txt 写 FONT=华文楷体 即生效。
  提示：大字重文件会增大包体，建议只导入用到的字重；商用字体请确认授权。
