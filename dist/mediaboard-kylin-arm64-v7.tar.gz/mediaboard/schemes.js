window.SCHEMES=[{name:"党建文化",file:"playlist-党建文化.js",key:"党建文化"},{name:"日常发布",file:"playlist-日常发布.js",key:"日常发布"}];
