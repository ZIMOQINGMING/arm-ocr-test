window.PLAYLIST={
duration:8,
sound:false,
reloadMinutes:0,
fill:"cover",
transition:"push-l",
transitionTime:0.8,
twinkle:false,
perf:"high",
kenburns:false,
bgcolor:"#070d1a",
bgfx:"aurora",
ticker:{text:"麒麟V10 离线看板 · MediaBoard v5 · 表格/数据/仪表/天气窗已就绪\n",effect:"scroll-left",speed:90,size:5,color:"#e2e8f0",bgcolor:"#0f1f3a",bold:true,height:8,sep:"　　●　　",mask:true,overlay:true,pos:"bottom"},
fontfaces:[{family:"思源黑体 粗",url:"fonts/SourceHanSansSC-Bold.woff2",format:"woff2"},{family:"思源黑体 常规",url:"fonts/SourceHanSansSC-Regular.woff2",format:"woff2"},{family:"思源宋体 粗",url:"fonts/SourceHanSerifSC-Bold.woff2",format:"woff2"},],
schedule:[
],
pages:[
{duration:25,zones:[
{name:"主画面",x:0,y:0,w:70,h:86,duration:8,slides:["./content/主画面/01-main.png",]},
{name:"通知",x:70,y:0,w:30,h:28,shadow:"yes",padding:"1.5",text:{content:"欢迎使用 MediaBoard\n素材放入 content/主画面\n即可全屏轮播播放\n",size:"4",color:"#7dff9a",bgcolor:"#101010",effect:"static",bold:"yes",align:"center"}},
{name:"时钟",x:70,y:28,w:30,h:29,clock:{mode:"dial",color:"#ffffff",bgcolor:"#101820"}},
{name:"倒计时",x:70,y:57,w:30,h:29,countdown:{}},

]},
{duration:20,zones:[
{name:"标题",x:0,y:0,w:100,h:10,gradient:"#0e2a52,#1a4a8c",glow:"#7dd3fc",tabnum:"yes",text:{content:"MediaBoard v6 · 麒麟V10 离线多媒体看板\n",size:"5",color:"#eaf4ff",bold:"yes",effect:"static"}},
{name:"数据",x:0,y:10,w:40,h:45,title:"生产总览",icon:"chart",padding:"1",card:"yes",glass:"yes",data:{content:"今日产量|1868|件|92\n完成率|92.4|%|92\n在线设备|126|台|88\n当日报警|3|条|12\n",title:"生产总览",icon:"chart",size:"5",valuecolor:"#7dd3fc",barcolor:"#38bdf8"}},
{name:"仪表",x:0,y:55,w:40,h:45,title:"系统状态",icon:"gear",padding:"1",gauge:{content:"主控CPU=62,100\n内存占用=71,100\n网络负载=38,100\n",title:"系统状态",icon:"gear",unit:"%",colors:"#22c55e,#f59e0b,#ef4444",ring:"rgba(255,255,255,.12)"}},
{name:"天气",x:40,y:10,w:25,h:45,padding:"1",glass:"yes",weather:{content:"麒麟厂区\n今日,晴,26,14\n明日,多云,23,12\n周三,小雨,20,11\n周四,晴,24,13\n周五,晴,25,14\n"}},
{name:"表格",x:65,y:10,w:35,h:82,title:"今日议程",icon:"calendar",padding:"1",table:{content:"时间|事项|地点|负责人\n09:00|晨会调度|三楼会议室|张工\n10:00|产线巡检|二号车间|李工\n14:00|安全培训|多功能厅|王工\n16:30|日报汇总|办公楼201|赵工\n",title:"今日议程",icon:"calendar",size:"2.8",accent:"#1d4ed8"}},

]},
{duration:20,zones:[
{name:"分布地图",x:0.00,y:0.00,w:66.67,h:91.67,glass:"no",map:{content:"中国\n标题:服务站点分布（示例）\n域:北京,广东,四川,湖北\n图例:已建站点,规划站点\n点:北京,68,36,华北中心\n点:广州,72,74,华南中心\n点:成都,48,58,西南中心\n点:武汉,64,57,华中中心\n",map_color:"#ffd54a",map_color2:"#c8102e",map_tint:"20"}},
{name:"站点说明",x:66.67,y:0.00,w:33.33,h:41.67,titlebar:"yes",title:"站点说明",titlebar_color:"#1d4ed8",icon:"pin",glass:"yes",glass_alpha:"14",glass_color:"#12233f",glass_blur:"2.4",padding:"2",text:{content:"地图窗演示\n金色高亮=服务覆盖省份\n脉冲标记=区域中心站点\n支持自定义 SVG 底图\n支持压暗/模糊/半透明\n",font:"思源黑体 常规",size:"2.6",color:"#eaf4ff",align:"left",linespacing:"1.7"}},
{name:"运行指标",x:66.67,y:41.67,w:33.33,h:50.00,title:"运行概览（示例数据）",icon:"chart",glass:"yes",glass_alpha:"14",glass_color:"#12233f",glass_blur:"2.4",padding:"2",data:{content:"覆盖省份|12|个|80\n服务站点|48|个|96\n在线率|99.6|%|99\n",title:"运行概览（示例数据）",icon:"chart",size:"3.2",valuecolor:"#7dd3fc",barcolor:"#38bdf8",countup:true}},

]},
],
slides:[
"./content/00-welcome.png",]
};
