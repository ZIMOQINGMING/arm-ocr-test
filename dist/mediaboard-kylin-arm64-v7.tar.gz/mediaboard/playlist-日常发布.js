window["MB_PLAYLIST_日常发布"]={
duration:8,
sound:false,
reloadMinutes:0,
fill:"cover",
transition:"push-l",
transitionTime:0.8,
twinkle:false,
perf:"high",
kenburns:false,
bgcolor:"#070d1a",
bgfx:"gridmove",
ticker:{text:"今日事今日毕　　安全第一 预防为主　　有问题请及时反馈\n",effect:"scroll-left",speed:90,size:5,color:"#e2e8f0",bgcolor:"#0f1f3a",bold:true,height:8,sep:"　　●　　",mask:true,overlay:true,pos:"bottom"},
fontfaces:[{family:"思源黑体 粗",url:"fonts/SourceHanSansSC-Bold.woff2",format:"woff2"},{family:"思源黑体 常规",url:"fonts/SourceHanSansSC-Regular.woff2",format:"woff2"},{family:"思源宋体 粗",url:"fonts/SourceHanSerifSC-Bold.woff2",format:"woff2"},],
schedule:[
],
pages:[
{duration:25,zones:[
{name:"主画面",x:0.00,y:0.00,w:66.67,h:75.00,duration:10,slides:[]},
{name:"通知",x:66.67,y:0.00,w:33.33,h:50.00,titlebar:"yes",title:"今日通知",titlebar_color:"#1d4ed8",icon:"horn",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#12233f",glass_blur:"2.4",text:{content:"晨会时间 08:30 三楼会议室\n系统巡检 14:00 全线进行\n（通知请按实际修改）\n",font:"思源黑体 常规",size:"3",color:"#eaf4ff",align:"center",linespacing:"1.7"}},
{name:"时钟",x:66.67,y:50.00,w:33.33,h:25.00,tabnum:"yes",padding:"1",glass:"yes",glass_alpha:"13",glass_color:"#12233f",glass_blur:"2.4",clock:{format:"big",mode:"digital",size:"3.4",color:"#7dd3fc",font:"思源黑体 常规"}},

]},
{duration:25,zones:[
{name:"数据指标",x:0.00,y:0.00,w:50.00,h:50.00,title:"今日概览（示例数据）",icon:"chart",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#12233f",glass_blur:"2.4",data:{content:"今日出勤|326|人|96\n任务完成|88|%|88\n待办事项|12|项|40\n运行时长|99.8|%|99\n",title:"今日概览（示例数据）",icon:"chart",size:"4.2",valuecolor:"#7dd3fc",barcolor:"#38bdf8",countup:true}},
{name:"公告",x:50.00,y:0.00,w:50.00,h:50.00,title:"公告栏",icon:"info",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#12233f",glass_blur:"2.4",notice:{content:"季度工作例会改期至周五\n办公区域空调保养通知\n文档归档截止月底\n（公告按实际修改）\n",title:"公告栏",color:"#eaf4ff",size:"3",icon:"info",speed:"28"}},
{name:"今日议程",x:0.00,y:50.00,w:100.00,h:41.67,title:"今日议程",icon:"calendar",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#12233f",glass_blur:"2.4",table:{content:"时间|事项|地点\n09:00|生产晨会|三楼会议室\n10:30|项目评审|二号会议室\n14:00|系统巡检|机房\n16:00|周度复盘|大会议室\n",title:"今日议程",icon:"calendar",size:"2.6",color:"#eaf4ff",header:"yes",zebra:"yes",accent:"#1d4ed8"}},

]},
],
slides:[
]
};
