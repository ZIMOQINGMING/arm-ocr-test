window["MB_PLAYLIST_党建文化"]={
duration:8,
sound:false,
reloadMinutes:0,
fill:"cover",
transition:"fade-zoom",
transitionTime:0.9,
twinkle:false,
perf:"high",
kenburns:false,
bgcolor:"#2a0606",
ticker:{text:"学史明理 学史增信 学史崇德 学史力行　　请党放心 强国有我　　党旗所指就是团旗所向\n",effect:"scroll-left",speed:85,size:5,color:"#ffd700",bgcolor:"#6b0d0d",bold:true,height:8,sep:"　　●　　",mask:true,overlay:true,pos:"bottom"},
fontfaces:[{family:"思源黑体 粗",url:"fonts/SourceHanSansSC-Bold.woff2",format:"woff2"},{family:"思源黑体 常规",url:"fonts/SourceHanSansSC-Regular.woff2",format:"woff2"},{family:"思源宋体 粗",url:"fonts/SourceHanSerifSC-Bold.woff2",format:"woff2"},],
schedule:[
],
pages:[
{duration:25,zones:[
{name:"学习金句",x:0.00,y:0.00,w:25.00,h:33.33,frame:"doc",frame_color:"#ffd54a",frame_color2:"#c8102e",padding:"3",decor:"corner",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",text:{content:"不忘初心 方得始终\n\n青年一代有理想 有本领 有担当\n国家就有前途 民族就有希望\n\n（金句轮播：每行一句 可自行增删）\n",font:"思源宋体 粗",size:"4.2",color:"#ffe9b0",align:"center",linespacing:"2.0",effect:"typewriter",speed:"40"}},
{name:"党建动态",x:0.00,y:33.33,w:25.00,h:33.33,title:"党建动态",icon:"star",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",notice:{content:"支部委员会本月议题已排定\n党课安排已发布 请准时参加\n党小组会本周照常开展\n主题党日活动通知请查收\n（动态按实际修改）\n",title:"党建动态",color:"#ffe9b0",size:"2.8",icon:"star",speed:"26"}},
{name:"青年动态",x:0.00,y:66.67,w:25.00,h:33.33,title:"青年动态",icon:"horn",padding:"1.5",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",notice:{content:"青年读书会每周五举行　　技能比武报名进行中　　志愿服务持续开展　　请团员青年踊跃参加\n",title:"青年动态",color:"#ffe9b0",size:"2.7",icon:"horn",speed:"30"}},
{name:"主题活动",x:25.00,y:0.00,w:50.00,h:50.00,titlebar:"yes",titlebar_shape:"ribbon",title:"本期主题",titlebar_color:"#7a0d0d",icon:"flag",padding:"2.5",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",text:{content:"深学细悟强根基\n笃行实干建新功\n\n主题党日活动每月一期\n青年理论学习每周一次\n",font:"思源黑体 粗",size:"3.4",color:"#ffe9b0",align:"center",linespacing:"1.7"}},
{name:"三会一课",x:25.00,y:50.00,w:50.00,h:50.00,title:"三会一课 · 本月安排",icon:"doc",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",table:{content:"时间|事项|地点\n第一周|支部委员会|党员活动室\n第二周|党小组会|各小组场地\n第三周|主题党日|教育基地\n第四周|党课学习|大会议室\n",title:"三会一课 · 本月安排",icon:"doc",size:"2.2",color:"#ffe9b0",header:"yes",zebra:"yes",accent:"#a01515"}},
{name:"时钟",x:75.00,y:0.00,w:25.00,h:25.00,tabnum:"yes",padding:"1",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",clock:{format:"weektime",mode:"digital",size:"3",color:"#ffd700",font:"思源黑体 常规"}},
{name:"倒计时",x:75.00,y:25.00,w:25.00,h:25.00,padding:"1",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",countdown:{topic:"安全生产 100 天",target:"2026-12-31 00:00",label:"倒计时",unit:"天",topic_color:"#ffe9b0",topic_bg:"#c8102e",color:"#ffd700",size:"2.6"}},
{name:"公示栏",x:75.00,y:50.00,w:25.00,h:50.00,title:"公示栏",icon:"doc",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",notice:{content:"发展党员工作程序公开\n党费收缴使用情况公开\n评先评优结果公示\n（公示内容按实际填写）\n",title:"公示栏",color:"#ffe9b0",size:"2.9",icon:"doc",speed:"24"}},

]},
{duration:25,zones:[
{name:"党史长廊",x:0.00,y:0.00,w:100.00,h:66.67,titlebar:"yes",titlebar_shape:"ribbon",title:"党史长廊 · 光辉历程",titlebar_color:"#7a0d0d",transition:"cover-l",edge_mask:"4",duration:10,slides:[]},
{name:"大事记",x:0.00,y:66.67,w:100.00,h:33.33,title:"党史大事记（光辉历程）",icon:"flag",padding:"1.5",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",table:{content:"时间|事件\n1921|党的一大会召开 中国共产党成立\n1927|南昌起义 打响武装反抗第一枪\n1935|遵义会议 实现伟大历史转折\n1945|党的七大举行\n1949|中华人民共和国成立\n1978|十一届三中全会 开启改革开放新时期\n2012|党的十八大 中国特色社会主义进入新时代\n2022|党的二十大 为新征程擘画蓝图\n",title:"党史大事记（光辉历程）",icon:"flag",size:"2.3",color:"#ffe9b0",header:"yes",zebra:"yes",accent:"#a01515"}},

]},
{duration:25,zones:[
{name:"荣誉榜",x:0.00,y:0.00,w:58.33,h:75.00,title:"先锋榜样 · 荣誉榜",icon:"star",padding:"2",grid_fx:"9",grid_fx_order:"col",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",notice:{content:"优秀共产党员 每年评选表彰\n优秀党务工作者 每年评选表彰\n先进基层党组织 每年评选表彰\n党员先锋岗 亮身份亮职责亮承诺\n（名单以正式文件为准 按实际填写）\n",title:"先锋榜样 · 荣誉榜",color:"#ffe9b0",size:"2.9",icon:"star",speed:"24"}},
{name:"组织数据",x:58.33,y:0.00,w:41.67,h:41.67,title:"组织概况（示例 请按实际修改）",icon:"chart",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",data:{content:"支部党员数|96|名|88\n入党积极分子|24|名|60\n本年发展党员|6|名|75\n党员参学率|98|%|98\n",title:"组织概况（示例 请按实际修改）",icon:"chart",size:"3.6",valuecolor:"#ffd700",barcolor:"#c8102e",countup:true}},
{name:"活力指数",x:58.33,y:41.67,w:41.67,h:50.00,title:"组织活力",icon:"gear",padding:"1.5",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",gauge:{content:"组织生活参与度=92,100\n理论学习覆盖率=96,100\n主题党日出勤率=88,100\n志愿服务参与度=75,100\n",title:"组织活力",icon:"gear",unit:"%",size:"3.4",colors:"#e0a23c,#ffd54a,#c8102e"}},

]},
{duration:25,zones:[
{name:"红色地图",x:0.00,y:0.00,w:66.67,h:91.67,map:{content:"中国\n标题:红色教育基地巡礼（示例）\n域:江西,陕西,贵州,河北\n色:江西=#c8102e,陕西=#ffd54a,贵州=#8f2323,河北=#ff8a3a\n明度:江西=85,陕西=80,贵州=70,河北=75\n图例:红色教育基地,特色研学点\n点:井冈山,73,64,革命摇篮\n点:延安,57,40,革命圣地\n点:遵义,60,58,转折之城\n点:西柏坡,74,33,进京赶考\n",map_color:"#ffd54a",map_color2:"#c8102e",map_tint:"25",map_blur:"0"}},
{name:"教育基地说明",x:66.67,y:0.00,w:33.33,h:91.67,titlebar:"yes",titlebar_shape:"ribbon",title:"研学路线说明",titlebar_color:"#7a0d0d",icon:"pin",padding:"2",alignv:"top",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",text:{content:"红色研学地图使用说明：\n\n一、亮色区域为红色教育基地（示例可改）\n二、金色标记点为推荐研学点位\n三、可替换为本地爱国主义教育基地\n四、编辑 content/红色地图/text.txt 即可自定义高亮区域与标记\n",font:"思源黑体 常规",size:"2.7",color:"#ffe9b0",align:"left",linespacing:"1.75"}},

]},
{duration:25,zones:[
{name:"竖排标题",x:0.00,y:0.00,w:16.67,h:100.00,frame:"doc",frame_color:"#ffd54a",frame_color2:"#c8102e",glow:"#ffb84a",padding:"2",text:{content:"党旗领航\n初心如磐\n",font:"思源宋体 粗",size:"5.5",color:"#ffd700",vertical:"yes",align:"center",linespacing:"1.8"}},
{name:"红金横幅",x:16.67,y:0.00,w:83.33,h:16.67,frame:"ribbon",frame_color:"#ffd54a",frame_color2:"#c8102e",glow:"#ffb84a",shadow:"yes",padding:"1",transparent:"yes",text:{content:"党建文化阵地 · 初心使命学堂\n",font:"思源宋体 粗",size:"6.6",color:"#ffd700",bold:"yes",align:"center"}},
{name:"学习金句",x:16.67,y:16.67,w:50.00,h:41.67,frame:"doc",frame_color:"#ffd54a",frame_color2:"#c8102e",padding:"3",decor:"corner",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",text:{content:"不忘初心 方得始终\n\n青年一代有理想 有本领 有担当\n国家就有前途 民族就有希望\n\n（金句轮播：每行一句 可自行增删）\n",font:"思源宋体 粗",size:"4.2",color:"#ffe9b0",align:"center",linespacing:"2.0",effect:"typewriter",speed:"40"}},
{name:"大事记",x:66.67,y:16.67,w:33.33,h:41.67,title:"党史大事记（光辉历程）",icon:"flag",padding:"1.5",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",table:{content:"时间|事件\n1921|党的一大会召开 中国共产党成立\n1927|南昌起义 打响武装反抗第一枪\n1935|遵义会议 实现伟大历史转折\n1945|党的七大举行\n1949|中华人民共和国成立\n1978|十一届三中全会 开启改革开放新时期\n2012|党的十八大 中国特色社会主义进入新时代\n2022|党的二十大 为新征程擘画蓝图\n",title:"党史大事记（光辉历程）",icon:"flag",size:"2.3",color:"#ffe9b0",header:"yes",zebra:"yes",accent:"#a01515"}},
{name:"党建动态",x:16.67,y:58.33,w:83.33,h:41.67,title:"党建动态",icon:"star",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",notice:{content:"支部委员会本月议题已排定\n党课安排已发布 请准时参加\n党小组会本周照常开展\n主题党日活动通知请查收\n（动态按实际修改）\n",title:"党建动态",color:"#ffe9b0",size:"2.8",icon:"star",speed:"26"}},

]},
{duration:25,zones:[
{name:"主题党日安排",x:0.00,y:0.00,w:58.33,h:66.67,title:"主题党日 · 流程安排",icon:"flag",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",table:{content:"时间|环节|内容\n09:00|签到入场|党员活动室\n09:10|重温誓词|全体党员\n09:30|集中学习|领学+研讨\n10:20|交流发言|代表发言\n10:50|部署工作|支部书记\n",title:"主题党日 · 流程安排",icon:"flag",size:"2.5",color:"#ffe9b0",header:"yes",zebra:"yes",accent:"#a01515"}},
{name:"公示栏",x:58.33,y:0.00,w:41.67,h:66.67,title:"公示栏",icon:"doc",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",notice:{content:"发展党员工作程序公开\n党费收缴使用情况公开\n评先评优结果公示\n（公示内容按实际填写）\n",title:"公示栏",color:"#ffe9b0",size:"2.9",icon:"doc",speed:"24"}},
{name:"监督电话",x:0.00,y:66.67,w:100.00,h:25.00,frame:"bookmark",frame_color:"#ffd54a",frame_color2:"#c8102e",padding:"2",glass:"yes",glass_alpha:"13",glass_color:"#4a0a0a",glass_blur:"2.2",text:{content:"意见箱：党员活动室入口\n监督电话：0000-0000000（请填写）\n接待时间：工作日 09:00-17:00\n",font:"思源黑体 常规",size:"2.6",color:"#ffd700",align:"center",linespacing:"1.6"}},

]},
],
slides:[
]
};
