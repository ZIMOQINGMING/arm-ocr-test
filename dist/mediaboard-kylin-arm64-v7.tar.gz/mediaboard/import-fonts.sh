#!/usr/bin/env bash
# MediaBoard v7 系统字体导入工具（麒麟 V10 离网可用）
# 把麒麟系统 / 麒麟应用商店安装的字体复制进包内 fonts/ 目录，离线播放即可使用。
#
# 用法:
#   ./import-fonts.sh --list [关键词]      列出系统字体（可加关键词过滤）
#   ./import-fonts.sh 思源 黑体 楷体       按名称导入（多关键词任一命中即导入）
#   ./import-fonts.sh /路径/xx.ttf         按文件路径导入
#
# 导入后:
#   1) 字体族名默认取文件名（不含扩展名）；建议在 fonts/FONTS.txt 加别名行:
#      SourceHanSansSC-Bold=思源黑体 粗
#   2) 之后任意分区 style.txt 写 FONT=思源黑体 粗 即可用该字体。
#   3) 大字体文件会增大包体并拖慢首屏；仅导入实际用到的字重，
#      有条件时可在联网电脑上做子集化后再拷入（参考 fonts/README.txt）。
# 许可提示: 请确认所导字体具备本单位使用授权（系统自带字体随系统授权走）。
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
FDIR="$DIR/fonts"
[ -d "$FDIR" ] || mkdir -p "$FDIR"

# 常见系统字体位置（麒麟 V10 / UKUI / WPS）
SCAN_DIRS="/usr/share/fonts /usr/local/share/fonts $HOME/.fonts $HOME/.local/share/fonts /opt/fonts"

find_fonts() { # $1=可选关键词（空=全部）
  local kw="$1" f nm
  find $SCAN_DIRS -type f \
    \( -iname "*.ttf" -o -iname "*.otf" -o -iname "*.woff" -o -iname "*.woff2" \) 2>/dev/null \
    | LC_ALL=C sort | while IFS= read -r f; do
      nm="$(basename "$f")"
      if [ -n "$kw" ]; then
        case "$nm" in *"$kw"*) printf '%s\n' "$f";; esac
      else
        printf '%s\n' "$f"
      fi
    done
}

case "${1:-}" in
  --list|-l)
    shift || true
    KW="${1:-}"
    find_fonts "$KW" | while IFS= read -r f; do
      printf '%s  (%s)\n' "$(basename "$f")" "$(du -h "$f" 2>/dev/null | cut -f1)"
    done
    echo "提示: ./import-fonts.sh <名称关键词> 导入；导入后编辑 fonts/FONTS.txt 设中文名。"
    exit 0
    ;;
  "")
    echo "用法: $0 --list [关键词] | $0 <名称关键词...> | $0 <字体文件路径>"
    echo "示例: $0 --list 楷   （列出含『楷』的系统字体）"
    echo "      $0 楷 金石      （导入命中的字体进 fonts/）"
    exit 0
    ;;
esac

import_one() {
  local src="$1" dst fam
  [ -f "$src" ] || { echo "[跳过] 文件不存在: $src"; return 1; }
  dst="$FDIR/$(basename "$src")"
  fam="$(basename "${src%.*}")"
  if [ -e "$dst" ]; then
    echo "[跳过] 已存在: $(basename "$src")（先手动删除再重复制）"
    return 0
  fi
  cp -f "$src" "$dst" || { echo "[失败] 复制: $src"; return 1; }
  echo "[导入] $fam -> fonts/$(basename "$src")  ($(du -h "$dst" | cut -f1))"
  # 提示别名（幂等：不重复追加）
  if [ -f "$FDIR/FONTS.txt" ] && ! grep -qF "$fam=" "$FDIR/FONTS.txt"; then
    echo "# $fam=$fam" >> "$FDIR/FONTS.txt"
  fi
}

IMPORTED=0
for arg in "$@"; do
  case "$arg" in
    /*|./*) # 绝对/相对路径
      import_one "$arg" && IMPORTED=$((IMPORTED + 1))
      ;;
    *) # 名称关键词：扫描命中即导入
      find_fonts "$arg" | while IFS= read -r f; do import_one "$f"; done
      cnt="$(find_fonts "$arg" | wc -l)"
      [ "$cnt" -gt 0 ] && IMPORTED=$((IMPORTED + cnt)) || echo "[提示] 系统字体目录未命中关键词: $arg"
      ;;
  esac
done

echo ""
echo "完成。请检查 fonts/ 目录；随后可运行 ./start.sh 重新生成 playlist（字体自动枚举注入）。"
echo "建议: 在 fonts/FONTS.txt 里给新字体设中文名，例如: SourceHanSansSC-Bold=思源黑体 粗"
echo "      分区 style.txt 中写 FONT=思源黑体 粗 即可生效。"
